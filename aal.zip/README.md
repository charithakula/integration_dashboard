# ICoE Integration Landscape Dashboard

A Flask-based dashboard application for monitoring and analyzing API usage across different organizational units with Splunk integration.

## 🏗️ Architecture Overview

This application has been refactored from a monolithic structure into modular components:

```
├── app.py                  # Main Flask application
├── config.py              # Configuration management
├── models.py               # Data validation schemas
├── queries.py              # Splunk query definitions
├── cache.py                # Cache management utilities
├── splunk_connector.py     # Splunk connection handling
├── data_processing.py      # Data processing and mock data
├── tasks.py                # Background task management
├── utils.py                # Utility functions
├── run.py                  # Application runner
├── requirements.txt        # Python dependencies
├── Dockerfile              # Container configuration
├── docker-compose.yml      # Container orchestration
├── .env.example            # Environment variables template
└── README.md               # This file
```

## 🚀 Quick Start

### 1. Environment Setup

```bash
# Clone the repository
git clone <repository-url>
cd icoe-dashboard

# Copy environment template
cp .env.example .env

# Edit .env file with your configuration
nano .env
```

### 2. Install Dependencies

```bash
# Create virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 3. Configure Splunk (Optional)

Edit your `.env` file with Splunk credentials:

```bash
SPLUNK_HOST=your-splunk-host.com
SPLUNK_PORT=8089
SPLUNK_USERNAME=your-username
SPLUNK_PASSWORD=your-password
```

### 4. Run the Application

```bash
# Simple run
python run.py

# Or using Flask directly
export FLASK_APP=run.py
flask run
```

The application will be available at `http://localhost:5000`

## 🐳 Docker Deployment

### Basic Deployment

```bash
# Build and run with Docker
docker build -t icoe-dashboard .
docker run -p 5000:5000 --env-file .env icoe-dashboard
```

### Docker Compose (Recommended)

```bash
# Start the application
docker-compose up -d

# With monitoring stack (Prometheus + Grafana)
docker-compose --profile monitoring up -d

# With Redis caching
docker-compose --profile redis up -d

# All services
docker-compose --profile monitoring --profile redis up -d
```

## 📊 Available Endpoints

### Dashboard Endpoints
- `GET /` - Main dashboard interface
- `GET /api/dashboard-data` - Dashboard data API
- `GET /api/health` - Health check endpoint
- `GET /api/refresh-cache` - Clear and refresh cache

### Splunk Integration
- `POST /api/splunk/search` - Direct Splunk search endpoint

### Data Export
- `GET /api/export/json` - Export data as JSON
- `GET /api/export/csv` - Export data as CSV
- `GET /api/export/pdf` - Export data as PDF

### Monitoring
- `GET /metrics` - Prometheus metrics endpoint

## 🔧 Configuration

### Environment Variables

| Variable | Description | Default | Required |
|----------|-------------|---------|----------|
| `FLASK_ENV` | Environment mode | `development` | No |
| `FLASK_DEBUG` | Debug mode | `false` | No |
| `SECRET_KEY` | Flask secret key | - | Yes |
| `HOST` | Server host | `0.0.0.0` | No |
| `PORT` | Server port | `5000` | No |
| `SPLUNK_HOST` | Splunk server host | - | Yes* |
| `SPLUNK_PORT` | Splunk server port | `8089` | No |
| `SPLUNK_USERNAME` | Splunk username | - | Yes* |
| `SPLUNK_PASSWORD` | Splunk password | - | Yes* |
| `CACHE_TTL` | Cache TTL in seconds | `300` | No |

*Required for Splunk integration. Without these, the app will use mock data.

### Configuration Classes

The application supports multiple configuration environments:

- **Development**: Debug enabled, shorter cache TTL
- **Production**: Debug disabled, security optimized
- **Testing**: Optimized for testing scenarios

## 📦 Module Overview

### `app.py` - Main Application
- Flask application factory
- Route definitions
- Error handling
- Background task setup

### `config.py` - Configuration Management
- Environment-based configuration
- Security settings
- Feature flags

### `splunk_connector.py` - Splunk Integration
- Session-based authentication
- Query execution
- Connection management
- Error handling and retries

### `cache.py` - Cache Management
- In-memory caching
- Cache decorators
- Cache statistics
- Cleanup utilities

### `data_processing.py` - Data Processing
- Raw data transformation
- Mock data generation
- Data validation
- Statistical calculations

### `tasks.py` - Background Tasks
- Cache management
- Health monitoring
- Metrics collection
- Connection retries

### `utils.py` - Utilities
- Export functions (CSV, PDF)
- Data validation
- Formatting helpers
- System utilities

## 🔍 Monitoring & Observability

### Prometheus Metrics
The application exposes metrics at `/metrics`:
- Request counts and durations
- Splunk query statistics
- Cache hit rates
- Active connections

### Health Checks
Health endpoint at `/api/health` provides:
- Service status
- Connection status
- Cache statistics
- System metrics

### Logging
Structured JSON logging with:
- Request tracing
- Error tracking
- Performance metrics
- Security events

## 🚨 Error Handling

The application includes comprehensive error handling:
- **Splunk Failures**: Automatic fallback to mock data
- **Cache Issues**: Graceful degradation
- **Network Errors**: Retry mechanisms with exponential backoff
- **Validation Errors**: Clear error messages

## 🔒 Security Features

- Input validation and sanitization
- SQL injection prevention
- Rate limiting capabilities
- Secure headers
- Environment-based configuration
- Non-root container execution

## 🧪 Testing

```bash
# Run tests
pytest

# Run with coverage
pytest --cov=. --cov-report=html

# Run specific test file
pytest tests/test_splunk_connector.py
```

## 📈 Performance Considerations

- **Caching**: Configurable TTL, automatic cleanup
- **Connection Pooling**: Reused HTTP connections
- **Background Tasks**: Non-blocking operations
- **Pagination**: Limited result sets
- **Compression**: Gzip compression enabled

## 🔧 Development

### Code Quality
```bash
# Format code
black .

# Sort imports
isort .

# Lint code
flake8 .
```

### Adding New Features

1. **New Splunk Queries**: Add to `queries.py`
2. **New Endpoints**: Add to `app.py`
3. **New Data Processing**: Add to `data_processing.py`
4. **New Background Tasks**: Add to `tasks.py`

## 🐛 Troubleshooting

### Common Issues

1. **Splunk Connection Failed**
   - Check credentials in `.env`
   - Verify network connectivity
   - Check Splunk server logs

2. **Cache Issues**
   - Clear cache: `GET /api/refresh-cache`
   - Check memory usage
   - Verify TTL settings

3. **Performance Issues**
   - Monitor `/metrics` endpoint
   - Check Splunk query performance
   - Review cache hit rates

### Debug Mode
Enable debug mode for detailed logging:
```bash
export FLASK_DEBUG=true
python run.py
```

## 📝 API Documentation

### Dashboard Data API
```bash
GET /api/dashboard-data?time_range=30d&environment=prod
```

### Direct Splunk Search
```bash
POST /api/splunk/search
Content-Type: application/json

{
  "query": "search index=datapower | stats count",
  "earliest_time": "-24h@h",
  "latest_time": "now"
}
```

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Run quality checks
6. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Check the troubleshooting section
- Review application logs
- Check health endpoint: `/api/health`
- Contact the ICoE team