#!/usr/bin/env python3
"""
Simple runner script for the ICoE Integration Landscape Dashboard
"""
import os
import sys
from app import create_app, setup_background_tasks

def main():
    """Main entry point for the application"""
    # Get environment configuration
    env = os.getenv('FLASK_ENV', 'development')
    
    print(f"Starting ICoE Dashboard in {env} mode...")
    
    try:
        # Create the Flask application
        app = create_app(env)
        
        # Setup background tasks
        setup_background_tasks(app)
        
        # Get host and port from config
        host = app.config.get('HOST', '0.0.0.0')
        port = app.config.get('PORT', 5000)
        debug = app.config.get('DEBUG', False)
        
        print(f"Server starting on http://{host}:{port}")
        print(f"Debug mode: {debug}")
        
        if app.splunk and app.splunk.config.get('username'):
            print(f"Splunk configured: {app.splunk.config['host']}:{app.splunk.config['port']}")
        else:
            print("Splunk not configured - using mock data")
        
        # Start the application
        app.run(
            host=host,
            port=port,
            debug=debug,
            threaded=True
        )
        
    except KeyboardInterrupt:
        print("\nShutting down gracefully...")
        sys.exit(0)
    except Exception as e:
        print(f"Failed to start application: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()