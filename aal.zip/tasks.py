import time
import threading
import schedule
from datetime import datetime
import structlog
from cache import memory_cache, cleanup_expired_entries
from prometheus_client import Gauge

# Initialize logger
logger = structlog.get_logger()

# Metrics
ACTIVE_CONNECTIONS = Gauge('active_connections', 'Active connections')

class BackgroundTaskManager:
    """Manages background tasks for the application"""
    
    def __init__(self, app_config=None, splunk_connector=None):
        self.app_config = app_config or {}
        self.splunk_connector = splunk_connector
        self.running = False
        self.threads = []
        
    def start_background_tasks(self):
        """Start all background tasks"""
        if self.running:
            logger.warning("Background tasks already running")
            return
            
        self.running = True
        
        # Start cache management thread
        cache_thread = threading.Thread(
            target=self._cache_management_loop, 
            name="CacheManager",
            daemon=True
        )
        cache_thread.start()
        self.threads.append(cache_thread)
        
        # Start health monitoring thread
        health_thread = threading.Thread(
            target=self._health_monitoring_loop,
            name="HealthMonitor", 
            daemon=True
        )
        health_thread.start()
        self.threads.append(health_thread)
        
        # Start metrics collection thread
        metrics_thread = threading.Thread(
            target=self._metrics_collection_loop,
            name="MetricsCollector",
            daemon=True
        )
        metrics_thread.start()
        self.threads.append(metrics_thread)
        
        logger.info("Background tasks started", thread_count=len(self.threads))
        
    def stop_background_tasks(self):
        """Stop all background tasks"""
        self.running = False
        logger.info("Background tasks stopped")
        
    def _cache_management_loop(self):
        """Background cache management task"""
        logger.info("Cache management task started")
        
        while self.running:
            try:
                # Get cache TTL from config
                cache_ttl = self.app_config.get('CACHE_TTL', 300)
                
                # Sleep for the cache TTL duration
                time.sleep(cache_ttl)
                
                if not self.running:
                    break
                    
                logger.info("Starting cache maintenance cycle")
                
                # Clean expired entries
                expired_count = cleanup_expired_entries(cache_ttl)
                
                # Log cache statistics
                cache_size = len(memory_cache)
                logger.info("Cache maintenance completed", 
                          expired_entries=expired_count,
                          active_entries=cache_size)
                
                # If cache is getting too large, do more aggressive cleanup
                if cache_size > 1000:
                    logger.warning("Cache size is large, performing aggressive cleanup", 
                                 cache_size=cache_size)
                    # Clean entries older than half the TTL
                    cleanup_expired_entries(cache_ttl // 2)
                
            except Exception as e:
                logger.error("Cache management task error", error=str(e))
                # Sleep a bit before retrying
                time.sleep(30)
        
        logger.info("Cache management task stopped")
    
    def _health_monitoring_loop(self):
        """Background health monitoring task"""
        logger.info("Health monitoring task started")
        
        # Schedule health checks every 5 minutes
        schedule.every(5).minutes.do(self._perform_health_check)
        
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(30)  # Check for scheduled tasks every 30 seconds
                
            except Exception as e:
                logger.error("Health monitoring task error", error=str(e))
                time.sleep(60)
        
        logger.info("Health monitoring task stopped")
    
    def _metrics_collection_loop(self):
        """Background metrics collection task"""
        logger.info("Metrics collection task started")
        
        while self.running:
            try:
                # Collect and update metrics every minute
                time.sleep(60)
                
                if not self.running:
                    break
                
                self._collect_metrics()
                
            except Exception as e:
                logger.error("Metrics collection task error", error=str(e))
                time.sleep(60)
        
        logger.info("Metrics collection task stopped")
    
    def _perform_health_check(self):
        """Perform health check on Splunk connection"""
        try:
            if not self.splunk_connector:
                ACTIVE_CONNECTIONS.set(0)
                return
            
            # Test Splunk connection
            if (self.splunk_connector.config.get('username') and 
                self.splunk_connector.config.get('password')):
                
                connection_successful = self.splunk_connector.test_connection()
                
                if connection_successful:
                    ACTIVE_CONNECTIONS.set(1)
                    logger.debug("Health check passed - Splunk connection active")
                else:
                    ACTIVE_CONNECTIONS.set(0)
                    logger.warning("Health check failed - Splunk connection inactive")
            else:
                ACTIVE_CONNECTIONS.set(0)
                logger.debug("Health check skipped - no Splunk credentials")
                
        except Exception as e:
            logger.error("Health check failed", error=str(e))
            ACTIVE_CONNECTIONS.set(0)
    
    def _collect_metrics(self):
        """Collect various application metrics"""
        try:
            # Cache metrics
            cache_stats = {
                'total_entries': len(memory_cache),
                'estimated_size': sum(len(str(data)) for data, _ in memory_cache.values())
            }
            
            logger.debug("Metrics collected", 
                        cache_entries=cache_stats['total_entries'],
                        cache_size=cache_stats['estimated_size'])
            
        except Exception as e:
            logger.error("Metrics collection failed", error=str(e))

def scheduled_cache_warm_up(get_dashboard_data_func, warm_up_params=None):
    """Scheduled task to warm up cache with common queries"""
    try:
        if not warm_up_params:
            warm_up_params = [
                {'time_range': '30d', 'environment': 'prod'},
                {'time_range': '7d', 'environment': 'prod'},
                {'time_range': '1d', 'environment': 'prod'},
            ]
        
        logger.info("Starting cache warm-up", params_count=len(warm_up_params))
        
        warmed_count = 0
        for params in warm_up_params:
            try:
                # This will cache the results
                data = get_dashboard_data_func(**params)
                if data:
                    warmed_count += 1
                    logger.debug("Cache warmed for params", params=params)
                else:
                    logger.warning("Cache warm-up returned no data", params=params)
                    
            except Exception as e:
                logger.warning("Cache warm-up failed for params", params=params, error=str(e))
        
        logger.info("Cache warm-up completed", 
                   successful_warmups=warmed_count,
                   total_attempts=len(warm_up_params))
        
    except Exception as e:
        logger.error("Cache warm-up task failed", error=str(e))

def scheduled_data_quality_check(get_dashboard_data_func):
    """Scheduled task to check data quality"""
    try:
        logger.info("Starting data quality check")
        
        # Get current data
        data = get_dashboard_data_func('30d', 'prod')
        
        if not data:
            logger.warning("Data quality check: No data available")
            return
        
        # Perform quality checks
        quality_issues = []
        
        # Check for empty datasets
        for key, value in data.items():
            if isinstance(value, dict):
                if 'labels' in value and 'data' in value:
                    if not value['labels'] or not value['data']:
                        quality_issues.append(f"Empty dataset: {key}")
                    elif len(value['labels']) != len(value['data']):
                        quality_issues.append(f"Mismatched labels/data: {key}")
        
        # Check stats validity
        stats = data.get('stats', {})
        for stat_key, stat_value in stats.items():
            if not stat_value or stat_value == '0' or stat_value == '0%':
                quality_issues.append(f"Zero/empty stat: {stat_key}")
        
        if quality_issues:
            logger.warning("Data quality issues detected", issues=quality_issues)
        else:
            logger.info("Data quality check passed")
            
    except Exception as e:
        logger.error("Data quality check failed", error=str(e))

def scheduled_connection_retry(splunk_connector):
    """Scheduled task to retry Splunk connection if it's down"""
    try:
        if not splunk_connector:
            return
            
        if not (splunk_connector.config.get('username') and 
                splunk_connector.config.get('password')):
            return
        
        # Only retry if connection is down
        if not splunk_connector.is_session_valid():
            logger.info("Attempting to restore Splunk connection")
            
            connection_restored = splunk_connector.connect()
            
            if connection_restored:
                logger.info("Splunk connection restored successfully")
            else:
                logger.warning("Splunk connection restore failed")
        
    except Exception as e:
        logger.error("Connection retry task failed", error=str(e))

def create_background_task_manager(app_config, splunk_connector=None):
    """Factory function to create and configure background task manager"""
    manager = BackgroundTaskManager(app_config, splunk_connector)
    
    # Add any additional configuration here
    if app_config.get('DEBUG'):
        logger.info("Background tasks configured for development mode")
    else:
        logger.info("Background tasks configured for production mode")
    
    return manager

# Utility functions for manual task execution
def run_cache_maintenance(cache_ttl=300):
    """Manually run cache maintenance"""
    try:
        expired_count = cleanup_expired_entries(cache_ttl)
        logger.info("Manual cache maintenance completed", expired_entries=expired_count)
        return expired_count
    except Exception as e:
        logger.error("Manual cache maintenance failed", error=str(e))
        return 0

def run_health_check(splunk_connector):
    """Manually run health check"""
    try:
        if not splunk_connector:
            return False
            
        connection_successful = splunk_connector.test_connection()
        logger.info("Manual health check completed", connection_status=connection_successful)
        return connection_successful
    except Exception as e:
        logger.error("Manual health check failed", error=str(e))
        return False