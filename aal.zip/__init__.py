"""
ICoE Integration Landscape Dashboard

A Flask application for monitoring and analyzing API usage across different
organizational units with Splunk integration.
"""

__version__ = "2.0.0"
__author__ = "ICoE Team"
__description__ = "Integration Landscape Dashboard with Splunk Analytics"

# Import main components for easy access
from .app import create_app
from .config import Config
from .splunk_connector import SplunkConnector
from .cache import cache_result, clear_cache
from .data_processing import get_mock_data, process_splunk_data

# Package-level configuration
DEFAULT_CONFIG = {
    'CACHE_TTL': 300,
    'DEBUG': False,
    'SPLUNK_TIMEOUT': 30,
    'MAX_QUERY_RESULTS': 1000
}

__all__ = [
    'create_app',
    'Config',
    'SplunkConnector',
    'cache_result',
    'clear_cache',
    'get_mock_data',
    'process_splunk_data',
    'DEFAULT_CONFIG'
]