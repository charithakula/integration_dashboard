import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class Config:
    """Application configuration"""
    SECRET_KEY = os.getenv('SECRET_KEY', 'dev-secret-key-change-in-production')
    
    # Splunk Configuration - Session Authentication (Username/Password)
    SPLUNK_HOST = os.getenv('SPLUNK_HOST', 'localhost')
    SPLUNK_PORT = int(os.getenv('SPLUNK_PORT', '8089'))
    SPLUNK_SCHEME = os.getenv('SPLUNK_SCHEME', 'https')
    SPLUNK_USERNAME = os.getenv('SPLUNK_USERNAME')
    SPLUNK_PASSWORD = os.getenv('SPLUNK_PASSWORD')
    
    # Cache Configuration (In-Memory Only)
    CACHE_TTL = int(os.getenv('CACHE_TTL', '300'))  # 5 minutes
    
    # Application Settings
    DEBUG = os.getenv('FLASK_DEBUG', 'False').lower() == 'true'
    PORT = int(os.getenv('PORT', '5000'))
    HOST = os.getenv('HOST', '0.0.0.0')

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    CACHE_TTL = 60  # Shorter cache for development

class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    
class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    CACHE_TTL = 0  # No caching for tests

# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}