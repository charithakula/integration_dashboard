import time
from typing import Optional, Any
from functools import wraps
import structlog

# Initialize logger
logger = structlog.get_logger()

# In-memory cache ONLY
memory_cache = {}

def get_cache_key(prefix: str, **kwargs) -> str:
    """Generate cache key from parameters"""
    sorted_params = sorted(kwargs.items())
    params_str = "_".join([f"{k}:{v}" for k, v in sorted_params])
    return f"{prefix}:{params_str}"

def get_from_cache(key: str, ttl: int = 300) -> Optional[Any]:
    """Get value from in-memory cache with better error handling"""
    try:
        if key in memory_cache:
            data, timestamp = memory_cache[key]
            if time.time() - timestamp < ttl:
                logger.debug("Cache hit", key=key)
                return data
            else:
                # Remove expired entry
                del memory_cache[key]
                logger.debug("Cache expired, removed", key=key)
    except Exception as e:
        logger.error("Cache retrieval error", error=str(e), key=key)
    
    return None

def set_cache(key: str, value: Any, ttl: int = None) -> bool:
    """Set value in in-memory cache"""
    try:
        memory_cache[key] = (value, time.time())
        logger.debug("Cache stored", key=key)
        return True
    except Exception as e:
        logger.error("Cache storage error", error=str(e), key=key)
        return False

def clear_cache() -> int:
    """Clear all cache entries"""
    try:
        cleared_count = len(memory_cache)
        memory_cache.clear()
        logger.info("Cache cleared", entries_removed=cleared_count)
        return cleared_count
    except Exception as e:
        logger.error("Cache clear error", error=str(e))
        return 0

def get_cache_stats() -> dict:
    """Get cache statistics"""
    try:
        current_time = time.time()
        active_entries = 0
        expired_entries = 0
        total_size = 0
        
        for key, (data, timestamp) in memory_cache.items():
            if current_time - timestamp < 300:  # Default TTL
                active_entries += 1
            else:
                expired_entries += 1
            
            # Rough size estimation
            total_size += len(str(data))
        
        return {
            'total_entries': len(memory_cache),
            'active_entries': active_entries,
            'expired_entries': expired_entries,
            'estimated_size_bytes': total_size,
            'cache_type': 'memory'
        }
    except Exception as e:
        logger.error("Error getting cache stats", error=str(e))
        return {
            'total_entries': 0,
            'active_entries': 0,
            'expired_entries': 0,
            'estimated_size_bytes': 0,
            'cache_type': 'memory',
            'error': str(e)
        }

def cleanup_expired_entries(ttl: int = 300) -> int:
    """Clean up expired cache entries"""
    try:
        current_time = time.time()
        expired_keys = [
            key for key, (_, timestamp) in memory_cache.items()
            if current_time - timestamp > ttl
        ]
        
        for key in expired_keys:
            del memory_cache[key]
        
        logger.info("Cache cleanup completed", expired_entries=len(expired_keys))
        return len(expired_keys)
    except Exception as e:
        logger.error("Cache cleanup error", error=str(e))
        return 0

def cache_result(cache_prefix: str, ttl: int = None, use_mock_on_failure: bool = True):
    """Enhanced caching decorator with mock fallback"""
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Create cache key from function arguments
            cache_key = get_cache_key(cache_prefix, **kwargs)
            
            # Try to get from cache
            cached_result = get_from_cache(cache_key, ttl or 300)
            if cached_result is not None:
                logger.debug("Cache hit", function=func.__name__, cache_key=cache_key)
                return cached_result
            
            # Execute function and cache result
            try:
                result = func(*args, **kwargs)
                if result:
                    set_cache(cache_key, result, ttl)
                    logger.debug("Cache miss - stored result", function=func.__name__, cache_key=cache_key)
                    return result
                elif use_mock_on_failure:
                    logger.warning("Function returned empty result, using mock data", function=func.__name__)
                    from data_processing import get_mock_data
                    mock_result = get_mock_data()
                    return mock_result
                else:
                    return result
            except Exception as e:
                logger.error("Function execution failed", function=func.__name__, error=str(e))
                if use_mock_on_failure:
                    from data_processing import get_mock_data
                    return get_mock_data()
                return {}
        return wrapper
    return decorator

def invalidate_cache_pattern(pattern: str) -> int:
    """Invalidate cache entries matching a pattern"""
    try:
        matching_keys = [key for key in memory_cache.keys() if pattern in key]
        
        for key in matching_keys:
            del memory_cache[key]
        
        logger.info("Cache pattern invalidated", pattern=pattern, keys_removed=len(matching_keys))
        return len(matching_keys)
    except Exception as e:
        logger.error("Cache pattern invalidation error", error=str(e), pattern=pattern)
        return 0

def warm_cache(func, cache_prefix: str, params_list: list, ttl: int = None):
    """Warm up cache with pre-computed values"""
    try:
        warmed_count = 0
        for params in params_list:
            cache_key = get_cache_key(cache_prefix, **params)
            
            # Only warm if not already cached
            if get_from_cache(cache_key, ttl or 300) is None:
                try:
                    result = func(**params)
                    if result:
                        set_cache(cache_key, result, ttl)
                        warmed_count += 1
                except Exception as e:
                    logger.warning("Cache warming failed for params", params=params, error=str(e))
        
        logger.info("Cache warming completed", warmed_entries=warmed_count)
        return warmed_count
    except Exception as e:
        logger.error("Cache warming error", error=str(e))
        return 0