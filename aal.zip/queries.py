# Splunk Queries for Dashboard

SPLUNK_QUERIES = {
    'total_consumers': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | stats distinct_count(app_name)
    ''',
    
    'top_apis_by_consumers': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | stats distinct_count(app_name) as consumers by api_name 
        | sort - consumers 
        | head 10
    ''',
    
    'api_usage_count': '''
        search index="datapower" sourcetype="datapower:apimgr" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | stats distinct_count(app_name) as AppUsageCount by api_name 
        | sort - AppUsageCount 
        | head 10
    ''',
    
    'api_usage_by_app': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* app_name!="API-MSP" 
        app_name!="API Connect Common App" app_name!="developer" app_name!="N/A" 
        | stats distinct_count(api_name) as api_usage by app_name 
        | sort - api_usage 
        | head 10
    ''',
    
    'performance_metrics_7d': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        status_code="20*" app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | lookup icoe_api_reporting_dashboard_providerorg api_name 
        | stats min(time_to_serve_request) as min_response 
          avg(time_to_serve_request) as avg_response 
          max(time_to_serve_request) as max_response 
          count(resource_id) as total_count by ou_name api_name 
        | sort - total_count
    ''',
    
    'performance_metrics_30d': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        status_code="20*" app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | lookup icoe_api_reporting_dashboard_providerorg api_name 
        | stats min(time_to_serve_request) as min_response 
          avg(time_to_serve_request) as avg_response 
          max(time_to_serve_request) as max_response 
          count(resource_id) as total_count by ou_name api_name 
        | sort - total_count
    ''',
    
    'ou_api_usage': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | lookup icoe_api_reporting_dashboard_providerorg api_name 
        | stats distinct_count(api_name) as api_usage by ou_name
    ''',
    
    'ou_api_usage_filtered': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* app_name!="API Connect Common App" 
        | lookup icoe_api_reporting_dashboard_providerorg app_name 
        | stats distinct_count(api_name) as APIUsageCount by ou_name
    ''',
    
    'performance_timechart': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        (api_name="payments" OR api_name="viewusage" OR api_name="bills") 
        | timechart span=1h avg(time_to_serve_request) by api_name
    ''',
    
    'daily_app_usage': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="API Connect Common App" 
        | timechart span=1d count by app_name limit=5
    ''',
    
    'error_analysis': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        status_code="40*" OR status_code="50*"
        | stats count(uri_path) as CountOfPath by uri_path status_code bytes_sent
        | sort - CountOfPath
        | head 20
    ''',
    
    'api_reusability': '''
        search index="datapower" sourcetype="datapower:apimgr:app" catalog_name="prod" 
        app_name!="N/A" app_name!="" *INTERNAL*OS_* 
        | stats distinct_count(api_name) as "used"
    '''
}

def get_query_by_name(query_name: str) -> str:
    """Get a Splunk query by name"""
    return SPLUNK_QUERIES.get(query_name, '')

def modify_query_for_environment(query: str, environment: str) -> str:
    """Modify a query for a specific environment"""
    if environment != 'prod':
        return query.replace('catalog_name="prod"', f'catalog_name="{environment}"')
    return query

def get_available_queries() -> list:
    """Get list of available query names"""
    return list(SPLUNK_QUERIES.keys())

def validate_query_syntax(query: str) -> bool:
    """Basic validation of Splunk query syntax"""
    dangerous_keywords = ['delete', 'drop', 'insert', 'update', 'create', 'alter', 'eval', 'outputlookup']
    query_lower = query.lower()
    
    # Check for dangerous operations
    if any(keyword in query_lower for keyword in dangerous_keywords):
        return False
    
    # Ensure query starts with 'search' or contains 'index='
    if not (query_lower.strip().startswith('search') or 'index=' in query_lower):
        return False
    
    return True

def prepare_query(query: str, environment: str = 'prod') -> str:
    """Prepare a query for execution by ensuring proper syntax and environment"""
    # Modify for environment
    query = modify_query_for_environment(query, environment)
    
    # Ensure query starts with 'search'
    query = query.strip()
    if not query.lower().startswith('search '):
        query = f"search {query}"
    
    return query