#!/usr/bin/env python3
"""
Splunk Connector Usage Examples

This file demonstrates how to use the enhanced SplunkConnector
with both authentication methods and various use cases.
"""

import os
import sys
import json
from datetime import datetime, timedelta

# Import the connector (works standalone)
from splunk_connector import (
    SplunkConnector, 
    create_username_password_connector,
    create_bearer_token_connector,
    AuthMethod
)

# Example 1: Username/Password Authentication
def example_username_password():
    """Example using username/password authentication"""
    print("=== Username/Password Authentication Example ===")
    
    # Method 1: Using the convenience function
    connector = create_username_password_connector(
        host='your-splunk-host.com',
        username='your-username',
        password='your-password',
        port=8089,
        verify_ssl=False
    )
    
    # Method 2: Using the main class with config dict
    config = {
        'host': 'your-splunk-host.com',
        'port': 8089,
        'scheme': 'https',
        'auth_method': 'username_password',
        'username': 'your-username',
        'password': 'your-password',
        'verify_ssl': False,
        'timeout': 30
    }
    # connector = SplunkConnector(config)
    
    # Test connection
    if connector.connect():
        print("✓ Connected successfully")
        
        # Execute a simple query
        results = connector.execute_query(
            query='search index=_internal | head 10',
            earliest_time='-1h@h',
            latest_time='now'
        )
        print(f"Query returned {len(results)} results")
        
        # Get connection status
        status = connector.get_status()
        print(f"Connection status: {status['connected']}")
        print(f"Auth method: {status['auth_method']}")
        
    else:
        print("✗ Connection failed")

# Example 2: Bearer Token Authentication
def example_bearer_token():
    """Example using bearer token authentication"""
    print("\n=== Bearer Token Authentication Example ===")
    
    # Method 1: Using the convenience function
    connector = create_bearer_token_connector(
        host='your-splunk-host.com',
        bearer_token='your-bearer-token-here',
        port=8089,
        token_type='Splunk',  # or 'Bearer'
        verify_ssl=False
    )
    
    # Method 2: Using the main class with config dict
    config = {
        'host': 'your-splunk-host.com',
        'port': 8089,
        'scheme': 'https',
        'auth_method': 'bearer_token',
        'bearer_token': 'your-bearer-token-here',
        'token_type': 'Splunk',  # This will result in "Authorization: Splunk your-token"
        'verify_ssl': False,
        'timeout': 30
    }
    # connector = SplunkConnector(config)
    
    # Test connection
    if connector.connect():
        print("✓ Connected successfully with bearer token")
        
        # Execute query
        results = connector.execute_query(
            query='search index=datapower | head 5',
            earliest_time='-24h@h',
            latest_time='now'
        )
        print(f"Query returned {len(results)} results")
        
    else:
        print("✗ Bearer token connection failed")

# Example 3: Advanced Query Examples
def example_advanced_queries():
    """Example showing various Splunk queries"""
    print("\n=== Advanced Query Examples ===")
    
    # Use environment variables for credentials
    connector = create_username_password_connector(
        host=os.getenv('SPLUNK_HOST', 'localhost'),
        username=os.getenv('SPLUNK_USERNAME', 'admin'),
        password=os.getenv('SPLUNK_PASSWORD', 'changeme'),
        verify_ssl=False
    )
    
    if not connector.connect():
        print("Cannot connect to Splunk - skipping advanced examples")
        return
    
    # Example queries
    queries = [
        {
            'name': 'Index Statistics',
            'query': 'search index=_internal | stats count by index',
            'earliest': '-1h@h'
        },
        {
            'name': 'Error Analysis',
            'query': 'search index=* error OR failed | stats count by host',
            'earliest': '-24h@h'
        },
        {
            'name': 'Top Sourcetypes',
            'query': 'search index=* | stats count by sourcetype | sort -count | head 10',
            'earliest': '-1h@h'
        },
        {
            'name': 'Time Chart Example',
            'query': 'search index=_internal | timechart span=15m count',
            'earliest': '-4h@h'
        }
    ]
    
    for query_info in queries:
        print(f"\nExecuting: {query_info['name']}")
        print(f"Query: {query_info['query']}")
        
        try:
            results = connector.execute_query(
                query=query_info['query'],
                earliest_time=query_info['earliest'],
                latest_time='now',
                timeout=60
            )
            
            print(f"Results: {len(results)} rows")
            
            # Show first result if available
            if results:
                print("Sample result:")
                print(json.dumps(results[0], indent=2))
                
        except Exception as e:
            print(f"Query failed: {e}")

# Example 4: Error Handling and Retries
def example_error_handling():
    """Example showing error handling patterns"""
    print("\n=== Error Handling Example ===")
    
    # Example with invalid credentials
    bad_connector = create_username_password_connector(
        host='localhost',
        username='invalid',
        password='invalid',
        port=8089,
        max_retries=2,
        connection_cooldown=5
    )
    
    print("Testing with invalid credentials...")
    if not bad_connector.connect():
        print("✓ Properly handled invalid credentials")
        status = bad_connector.get_status()
        print(f"Connection attempts: {status['connection_attempts']}")
    
    # Example with connection timeout
    print("\nTesting query timeout handling...")
    # This would normally be a valid connector
    # connector.execute_query("search index=* | head 1000000", timeout=1)

# Example 5: Configuration from Environment
def example_env_config():
    """Example using environment variables for configuration"""
    print("\n=== Environment Configuration Example ===")
    
    # Check which auth method to use based on environment
    if os.getenv('SPLUNK_BEARER_TOKEN'):
        print("Using bearer token from environment")
        connector = create_bearer_token_connector(
            host=os.getenv('SPLUNK_HOST', 'localhost'),
            bearer_token=os.getenv('SPLUNK_BEARER_TOKEN'),
            port=int(os.getenv('SPLUNK_PORT', '8089')),
            verify_ssl=os.getenv('SPLUNK_VERIFY_SSL', 'false').lower() == 'true'
        )
    elif os.getenv('SPLUNK_USERNAME') and os.getenv('SPLUNK_PASSWORD'):
        print("Using username/password from environment")
        connector = create_username_password_connector(
            host=os.getenv('SPLUNK_HOST', 'localhost'),
            username=os.getenv('SPLUNK_USERNAME'),
            password=os.getenv('SPLUNK_PASSWORD'),
            port=int(os.getenv('SPLUNK_PORT', '8089')),
            verify_ssl=os.getenv('SPLUNK_VERIFY_SSL', 'false').lower() == 'true'
        )
    else:
        print("No Splunk credentials found in environment")
        print("Set either SPLUNK_BEARER_TOKEN or SPLUNK_USERNAME+SPLUNK_PASSWORD")
        return
    
    # Test the connection
    if connector.connect():
        print("✓ Connected using environment configuration")
        
        # Quick test query
        results = connector.execute_query('search index=_internal | head 1')
        print(f"Test query successful: {len(results)} results")
        
    else:
        print("✗ Connection failed with environment configuration")

# Example 6: Batch Query Processing
def example_batch_processing():
    """Example showing how to process multiple queries efficiently"""
    print("\n=== Batch Query Processing Example ===")
    
    connector = create_username_password_connector(
        host=os.getenv('SPLUNK_HOST', 'localhost'),
        username=os.getenv('SPLUNK_USERNAME', 'admin'),
        password=os.getenv('SPLUNK_PASSWORD', 'changeme')
    )
    
    if not connector.connect():
        print("Cannot connect - skipping batch processing example")
        return
    
    # Multiple queries to execute
    batch_queries = [
        {'name': 'Total Events', 'query': 'search index=_internal | stats count'},
        {'name': 'Unique Hosts', 'query': 'search index=_internal | stats dc(host)'},
        {'name': 'Recent Errors', 'query': 'search index=_internal error | head 10'},
        {'name': 'Index Sizes', 'query': '| rest /services/data/indexes | table title currentDBSizeMB'}
    ]
    
    results_summary = {}
    
    for query_info in batch_queries:
        print(f"Processing: {query_info['name']}")
        
        try:
            start_time = datetime.now()
            results = connector.execute_query(
                query=query_info['query'],
                earliest_time='-1h@h',
                timeout=30
            )
            end_time = datetime.now()
            execution_time = (end_time - start_time).total_seconds()
            
            results_summary[query_info['name']] = {
                'result_count': len(results),
                'execution_time': execution_time,
                'success': True
            }
            
        except Exception as e:
            results_summary[query_info['name']] = {
                'error': str(e),
                'success': False
            }
    
    # Print summary
    print("\nBatch Processing Summary:")
    print(json.dumps(results_summary, indent=2))

# Example 7: Standalone Script Usage
def example_standalone_script():
    """Example of using the connector in a standalone script"""
    print("\n=== Standalone Script Example ===")
    
    # This could be a separate monitoring script
    def monitor_splunk_health():
        try:
            connector = create_bearer_token_connector(
                host=os.getenv('SPLUNK_HOST', 'localhost'),
                bearer_token=os.getenv('SPLUNK_BEARER_TOKEN', 'dummy-token')
            )
            
            if connector.test_connection():
                # Check index health
                results = connector.execute_query(
                    'search index=_internal | stats count by index | sort -count'
                )
                
                health_data = {
                    'timestamp': datetime.now().isoformat(),
                    'connection_status': 'healthy',
                    'active_indexes': len(results),
                    'top_indexes': results[:5] if results else []
                }
                
                return health_data
            else:
                return {
                    'timestamp': datetime.now().isoformat(),
                    'connection_status': 'unhealthy',
                    'error': 'Cannot connect to Splunk'
                }
                
        except Exception as e:
            return {
                'timestamp': datetime.now().isoformat(),
                'connection_status': 'error',
                'error': str(e)
            }
    
    # Run the health check
    health = monitor_splunk_health()
    print("Splunk Health Monitor Result:")
    print(json.dumps(health, indent=2))

def main():
    """Run all examples"""
    print("Splunk Connector Usage Examples")
    print("=" * 50)
    
    # Note: Most examples will fail without proper Splunk credentials
    # This is intentional to show error handling
    
    try:
        example_username_password()
        example_bearer_token()
        example_advanced_queries()
        example_error_handling()
        example_env_config()
        example_batch_processing()
        example_standalone_script()
        
    except KeyboardInterrupt:
        print("\nExamples interrupted by user")
    except Exception as e:
        print(f"Example execution error: {e}")

if __name__ == '__main__':
    # Check if running as standalone
    if len(sys.argv) > 1 and sys.argv[1] == '--help':
        print("""
Splunk Connector Usage Examples

Environment Variables:
  SPLUNK_HOST        - Splunk server hostname
  SPLUNK_PORT        - Splunk server port (default: 8089)
  SPLUNK_USERNAME    - Username for username/password auth
  SPLUNK_PASSWORD    - Password for username/password auth
  SPLUNK_BEARER_TOKEN - Bearer token for token auth
  SPLUNK_VERIFY_SSL  - SSL verification (true/false)

Examples:
  python splunk_usage_examples.py                    # Run all examples
  python splunk_usage_examples.py --help            # Show this help
  
  # Set environment and run
  export SPLUNK_HOST=mysplunk.com
  export SPLUNK_USERNAME=admin  
  export SPLUNK_PASSWORD=changeme
  python splunk_usage_examples.py
  
  # Or with bearer token
  export SPLUNK_HOST=mysplunk.com
  export SPLUNK_BEARER_TOKEN=your-token-here
  python splunk_usage_examples.py
        """)
    else:
        main()