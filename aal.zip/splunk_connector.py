#!/usr/bin/env python3
"""
Independent Splunk Connector with Multiple Authentication Options

Supports:
1. Username/Password authentication (generates session key)
2. Bearer token authentication (direct API access)

Can be used as a standalone module or within a larger application.
"""

import time
import re
import requests
import json
import sys
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Union
from enum import Enum
import urllib3

# Optional environment loading - falls back gracefully if not available
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Optional structured logging - falls back to standard logging if not available
try:
    import structlog
    logger = structlog.get_logger()
except ImportError:
    import logging
    logging.basicConfig(level=logging.INFO)
    logger = logging.getLogger(__name__)

# Disable SSL warnings
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

class AuthMethod(Enum):
    """Authentication method options"""
    USERNAME_PASSWORD = "username_password"
    BEARER_TOKEN = "bearer_token"

class SplunkConnector:
    """
    Enhanced Splunk connector supporting multiple authentication methods
    
    Authentication Options:
    1. Username/Password: Traditional session-based auth
    2. Bearer Token: Direct API access with pre-generated token
    """
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """
        Initialize the Splunk connector
        
        Args:
            config: Configuration dictionary with the following options:
            
            Common settings:
            - host: Splunk server hostname
            - port: Splunk server port (default: 8089)
            - scheme: http or https (default: https)
            - verify_ssl: SSL verification (default: False)
            
            Username/Password auth:
            - auth_method: "username_password" (default)
            - username: Splunk username
            - password: Splunk password
            
            Bearer Token auth:
            - auth_method: "bearer_token"
            - bearer_token: Pre-generated bearer token
            - token_type: "Splunk" or "Bearer" (default: "Splunk")
            
            If config is None or missing values, will read from environment variables:
            SPLUNK_HOST, SPLUNK_PORT, SPLUNK_SCHEME, SPLUNK_USERNAME, SPLUNK_PASSWORD, etc.
        """
        # If no config provided, read from environment
        if config is None:
            config = {}
        
        # Merge config with environment variables (config takes priority)
        env_config = self._load_from_environment()
        merged_config = {**env_config, **config}
        
        self.config = self._validate_config(merged_config)
        self.base_url = f"{self.config['scheme']}://{self.config['host']}:{self.config['port']}"
        
        # Authentication method detection
        self.auth_method = AuthMethod(self.config.get('auth_method', 'username_password'))
        
        # Session-based auth attributes
        self.session_key = None
        self.session_expiry = None
        
        # Bearer token auth attributes  
        self.bearer_token = self.config.get('bearer_token')
        self.token_type = self.config.get('token_type', 'Splunk')
        
        # Connection management
        self.connection_attempts = 0
        self.max_retries = self.config.get('max_retries', 3)
        self.last_connection_attempt = None
        self.connection_cooldown = self.config.get('connection_cooldown', 30)
        
        # Create requests session for connection pooling
        self.session = requests.Session()
        self.session.verify = self.config.get('verify_ssl', False)
        
        self._log_initialization()
    
    def _load_from_environment(self) -> Dict[str, Any]:
        """Load configuration from environment variables"""
        env_config = {}
        
        # Map environment variables to config keys
        env_mappings = {
            'SPLUNK_HOST': 'host',
            'SPLUNK_PORT': 'port',
            'SPLUNK_SCHEME': 'scheme',
            'SPLUNK_USERNAME': 'username',
            'SPLUNK_PASSWORD': 'password',
            'SPLUNK_BEARER_TOKEN': 'bearer_token',
            'SPLUNK_TOKEN_TYPE': 'token_type',
            'SPLUNK_AUTH_METHOD': 'auth_method',
            'SPLUNK_VERIFY_SSL': 'verify_ssl',
            'SPLUNK_TIMEOUT': 'timeout',
            'SPLUNK_MAX_RETRIES': 'max_retries',
            'SPLUNK_CONNECTION_COOLDOWN': 'connection_cooldown'
        }
        
        for env_var, config_key in env_mappings.items():
            value = os.getenv(env_var)
            if value is not None:
                # Type conversion for specific fields
                if config_key in ['port', 'timeout', 'max_retries', 'connection_cooldown']:
                    try:
                        env_config[config_key] = int(value)
                    except ValueError:
                        self._log_warning(f"Invalid integer value for {env_var}: {value}")
                elif config_key == 'verify_ssl':
                    env_config[config_key] = value.lower() in ('true', '1', 'yes', 'on')
                else:
                    env_config[config_key] = value
        
        # Auto-detect auth method based on available credentials
        if 'auth_method' not in env_config:
            if env_config.get('bearer_token'):
                env_config['auth_method'] = 'bearer_token'
            elif env_config.get('username') and env_config.get('password'):
                env_config['auth_method'] = 'username_password'
        
        return env_config
    
    def _validate_config(self, config: Dict[str, Any]) -> Dict[str, Any]:
        """Validate and normalize configuration"""
        required_fields = ['host']
        
        for field in required_fields:
            if field not in config:
                raise ValueError(f"Required configuration field missing: {field}")
        
        # Set defaults
        normalized_config = {
            'host': config['host'],
            'port': config.get('port', 8089),
            'scheme': config.get('scheme', 'https'),
            'verify_ssl': config.get('verify_ssl', False),
            'auth_method': config.get('auth_method', 'username_password'),
            'max_retries': config.get('max_retries', 3),
            'connection_cooldown': config.get('connection_cooldown', 30),
            'timeout': config.get('timeout', 30)
        }
        
        # Auth method specific validation
        auth_method = normalized_config['auth_method']
        
        if auth_method == 'username_password':
            if not config.get('username') or not config.get('password'):
                self._log_warning("Username/password not provided - limited functionality")
            normalized_config.update({
                'username': config.get('username'),
                'password': config.get('password')
            })
            
        elif auth_method == 'bearer_token':
            if not config.get('bearer_token'):
                raise ValueError("Bearer token required for bearer_token auth method")
            normalized_config.update({
                'bearer_token': config['bearer_token'],
                'token_type': config.get('token_type', 'Splunk')
            })
            
        else:
            raise ValueError(f"Unsupported auth method: {auth_method}")
        
        return normalized_config
    
    def _log_initialization(self):
        """Log initialization details"""
        if hasattr(logger, 'info'):
            logger.info("SplunkConnector initialized", 
                       host=self.config['host'],
                       port=self.config['port'],
                       auth_method=self.auth_method.value,
                       verify_ssl=self.config['verify_ssl'])
        else:
            logger.info(f"SplunkConnector initialized - {self.config['host']}:{self.config['port']} - {self.auth_method.value}")
    
    def _log_info(self, message: str, **kwargs):
        """Unified logging interface"""
        if hasattr(logger, 'info'):
            logger.info(message, **kwargs)
        else:
            extra_info = " - ".join([f"{k}={v}" for k, v in kwargs.items()])
            logger.info(f"{message} - {extra_info}" if extra_info else message)
    
    def _log_warning(self, message: str, **kwargs):
        """Unified warning logging"""
        if hasattr(logger, 'warning'):
            logger.warning(message, **kwargs)
        else:
            extra_info = " - ".join([f"{k}={v}" for k, v in kwargs.items()])
            logger.warning(f"{message} - {extra_info}" if extra_info else message)
    
    def _log_error(self, message: str, **kwargs):
        """Unified error logging"""
        if hasattr(logger, 'error'):
            logger.error(message, **kwargs)
        else:
            extra_info = " - ".join([f"{k}={v}" for k, v in kwargs.items()])
            logger.error(f"{message} - {extra_info}" if extra_info else message)
    
    def should_attempt_connection(self) -> bool:
        """Check if we should attempt a connection based on cooldown"""
        if self.last_connection_attempt is None:
            return True
        return time.time() - self.last_connection_attempt > self.connection_cooldown
    
    def generate_session_key(self) -> bool:
        """Generate session key using username/password authentication"""
        if self.auth_method != AuthMethod.USERNAME_PASSWORD:
            self._log_error("Session key generation only available for username/password auth")
            return False
            
        if not self.config.get('username') or not self.config.get('password'):
            self._log_warning("No credentials available for session generation")
            return False
            
        if not self.should_attempt_connection():
            self._log_info("Session generation skipped due to cooldown")
            return False
            
        self.last_connection_attempt = time.time()
        auth_url = f"{self.base_url}/services/auth/login"
        
        try:
            auth_data = {
                'username': self.config['username'],
                'password': self.config['password'],
                'output_mode': 'json'
            }
            headers = {
                'Content-Type': 'application/x-www-form-urlencoded'
            }
            
            self._log_info("Generating Splunk session key",
                          url=auth_url,
                          username=self.config['username'])
            
            response = self.session.post(
                auth_url,
                data=auth_data,
                headers=headers,
                timeout=self.config['timeout']
            )
            
            if response.status_code != 200:
                self._log_error("Authentication failed",
                               status_code=response.status_code,
                               response_text=response.text[:200])
                return False
            
            auth_result = response.json()
            
            if 'sessionKey' in auth_result:
                self.session_key = auth_result['sessionKey']
                self.session_expiry = datetime.now() + timedelta(hours=1)
                
                self._log_info("Successfully generated session key",
                              session_key_prefix=self.session_key[:10] + "...",
                              expires_at=self.session_expiry.isoformat())
                return True
            else:
                self._log_error("No session key in authentication response", response=auth_result)
                return False
                
        except requests.exceptions.RequestException as e:
            self._log_error("Session generation request failed",
                           error=str(e),
                           error_type=type(e).__name__)
            return False
        except Exception as e:
            self._log_error("Unexpected session generation error",
                           error=str(e),
                           error_type=type(e).__name__)
            return False
    
    def is_session_valid(self) -> bool:
        """Check if current session is still valid"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return bool(self.bearer_token)
            
        if not self.session_key:
            return False
        
        if self.session_expiry and datetime.now() >= self.session_expiry:
            self._log_info("Session expired, need to re-authenticate")
            return False
        
        return True
    
    def ensure_valid_session(self) -> bool:
        """Ensure we have valid authentication before making API calls"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return bool(self.bearer_token)
            
        if not self.is_session_valid():
            self._log_info("Session invalid, generating new session...")
            return self.generate_session_key()
        return True
    
    def get_auth_headers(self) -> Dict[str, str]:
        """Get appropriate authentication headers based on auth method"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            return {
                'Authorization': f'{self.token_type} {self.bearer_token}',
                'Content-Type': 'application/x-www-form-urlencoded'
            }
        else:
            return {
                'Authorization': f'Splunk {self.session_key}',
                'Content-Type': 'application/x-www-form-urlencoded'
            }
    
    def test_authentication(self) -> bool:
        """Test authentication by running a simple search"""
        try:
            if not self.ensure_valid_session():
                return False
                
            search_url = f"{self.base_url}/services/search/jobs"
            
            # Simple test query
            search_data = {
                'search': 'search index=_internal | head 1',
                'output_mode': 'json',
                'exec_mode': 'blocking',
                'earliest_time': '-1m@m',
                'latest_time': 'now'
            }
            
            headers = self.get_auth_headers()
            
            self._log_info("Testing authentication with simple search")
            
            response = self.session.post(
                search_url,
                data=search_data,
                headers=headers,
                timeout=15
            )
            
            if response.status_code not in [200, 201]:
                self._log_error("Authentication test failed",
                               status_code=response.status_code,
                               response_text=response.text[:200])
                return False
                
            search_result = response.json()
            
            if 'sid' in search_result:
                self._log_info("Authentication test successful", sid=search_result['sid'])
                return True
            else:
                self._log_error("Authentication test failed - no SID returned")
                return False
                
        except Exception as e:
            self._log_error("Authentication test failed", error=str(e))
            return False
    
    def connect(self) -> bool:
        """Establish connection and test authentication"""
        if self.auth_method == AuthMethod.BEARER_TOKEN:
            if not self.bearer_token:
                self._log_error("No bearer token provided")
                return False
            return self.test_authentication()
        
        # Username/password authentication
        if not self.config.get('username') or not self.config.get('password'):
            self._log_warning("No credentials provided for username/password auth")
            return False
        
        while self.connection_attempts < self.max_retries:
            try:
                if not self.generate_session_key():
                    raise Exception("Failed to generate session key")
                
                if not self.test_authentication():
                    raise Exception("Authentication test failed")
                
                self._log_info("Successfully connected to Splunk",
                              auth_method=self.auth_method.value)
                self.connection_attempts = 0
                return True
                
            except Exception as e:
                self.connection_attempts += 1
                self._log_error("Failed to connect to Splunk",
                               error=str(e),
                               attempt=self.connection_attempts,
                               max_retries=self.max_retries)
                
                # Clear invalid session
                self.session_key = None
                self.session_expiry = None
                
                if self.connection_attempts < self.max_retries:
                    wait_time = min(2 ** self.connection_attempts, 10)
                    self._log_info(f"Retrying connection in {wait_time}s")
                    time.sleep(wait_time)
        
        self._log_error("Failed to connect after all retries")
        return False
    
    def execute_query(self, query: str, earliest_time: str = "-30d@d", 
                     latest_time: str = "now", timeout: int = None) -> List[Dict]:
        """
        Execute Splunk search query
        
        Args:
            query: Splunk search query
            earliest_time: Search start time (Splunk format)
            latest_time: Search end time (Splunk format)
            timeout: Query timeout in seconds
            
        Returns:
            List of search results
        """
        if timeout is None:
            timeout = self.config['timeout']
            
        if not self.ensure_valid_session():
            self._log_error("Cannot execute query - no valid authentication")
            return []
        
        start_time = time.time()
        
        try:
            # Security validation
            dangerous_keywords = ['delete', 'drop', 'insert', 'update', 'create', 'alter', 'eval', 'outputlookup']
            if any(keyword in query.lower() for keyword in dangerous_keywords):
                raise ValueError(f"Query contains potentially dangerous operations")
            
            # Ensure query starts with "search" command
            query = query.strip()
            if not query.lower().startswith('search '):
                query = f"search {query}"
            
            search_url = f"{self.base_url}/services/search/jobs"
            
            search_data = {
                'search': query,
                'output_mode': 'json',
                'exec_mode': 'blocking',
                'timeout': timeout,
                'earliest_time': earliest_time,
                'latest_time': latest_time,
                'max_count': 1000
            }
            
            headers = self.get_auth_headers()
            
            self._log_info("Executing Splunk query",
                          query_preview=query[:100],
                          earliest_time=earliest_time,
                          latest_time=latest_time,
                          auth_method=self.auth_method.value)
            
            response = self.session.post(
                search_url,
                data=search_data,
                headers=headers,
                timeout=timeout + 5
            )
            
            if response.status_code not in [200, 201]:
                error_details = response.text
                self._log_error("Query execution failed",
                               status_code=response.status_code,
                               response_text=error_details[:500])
                
                # Try to parse Splunk error message
                try:
                    error_json = response.json()
                    if 'messages' in error_json:
                        error_msg = error_json['messages'][0].get('text', 'Unknown error')
                        self._log_error("Splunk error details", error_message=error_msg)
                except:
                    pass
                    
                return []
            
            search_result = response.json()
            
            if 'sid' not in search_result:
                self._log_error("No SID in search response", response=search_result)
                return []
            
            job_sid = search_result['sid']
            self._log_info("Search job created successfully", job_sid=job_sid)
            
            # Get results using the SID
            results_url = f"{self.base_url}/services/search/jobs/{job_sid}/results"
            results_params = {
                'output_mode': 'json',
                'count': 1000
            }
            
            results_response = self.session.get(
                results_url,
                params=results_params,
                headers=headers,
                timeout=15
            )
            
            results_response.raise_for_status()
            results_data = results_response.json()
            
            results_list = results_data.get('results', [])
            
            execution_time = time.time() - start_time
            self._log_info("Query completed successfully",
                          results_count=len(results_list),
                          execution_time=f"{execution_time:.2f}s",
                          job_sid=job_sid)
            
            return results_list
            
        except requests.exceptions.Timeout as e:
            execution_time = time.time() - start_time
            self._log_error("Query timeout",
                           error=str(e),
                           execution_time=f"{execution_time:.2f}s",
                           timeout=timeout)
            return []
            
        except requests.exceptions.HTTPError as e:
            execution_time = time.time() - start_time
            
            if e.response.status_code == 401:
                self._log_warning("Authentication error, clearing session", error=str(e))
                if self.auth_method == AuthMethod.USERNAME_PASSWORD:
                    self.session_key = None
                    self.session_expiry = None
            elif e.response.status_code == 403:
                self._log_error("Permission denied", error=str(e))
            else:
                self._log_error("HTTP error executing Splunk query",
                               error=str(e),
                               status_code=e.response.status_code,
                               execution_time=f"{execution_time:.2f}s")
            
            return []
            
        except Exception as e:
            execution_time = time.time() - start_time
            error_type = type(e).__name__
            
            self._log_error("Error executing Splunk query",
                           error=str(e),
                           error_type=error_type,
                           execution_time=f"{execution_time:.2f}s")
            
            return []
    
    def get_status(self) -> Dict[str, Any]:
        """Get current connection status"""
        status = {
            'auth_method': self.auth_method.value,
            'connected': self.is_session_valid(),
            'base_url': self.base_url,
            'connection_attempts': self.connection_attempts,
            'last_connection_attempt': self.last_connection_attempt
        }
        
        if self.auth_method == AuthMethod.USERNAME_PASSWORD:
            status.update({
                'has_session_key': bool(self.session_key),
                'session_key_prefix': self.session_key[:10] + "..." if self.session_key else None,
                'session_expiry': self.session_expiry.isoformat() if self.session_expiry else None,
                'username': self.config.get('username')
            })
        else:
            status.update({
                'has_bearer_token': bool(self.bearer_token),
                'token_type': self.token_type,
                'bearer_token_prefix': self.bearer_token[:10] + "..." if self.bearer_token else None
            })
        
        return status
    
    def test_connection(self) -> bool:
        """Test connection with minimal overhead"""
        try:
            if not self.ensure_valid_session():
                return False
            return self.test_authentication()
        except Exception as e:
            self._log_error("Connection test failed", error=str(e))
            return False

# Convenience functions for standalone usage
def create_from_environment(**kwargs) -> SplunkConnector:
    """
    Create a Splunk connector using environment variables
    
    Reads configuration from environment variables:
    - SPLUNK_HOST: Splunk server hostname
    - SPLUNK_PORT: Splunk server port (default: 8089)
    - SPLUNK_SCHEME: Connection scheme (default: https)
    - SPLUNK_USERNAME: Splunk username (for username/password auth)
    - SPLUNK_PASSWORD: Splunk password (for username/password auth)
    - SPLUNK_BEARER_TOKEN: Bearer token (for token auth)
    - SPLUNK_TOKEN_TYPE: Token type prefix (default: 'Splunk')
    - SPLUNK_AUTH_METHOD: Authentication method (auto-detected if not set)
    - SPLUNK_VERIFY_SSL: SSL verification (default: false)
    - SPLUNK_TIMEOUT: Query timeout (default: 30)
    
    Args:
        **kwargs: Additional configuration options to override environment
        
    Returns:
        Configured SplunkConnector instance
    """
    return SplunkConnector(kwargs)

def create_username_password_connector(host: str, username: str, password: str, 
                                      port: int = 8089, scheme: str = 'https', 
                                      verify_ssl: bool = False, **kwargs) -> SplunkConnector:
    """
    Create a Splunk connector using username/password authentication
    
    Args:
        host: Splunk server hostname
        username: Splunk username
        password: Splunk password
        port: Splunk server port (default: 8089)
        scheme: Connection scheme (default: https)
        verify_ssl: SSL verification (default: False)
        **kwargs: Additional configuration options
        
    Returns:
        Configured SplunkConnector instance
    """
    config = {
        'host': host,
        'port': port,
        'scheme': scheme,
        'verify_ssl': verify_ssl,
        'auth_method': 'username_password',
        'username': username,
        'password': password,
        **kwargs
    }
    return SplunkConnector(config)

def create_bearer_token_connector(host: str, bearer_token: str,
                                 port: int = 8089, scheme: str = 'https',
                                 verify_ssl: bool = False, token_type: str = 'Splunk',
                                 **kwargs) -> SplunkConnector:
    """
    Create a Splunk connector using bearer token authentication
    
    Args:
        host: Splunk server hostname
        bearer_token: Pre-generated bearer token
        port: Splunk server port (default: 8089)
        scheme: Connection scheme (default: https)
        verify_ssl: SSL verification (default: False)
        token_type: Token type prefix (default: 'Splunk')
        **kwargs: Additional configuration options
        
    Returns:
        Configured SplunkConnector instance
    """
    config = {
        'host': host,
        'port': port,
        'scheme': scheme,
        'verify_ssl': verify_ssl,
        'auth_method': 'bearer_token',
        'bearer_token': bearer_token,
        'token_type': token_type,
        **kwargs
    }
    return SplunkConnector(config)

# Standalone usage example and testing
def main():
    """Example standalone usage"""
    import argparse
    
    parser = argparse.ArgumentParser(description='Splunk Connector Standalone Test')
    parser.add_argument('--host', help='Splunk host (or set SPLUNK_HOST env var)')
    parser.add_argument('--port', type=int, default=8089, help='Splunk port')
    parser.add_argument('--scheme', default='https', help='Connection scheme')
    
    # Authentication options
    auth_group = parser.add_mutually_exclusive_group()
    auth_group.add_argument('--username-password', nargs=2, metavar=('USERNAME', 'PASSWORD'),
                           help='Username and password for authentication')
    auth_group.add_argument('--bearer-token', help='Bearer token for authentication')
    auth_group.add_argument('--use-env', action='store_true', 
                           help='Use environment variables for configuration')
    
    parser.add_argument('--query', default='search index=_internal | head 5',
                       help='Test query to execute')
    parser.add_argument('--verify-ssl', action='store_true', help='Verify SSL certificates')
    
    args = parser.parse_args()
    
    try:
        # Create connector based on auth method
        if args.use_env or (not args.username_password and not args.bearer_token):
            print("Using environment variables for configuration")
            connector = create_from_environment()
        elif args.username_password:
            username, password = args.username_password
            host = args.host or os.getenv('SPLUNK_HOST', 'localhost')
            connector = create_username_password_connector(
                host=host,
                username=username,
                password=password,
                port=args.port,
                scheme=args.scheme,
                verify_ssl=args.verify_ssl
            )
        else:
            host = args.host or os.getenv('SPLUNK_HOST', 'localhost')
            connector = create_bearer_token_connector(
                host=host,
                bearer_token=args.bearer_token,
                port=args.port,
                scheme=args.scheme,
                verify_ssl=args.verify_ssl
            )
        
        print(f"Testing connection to {connector.config['host']}:{connector.config['port']}")
        
        # Test connection
        if connector.connect():
            print("✓ Connection successful")
            
            # Test query
            print(f"Executing test query: {args.query}")
            results = connector.execute_query(args.query, "-1h@h", "now", 30)
            
            print(f"✓ Query executed successfully, {len(results)} results returned")
            
            if results:
                print("Sample result:")
                print(json.dumps(results[0], indent=2))
            
            # Show status
            status = connector.get_status()
            print("\nConnection Status:")
            print(json.dumps(status, indent=2, default=str))
            
        else:
            print("✗ Connection failed")
            sys.exit(1)
            
    except KeyboardInterrupt:
        print("\nInterrupted by user")
        sys.exit(0)
    except Exception as e:
        print(f"Error: {e}")
        sys.exit(1)

if __name__ == '__main__':
    main()