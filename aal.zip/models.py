from marshmallow import Schema, fields, ValidationError

class DashboardQuerySchema(Schema):
    """Schema for dashboard query validation"""
    time_range = fields.Str(
        load_default='30d', 
        validate=lambda x: x in ['1d', '7d', '30d', '90d'],
        metadata={'description': 'Time range for the query'}
    )
    environment = fields.Str(
        load_default='prod', 
        validate=lambda x: x in ['prod', 'staging', 'dev'],
        metadata={'description': 'Environment to query'}
    )
    api_filter = fields.Str(
        load_default='',
        metadata={'description': 'Optional API name filter'}
    )

class CustomQuerySchema(Schema):
    """Schema for custom Splunk query validation"""
    query = fields.Str(
        required=True,
        metadata={'description': 'Splunk search query'}
    )
    time_range = fields.Str(
        load_default='30d',
        validate=lambda x: x in ['1d', '7d', '30d', '90d'],
        metadata={'description': 'Time range for the query'}
    )
    environment = fields.Str(
        load_default='prod',
        validate=lambda x: x in ['prod', 'staging', 'dev'],
        metadata={'description': 'Environment to query'}
    )
    earliest_time = fields.Str(
        load_default='-30d@d',
        metadata={'description': 'Earliest time for search (Splunk format)'}
    )
    latest_time = fields.Str(
        load_default='now',
        metadata={'description': 'Latest time for search (Splunk format)'}
    )
    timeout = fields.Int(
        load_default=30,
        validate=lambda x: 5 <= x <= 300,
        metadata={'description': 'Query timeout in seconds'}
    )

class ExportQuerySchema(Schema):
    """Schema for export request validation"""
    format = fields.Str(
        required=True,
        validate=lambda x: x in ['json', 'csv', 'pdf'],
        metadata={'description': 'Export format'}
    )
    time_range = fields.Str(
        load_default='30d',
        validate=lambda x: x in ['1d', '7d', '30d', '90d']
    )
    environment = fields.Str(
        load_default='prod',
        validate=lambda x: x in ['prod', 'staging', 'dev']
    )
    include_metadata = fields.Bool(
        load_default=True,
        metadata={'description': 'Include metadata in export'}
    )