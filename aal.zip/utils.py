import io
import os
from datetime import datetime
from typing import Dict, Any, List
import pandas as pd
import structlog

# PDF Generation
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors

# Initialize logger
logger = structlog.get_logger()

def create_directories():
    """Create necessary directories for the application"""
    directories = ['templates', 'static', 'logs', 'exports']
    
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            logger.debug(f"Directory ensured: {directory}")
        except Exception as e:
            logger.error(f"Failed to create directory {directory}", error=str(e))

def format_number(value, format_type='auto'):
    """Format numbers for display"""
    try:
        if isinstance(value, str):
            # Try to extract number from string
            import re
            number_match = re.search(r'[\d.]+', value)
            if number_match:
                value = float(number_match.group())
            else:
                return value
        
        if not isinstance(value, (int, float)):
            return str(value)
        
        if format_type == 'auto':
            if value >= 1000000:
                return f"{value/1000000:.1f}M"
            elif value >= 1000:
                return f"{value/1000:.1f}K"
            else:
                return str(int(value))
        elif format_type == 'percentage':
            return f"{value:.1f}%"
        elif format_type == 'currency':
            return f"${value:,.2f}"
        elif format_type == 'time_ms':
            return f"{value:.0f}ms"
        else:
            return str(value)
            
    except Exception as e:
        logger.error("Error formatting number", value=value, format_type=format_type, error=str(e))
        return str(value)

def export_to_csv(data: Dict[str, Any], filename: str = None) -> io.StringIO:
    """Export dashboard data to CSV format"""
    try:
        output = io.StringIO()
        
        # Write metadata
        metadata = data.get('metadata', {})
        output.write("# ICoE Integration Landscape Dashboard Export\n")
        output.write(f"# Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        output.write(f"# Time Range: {metadata.get('time_range', 'N/A')}\n")
        output.write(f"# Environment: {metadata.get('environment', 'N/A')}\n")
        output.write("\n")
        
        # Write KPI data
        output.write("## Key Performance Indicators\n")
        output.write("Metric,Value\n")
        stats = data.get('stats', {})
        for key, value in stats.items():
            output.write(f"{key.replace('_', ' ').title()},{value}\n")
        
        # Write top APIs data
        output.write("\n## Top APIs by Consumers\n")
        output.write("API Name,Consumers\n")
        top_apis = data.get('top_apis_by_consumers', {})
        for api, count in zip(top_apis.get('labels', []), top_apis.get('data', [])):
            output.write(f"{api},{count}\n")
        
        # Write OU usage data
        output.write("\n## Organization Unit API Usage\n")
        output.write("Organization Unit,API Usage\n")
        ou_usage = data.get('ou_api_usage', {})
        for ou, count in zip(ou_usage.get('labels', []), ou_usage.get('data', [])):
            output.write(f"{ou},{count}\n")
        
        # Write error analysis data
        output.write("\n## Error Analysis\n")
        output.write("Error Type,Count\n")
        error_analysis = data.get('error_analysis', {})
        for error, count in zip(error_analysis.get('labels', []), error_analysis.get('data', [])):
            output.write(f"{error},{count}\n")
        
        output.seek(0)
        return output
        
    except Exception as e:
        logger.error("Error exporting to CSV", error=str(e))
        raise

def export_to_pdf(data: Dict[str, Any], filename: str = None) -> io.BytesIO:
    """Export dashboard data to PDF format"""
    try:
        buffer = io.BytesIO()
        doc = SimpleDocTemplate(buffer, pagesize=letter)
        styles = getSampleStyleSheet()
        elements = []
        
        # Title
        title = Paragraph("ICoE Integration Landscape Dashboard Report", styles['Title'])
        elements.append(title)
        elements.append(Spacer(1, 20))
        
        # Metadata
        metadata = data.get('metadata', {})
        elements.append(Paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}", styles['Normal']))
        elements.append(Paragraph(f"Time Range: {metadata.get('time_range', 'N/A')}", styles['Normal']))
        elements.append(Paragraph(f"Environment: {metadata.get('environment', 'N/A')}", styles['Normal']))
        elements.append(Paragraph(f"Data Source: {metadata.get('data_source', 'N/A')}", styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # Executive Summary
        elements.append(Paragraph("Executive Summary", styles['Heading1']))
        stats = data.get('stats', {})
        summary_text = f"""
        This report provides an overview of the API landscape for the specified time period. 
        Key findings include {stats.get('total_apis', 'N/A')} total APIs serving 
        {stats.get('total_consumers', 'N/A')} consumers with an average response time of 
        {stats.get('avg_response_time', 'N/A')} and an error rate of {stats.get('error_rate', 'N/A')}.
        """
        elements.append(Paragraph(summary_text, styles['Normal']))
        elements.append(Spacer(1, 20))
        
        # KPI Table
        elements.append(Paragraph("Key Performance Indicators", styles['Heading1']))
        kpi_data = [['Metric', 'Value']]
        for key, value in stats.items():
            kpi_data.append([key.replace('_', ' ').title(), str(value)])
        
        kpi_table = Table(kpi_data)
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        elements.append(kpi_table)
        elements.append(Spacer(1, 20))
        
        # Top APIs Table
        elements.append(Paragraph("Top APIs by Consumer Count", styles['Heading1']))
        top_apis = data.get('top_apis_by_consumers', {})
        api_data = [['API Name', 'Consumer Count']]
        for api, count in zip(top_apis.get('labels', [])[:10], top_apis.get('data', [])[:10]):
            api_data.append([str(api), str(count)])
        
        if len(api_data) > 1:
            api_table = Table(api_data)
            api_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            elements.append(api_table)
        elements.append(Spacer(1, 20))
        
        # OU Usage Table
        elements.append(Paragraph("Organization Unit API Usage", styles['Heading1']))
        ou_usage = data.get('ou_api_usage', {})
        ou_data = [['Organization Unit', 'API Usage Count']]
        for ou, count in zip(ou_usage.get('labels', []), ou_usage.get('data', [])):
            ou_data.append([str(ou), str(count)])
        
        if len(ou_data) > 1:
            ou_table = Table(ou_data)
            ou_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, 0), 12),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            elements.append(ou_table)
        
        # Build PDF
        doc.build(elements)
        buffer.seek(0)
        return buffer
        
    except Exception as e:
        logger.error("Error exporting to PDF", error=str(e))
        raise

def validate_time_range(time_range: str) -> bool:
    """Validate time range parameter"""
    valid_ranges = ['1d', '7d', '30d', '90d']
    return time_range in valid_ranges

def validate_environment(environment: str) -> bool:
    """Validate environment parameter"""
    valid_environments = ['prod', 'staging', 'dev']
    return environment in valid_environments

def sanitize_query(query: str) -> str:
    """Sanitize Splunk query for security"""
    try:
        # Remove potentially dangerous commands
        dangerous_patterns = [
            'delete', 'drop', 'insert', 'update', 'create', 'alter', 
            'eval', 'outputlookup', 'script', 'sendemail', 'rest'
        ]
        
        query_lower = query.lower()
        for pattern in dangerous_patterns:
            if pattern in query_lower:
                logger.warning("Dangerous pattern detected in query", pattern=pattern)
                raise ValueError(f"Query contains dangerous pattern: {pattern}")
        
        # Ensure query has reasonable length
        if len(query) > 5000:
            raise ValueError("Query too long")
        
        return query.strip()
        
    except Exception as e:
        logger.error("Error sanitizing query", error=str(e))
        raise

def calculate_cache_key_hash(data: Dict[str, Any]) -> str:
    """Calculate a hash for cache key generation"""
    import hashlib
    import json
    
    try:
        # Sort keys for consistent hashing
        sorted_data = json.dumps(data, sort_keys=True)
        return hashlib.md5(sorted_data.encode()).hexdigest()[:8]
    except Exception as e:
        logger.error("Error calculating cache key hash", error=str(e))
        return "fallback"

def parse_time_range_to_splunk(time_range: str) -> tuple:
    """Convert time range to Splunk earliest/latest format"""
    time_map = {
        '1d': ('-1d@d', 'now'),
        '7d': ('-7d@d', 'now'),
        '30d': ('-30d@d', 'now'),
        '90d': ('-90d@d', 'now')
    }
    
    return time_map.get(time_range, ('-30d@d', 'now'))

def format_response_time(milliseconds: float) -> str:
    """Format response time for display"""
    try:
        if milliseconds < 1000:
            return f"{milliseconds:.0f}ms"
        elif milliseconds < 60000:
            return f"{milliseconds/1000:.1f}s"
        else:
            return f"{milliseconds/60000:.1f}m"
    except Exception:
        return "0ms"

def calculate_percentage(part: float, total: float) -> str:
    """Calculate percentage with safe division"""
    try:
        if total == 0:
            return "0.00%"
        percentage = (part / total) * 100
        return f"{percentage:.2f}%"
    except Exception:
        return "0.00%"

def chunk_list(data: List, chunk_size: int = 100) -> List[List]:
    """Split list into smaller chunks"""
    try:
        return [data[i:i + chunk_size] for i in range(0, len(data), chunk_size)]
    except Exception as e:
        logger.error("Error chunking list", error=str(e))
        return [data]

def safe_json_loads(json_string: str, default=None):
    """Safely parse JSON string"""
    try:
        import json
        return json.loads(json_string)
    except Exception as e:
        logger.warning("Failed to parse JSON", error=str(e))
        return default or {}

def measure_execution_time(func):
    """Decorator to measure function execution time"""
    from functools import wraps
    import time
    
    @wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug("Function executed", 
                        function=func.__name__,
                        execution_time=f"{execution_time:.3f}s")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error("Function failed", 
                        function=func.__name__,
                        execution_time=f"{execution_time:.3f}s",
                        error=str(e))
            raise
    return wrapper

def retry_on_failure(max_retries: int = 3, delay: float = 1.0):
    """Decorator to retry function on failure"""
    from functools import wraps
    import time
    
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            last_exception = None
            
            for attempt in range(max_retries):
                try:
                    return func(*args, **kwargs)
                except Exception as e:
                    last_exception = e
                    if attempt < max_retries - 1:
                        logger.warning("Function failed, retrying", 
                                     function=func.__name__,
                                     attempt=attempt + 1,
                                     max_retries=max_retries,
                                     error=str(e))
                        time.sleep(delay * (2 ** attempt))  # Exponential backoff
                    else:
                        logger.error("Function failed after all retries", 
                                   function=func.__name__,
                                   max_retries=max_retries,
                                   error=str(e))
            
            raise last_exception
        return wrapper
    return decorator

def get_system_info() -> Dict[str, Any]:
    """Get system information for monitoring"""
    try:
        import psutil
        import platform
        
        return {
            'platform': platform.system(),
            'python_version': platform.python_version(),
            'cpu_percent': psutil.cpu_percent(),
            'memory_percent': psutil.virtual_memory().percent,
            'disk_percent': psutil.disk_usage('/').percent,
            'timestamp': datetime.now().isoformat()
        }
    except ImportError:
        # psutil not available
        return {
            'platform': 'unknown',
            'python_version': 'unknown',
            'timestamp': datetime.now().isoformat()
        }
    except Exception as e:
        logger.error("Error getting system info", error=str(e))
        return {
            'error': str(e),
            'timestamp': datetime.now().isoformat()
        }