# PostgreSQL Setup Guide

This guide helps you set up PostgreSQL for the API Migration Tool in both development and production environments.

## 🐘 PostgreSQL Installation

### Local Development

#### Windows
```bash
# Download from https://www.postgresql.org/download/windows/
# Or use Chocolatey
choco install postgresql

# Or use Docker
docker run --name postgres-migration \
  -e POSTGRES_PASSWORD=mypassword \
  -e POSTGRES_DB=api_migration_db \
  -p 5432:5432 \
  -d postgres:15
```

#### macOS
```bash
# Using Homebrew
brew install postgresql@15
brew services start postgresql@15

# Or using Docker
docker run --name postgres-migration \
  -e POSTGRES_PASSWORD=mypassword \
  -e POSTGRES_DB=api_migration_db \
  -p 5432:5432 \
  -d postgres:15
```

#### Linux (Ubuntu/Debian)
```bash
# Install PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Start PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

## 🔧 Database Configuration

### 1. Create Database and User

```sql
-- Connect as postgres superuser
sudo -u postgres psql

-- Create database
CREATE DATABASE api_migration_db;

-- Create user
CREATE USER api_user WITH PASSWORD 'your_secure_password';

-- Grant privileges
GRANT ALL PRIVILEGES ON DATABASE api_migration_db TO api_user;

-- Grant schema privileges
\c api_migration_db
GRANT ALL ON SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO api_user;

-- Exit
\q
```

### 2. Configure Environment Variables

Create or update your `.env` file:

```bash
# PostgreSQL Configuration
DATABASE_URL=postgresql://api_user:your_secure_password@localhost:5432/api_migration_db

# Or use individual components
DB_TYPE=postgresql
DB_HOST=localhost
DB_PORT=5432
DB_NAME=api_migration_db
DB_USER=api_user
DB_PASSWORD=your_secure_password

# Connection Pool Settings
DB_POOL_SIZE=10
DB_MAX_OVERFLOW=20
DB_POOL_TIMEOUT=30
DB_POOL_RECYCLE=3600
```

### 3. Install Python Dependencies

```bash
# Install PostgreSQL adapter
pip install psycopg2-binary

# Or install from requirements.txt (already included)
pip install -r requirements.txt
```

## 🚀 Production Setup

### Azure Database for PostgreSQL

```bash
# Create Azure PostgreSQL server
az postgres server create \
  --resource-group myResourceGroup \
  --name mypostgresqlserver \
  --location westus2 \
  --admin-user myadmin \
  --admin-password myPassword123! \
  --sku-name GP_Gen5_2

# Create database
az postgres db create \
  --resource-group myResourceGroup \
  --server-name mypostgresqlserver \
  --name api_migration_db

# Get connection string
az postgres show-connection-string \
  --server-name mypostgresqlserver \
  --database-name api_migration_db \
  --admin-user myadmin \
  --admin-password myPassword123!
```

Environment configuration for Azure:
```bash
DATABASE_URL=postgresql://myadmin@mypostgresqlserver:myPassword123!@mypostgresqlserver.postgres.database.azure.com:5432/api_migration_db?sslmode=require
```

### AWS RDS PostgreSQL

```bash
# Create RDS instance using AWS CLI
aws rds create-db-instance \
  --db-instance-identifier api-migration-db \
  --db-instance-class db.t3.micro \
  --engine postgres \
  --master-username dbadmin \
  --master-user-password myPassword123! \
  --allocated-storage 20 \
  --db-name api_migration_db
```

Environment configuration for AWS:
```bash
DATABASE_URL=postgresql://dbadmin:myPassword123!@api-migration-db.xxxxxx.us-east-1.rds.amazonaws.com:5432/api_migration_db
```

### Google Cloud SQL

```bash
# Create Cloud SQL instance
gcloud sql instances create api-migration-db \
  --database-version=POSTGRES_14 \
  --tier=db-f1-micro \
  --region=us-central1

# Create database
gcloud sql databases create api_migration_db \
  --instance=api-migration-db

# Create user
gcloud sql users create api_user \
  --instance=api-migration-db \
  --password=myPassword123!
```

## 🔧 Database Initialization

### 1. Create Database Schema

```bash
# Run the database creation script
python create_database.py
```

The script will:
- ✅ Check PostgreSQL connectivity
- ✅ Create database if it doesn't exist
- ✅ Create all required tables
- ✅ Optionally add sample data

### 2. Manual Database Creation

If you prefer to create the database manually:

```bash
# Create database
createdb -U postgres api_migration_db

# Run the Flask application to create tables
python app.py
```

## 📊 Database Management

### Backup and Restore

#### Backup
```bash
# Create backup
pg_dump -U api_user -h localhost api_migration_db > backup.sql

# Or with custom format
pg_dump -U api_user -h localhost -Fc api_migration_db > backup.dump
```

#### Restore
```bash
# Restore from SQL file
psql -U api_user -h localhost api_migration_db < backup.sql

# Or from custom format
pg_restore -U api_user -h localhost -d api_migration_db backup.dump
```

### Monitoring

#### Check Database Status
```sql
-- Connect to database
psql -U api_user -h localhost -d api_migration_db

-- Check table sizes
SELECT 
    schemaname,
    tablename,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC;

-- Check active connections
SELECT count(*) FROM pg_stat_activity;

-- Check recent migrations
SELECT 
    api_name, 
    status, 
    created_at 
FROM migration_records 
ORDER BY created_at DESC 
LIMIT 10;
```

#### Performance Monitoring
```sql
-- Check slow queries
SELECT 
    query,
    mean_time,
    calls
FROM pg_stat_statements 
ORDER BY mean_time DESC 
LIMIT 10;
```

## 🔒 Security Configuration

### SSL Configuration

For production, enable SSL connections:

```bash
# In postgresql.conf
ssl = on
ssl_cert_file = 'server.crt'
ssl_key_file = 'server.key'

# In pg_hba.conf
hostssl all all 0.0.0.0/0 md5
```

Environment configuration with SSL:
```bash
DATABASE_URL=postgresql://api_user:password@localhost:5432/api_migration_db?sslmode=require
```

### Connection Limits

```sql
-- Set connection limit for user
ALTER USER api_user CONNECTION LIMIT 20;

-- Check current connections
SELECT 
    usename,
    count(*) 
FROM pg_stat_activity 
GROUP BY usename;
```

## 🐛 Troubleshooting

### Common Issues

#### Connection Refused
```bash
# Check if PostgreSQL is running
sudo systemctl status postgresql

# Start if not running
sudo systemctl start postgresql

# Check port
netstat -ln | grep 5432
```

#### Authentication Failed
```bash
# Check pg_hba.conf authentication method
sudo cat /etc/postgresql/15/main/pg_hba.conf

# Restart after changes
sudo systemctl restart postgresql
```

#### Permission Denied
```sql
-- Grant necessary permissions
GRANT ALL PRIVILEGES ON DATABASE api_migration_db TO api_user;
GRANT ALL ON SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO api_user;
```

### Connection Testing

Test your PostgreSQL connection:

```python
# Test script
import psycopg2
from urllib.parse import urlparse

DATABASE_URL = "postgresql://api_user:password@localhost:5432/api_migration_db"

try:
    parsed = urlparse(DATABASE_URL)
    conn = psycopg2.connect(
        host=parsed.hostname,
        port=parsed.port,
        user=parsed.username,
        password=parsed.password,
        database=parsed.path[1:]
    )
    print("✅ PostgreSQL connection successful!")
    conn.close()
except Exception as e:
    print(f"❌ Connection failed: {e}")
```

## 📈 Performance Optimization

### Index Creation

```sql
-- Create indexes for better performance
CREATE INDEX idx_migration_records_status ON migration_records(status);
CREATE INDEX idx_migration_records_created_at ON migration_records(created_at);
CREATE INDEX idx_migration_records_api_name ON migration_records(api_name);
CREATE INDEX idx_api_specifications_format ON api_specifications(format);
CREATE INDEX idx_migration_logs_migration_id ON migration_logs(migration_id);
```

### Connection Pooling

The application automatically configures connection pooling for PostgreSQL:

```python
# Configured in config.py
SQLALCHEMY_ENGINE_OPTIONS = {
    'pool_size': 10,          # Number of connections to maintain
    'max_overflow': 20,       # Additional connections allowed
    'pool_timeout': 30,       # Timeout for getting connection
    'pool_recycle': 3600,     # Recycle connections after 1 hour
    'pool_pre_ping': True,    # Verify connections before use
}
```

## 🔄 Migration from SQLite

If you're migrating from SQLite to PostgreSQL:

```bash
# 1. Export data from SQLite
python -c "
import sqlite3
import json
conn = sqlite3.connect('migrations.db')
conn.row_factory = sqlite3.Row

# Export migration records
cursor = conn.execute('SELECT * FROM migration_records')
migrations = [dict(row) for row in cursor.fetchall()]
with open('migrations_export.json', 'w') as f:
    json.dump(migrations, f, default=str)
conn.close()
"

# 2. Set up PostgreSQL and create tables
python create_database.py

# 3. Import data to PostgreSQL
python -c "
import json
from app import app
from models.database import db, MigrationRecord

with open('migrations_export.json', 'r') as f:
    migrations = json.load(f)

with app.app_context():
    for migration_data in migrations:
        migration = MigrationRecord(**migration_data)
        db.session.add(migration)
    db.session.commit()
print('Migration data imported successfully!')
"
```

## ✅ Quick Setup Checklist

- [ ] PostgreSQL installed and running
- [ ] Database and user created
- [ ] Environment variables configured
- [ ] Python dependencies installed (`psycopg2-binary`)
- [ ] Database tables created (`python create_database.py`)
- [ ] Connection tested successfully
- [ ] Application started with PostgreSQL

Your API Migration Tool is now ready to use PostgreSQL! 🎉