#!/usr/bin/env python3
"""
Test script for Azure APIM connection
Run this to debug your Azure APIM connector
"""
import os
import sys
import json
from dotenv import load_dotenv

# Add your project root to path
sys.path.append('.')

# Load environment variables
load_dotenv()

def test_azure_apim_connection():
    """Test Azure APIM connection step by step"""
    print("🔍 Testing Azure APIM Connection...")
    print("=" * 50)
    
    # 1. Check environment variables
    print("1. Checking Environment Variables:")
    required_vars = [
        'AZURE_CLIENT_ID',
        'AZURE_CLIENT_SECRET', 
        'AZURE_TENANT_ID',
        'AZURE_SUBSCRIPTION_ID',
        'AZURE_APIM_RESOURCE_GROUP',
        'AZURE_APIM_SERVICE_NAME'
    ]
    
    missing_vars = []
    for var in required_vars:
        value = os.getenv(var)
        if value:
            if 'SECRET' in var or 'KEY' in var:
                print(f"   ✅ {var}: {'*' * (len(value) - 4) + value[-4:]}")
            else:
                print(f"   ✅ {var}: {value}")
        else:
            print(f"   ❌ {var}: NOT SET")
            missing_vars.append(var)
    
    if missing_vars:
        print(f"\n❌ Missing variables: {missing_vars}")
        return False
    
    print("\n2. Testing Azure APIM Connector:")
    try:
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        # Initialize connector
        connector = AzureAPIMConnector()
        print(f"   ✅ Connector initialized: Available = {connector.is_available}")
        
        if not connector.is_available:
            print("   ❌ Connector not available - check initialization")
            return False
        
        # Test connection
        connection_result = connector.test_connection()
        print(f"   Connection test: {connection_result}")
        
        if connection_result['status'] != 'success':
            print(f"   ❌ Connection failed: {connection_result['message']}")
            return False
        
        print("   ✅ Connection successful!")
        
        # Test listing APIs
        print("\n3. Testing API listing:")
        try:
            apis = connector.list_apis()
            print(f"   ✅ Found {len(apis)} existing APIs")
            for api in apis[:3]:  # Show first 3
                print(f"      - {api['display_name']} (ID: {api['id']})")
        except Exception as e:
            print(f"   ⚠️  API listing failed: {e}")
        
        return True
        
    except ImportError as e:
        print(f"   ❌ Failed to import connector: {e}")
        return False
    except Exception as e:
        print(f"   ❌ Connector test failed: {e}")
        return False

def test_sample_api_creation():
    """Test creating a sample API"""
    print("\n4. Testing Sample API Creation:")
    
    try:
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        
        if not connector.is_available:
            print("   ❌ Connector not available")
            return False
        
        # Sample OpenAPI 3.0 spec
        sample_spec = {
            "openapi": "3.0.0",
            "info": {
                "title": "Test API Migration",
                "version": "1.0.0",
                "description": "Test API for migration debugging"
            },
            "servers": [
                {
                    "url": "https://api.example.com",
                    "description": "Test server"
                }
            ],
            "paths": {
                "/test": {
                    "get": {
                        "summary": "Test endpoint",
                        "responses": {
                            "200": {
                                "description": "Success"
                            }
                        }
                    }
                }
            }
        }
        
        print("   Creating test API...")
        result = connector.create_api_from_openapi(sample_spec, "test-migration-api")
        
        print(f"   Creation result: {result}")
        
        if result['status'] == 'success':
            print("   ✅ Test API created successfully!")
            
            # Clean up - delete the test API
            print("   Cleaning up test API...")
            delete_result = connector.delete_api("test-migration-api")
            print(f"   Cleanup result: {delete_result}")
            
            return True
        else:
            print(f"   ❌ Test API creation failed: {result['message']}")
            return False
            
    except Exception as e:
        print(f"   ❌ Test API creation error: {e}")
        import traceback
        traceback.print_exc()
        return False

def main():
    """Run all tests"""
    print("🚀 Azure APIM Diagnostic Tests")
    print("=" * 50)
    
    success = True
    
    # Test connection
    if not test_azure_apim_connection():
        success = False
    
    # Test API creation if connection works
    if success:
        if not test_sample_api_creation():
            success = False
    
    print("\n" + "=" * 50)
    if success:
        print("🎉 All tests passed! Your Azure APIM connection is working.")
    else:
        print("❌ Some tests failed. Check the errors above.")
    
    return success

if __name__ == "__main__":
    main()