#!/usr/bin/env python3
"""
Minimal test for gpt-5-mini with your exact YAML
"""
import os
import json
from dotenv import load_dotenv

load_dotenv()

def minimal_conversion_test():
    """Minimal test that should work with gpt-5-mini"""
    
    # Your exact YAML content
    yaml_content = '''swagger: "2.0"
info:
  title: "Pet Store API"
  version: "1.0.0"
  description: "A sample API that uses a petstore as an example"
host: "petstore.swagger.io"
basePath: "/v1"
schemes:
  - "https"
  - "http"
consumes:
  - "application/json"
produces:
  - "application/json"
securityDefinitions:
  api_key:
    type: "apiKey"
    name: "api_key"
    in: "header"
paths:
  /pets:
    get:
      summary: "List all pets"
      operationId: "listPets"
      tags:
        - "pets"
      parameters:
        - name: "limit"
          in: "query"
          description: "How many items to return at one time"
          required: false
          type: "integer"
          format: "int32"
      responses:
        "200":
          description: "A paged array of pets"
          schema:
            $ref: "#/definitions/Pets"
        default:
          description: "unexpected error"
          schema:
            $ref: "#/definitions/Error"
    post:
      summary: "Create a pet"
      operationId: "createPet"
      tags:
        - "pets"
      parameters:
        - name: "pet"
          in: "body"
          description: "Pet to add to the store"
          required: true
          schema:
            $ref: "#/definitions/Pet"
      responses:
        "201":
          description: "Pet created"
        default:
          description: "unexpected error"
          schema:
            $ref: "#/definitions/Error"
  /pets/{petId}:
    get:
      summary: "Info for a specific pet"
      operationId: "showPetById"
      tags:
        - "pets"
      parameters:
        - name: "petId"
          in: "path"
          required: true
          description: "The id of the pet to retrieve"
          type: "string"
      responses:
        "200":
          description: "Expected response to a valid request"
          schema:
            $ref: "#/definitions/Pet"
        default:
          description: "unexpected error"
          schema:
            $ref: "#/definitions/Error"
definitions:
  Pet:
    type: "object"
    required:
      - "id"
      - "name"
    properties:
      id:
        type: "integer"
        format: "int64"
      name:
        type: "string"
      tag:
        type: "string"
  Pets:
    type: "array"
    items:
      $ref: "#/definitions/Pet"
  Error:
    type: "object"
    required:
      - "code"
      - "message"
    properties:
      code:
        type: "integer"
        format: "int32"
      message:
        type: "string"'''

    try:
        from openai import AzureOpenAI
        
        client = AzureOpenAI(
            api_key=os.getenv('AZURE_OPENAI_API_KEY'),
            api_version="2024-02-01",
            azure_endpoint=os.getenv('AZURE_OPENAI_ENDPOINT')
        )
        
        print("Testing conversion with minimal parameters...")
        
        # Very simple prompt
        prompt = f"Convert this Swagger 2.0 to OpenAPI 3.0. Return only valid JSON:\n\n{yaml_content}"
        
        # Minimal API call - only required parameters
        response = client.chat.completions.create(
            model=os.getenv('AZURE_OPENAI_DEPLOYMENT'),
            messages=[
                {"role": "user", "content": prompt}
            ],
            max_completion_tokens=3000
        )
        
        if response and response.choices:
            result = response.choices[0].message.content
            
            print("=== RAW OPENAI RESPONSE ===")
            print(result)
            print("=== END RESPONSE ===")
            
            # Try to extract and validate JSON
            try:
                # Sometimes AI wraps JSON in code blocks
                if "```json" in result:
                    json_start = result.find("```json") + 7
                    json_end = result.find("```", json_start)
                    json_str = result[json_start:json_end].strip()
                elif "```" in result:
                    json_start = result.find("```") + 3
                    json_end = result.rfind("```")
                    json_str = result[json_start:json_end].strip()
                else:
                    json_str = result.strip()
                
                # Parse JSON
                parsed = json.loads(json_str)
                
                # Save to file
                with open("converted_openapi.json", "w") as f:
                    json.dump(parsed, f, indent=2)
                
                print(f"\nSUCCESS! Converted specification saved to: converted_openapi.json")
                print(f"OpenAPI version: {parsed.get('openapi', 'NOT FOUND')}")
                print(f"Title: {parsed.get('info', {}).get('title', 'NOT FOUND')}")
                print(f"Paths: {len(parsed.get('paths', {}))}")
                print(f"Schemas: {len(parsed.get('components', {}).get('schemas', {}))}")
                
                return True
                
            except json.JSONDecodeError as e:
                print(f"Failed to parse as JSON: {e}")
                print("Saving raw response to debug...")
                with open("raw_response.txt", "w") as f:
                    f.write(result)
                return False
        
    except Exception as e:
        print(f"API call failed: {e}")
        return False

if __name__ == "__main__":
    minimal_conversion_test()