-- Create New Database User for DocConverter Pro
-- Run this script after your database is initialized

-- Connect to PostgreSQL as superuser
-- docker exec -it docconverter_postgres psql -U postgres -d doc_converter

-- 1. Create a dedicated application user with limited privileges
CREATE USER docconverter_app WITH PASSWORD 'DocConverter2024!';

-- 2. Create a read-only user for reporting/analytics
CREATE USER docconverter_readonly WITH PASSWORD 'ReadOnly2024!';

-- 3. Create a backup user with specific backup privileges
CREATE USER docconverter_backup WITH PASSWORD 'Backup2024!';

-- 4. Grant database connection privileges
GRANT CONNECT ON DATABASE doc_converter TO docconverter_app;
GRANT CONNECT ON DATABASE doc_converter TO docconverter_readonly;
GRANT CONNECT ON DATABASE doc_converter TO docconverter_backup;

-- 5. Grant schema usage
GRANT USAGE ON SCHEMA public TO docconverter_app;
GRANT USAGE ON SCHEMA public TO docconverter_readonly;
GRANT USAGE ON SCHEMA public TO docconverter_backup;

-- 6. Grant table privileges to application user
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO docconverter_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO docconverter_app;

-- Grant privileges on future tables (important for new tables)
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO docconverter_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
    GRANT USAGE, SELECT ON SEQUENCES TO docconverter_app;

-- 7. Grant read-only privileges
GRANT SELECT ON ALL TABLES IN SCHEMA public TO docconverter_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
    GRANT SELECT ON TABLES TO docconverter_readonly;

-- 8. Grant backup privileges
GRANT SELECT ON ALL TABLES IN SCHEMA public TO docconverter_backup;
ALTER DEFAULT PRIVILEGES IN SCHEMA public 
    GRANT SELECT ON TABLES TO docconverter_backup;

-- 9. Create a user management function for admins
CREATE OR REPLACE FUNCTION create_app_user(
    user_email VARCHAR(120),
    user_password VARCHAR(100),
    user_first_name VARCHAR(50),
    user_last_name VARCHAR(50),
    user_role user_role DEFAULT 'viewer'
)
RETURNS INTEGER AS $$
DECLARE
    new_user_id INTEGER;
BEGIN
    INSERT INTO users (email, password_hash, first_name, last_name, role, is_active)
    VALUES (user_email, crypt(user_password, gen_salt('bf')), user_first_name, user_last_name, user_role, true)
    RETURNING id INTO new_user_id;
    
    -- Log the user creation
    INSERT INTO audit_logs (action, resource_type, resource_id, details, timestamp)
    VALUES ('user_created', 'user', new_user_id::TEXT, 
            json_build_object('email', user_email, 'role', user_role)::TEXT, 
            CURRENT_TIMESTAMP);
    
    RETURN new_user_id;
END;
$$ LANGUAGE plpgsql;

-- 10. Create sample application users
SELECT create_app_user('john.doe@company.com', 'TempPassword123!', 'John', 'Doe', 'editor');
SELECT create_app_user('jane.smith@company.com', 'TempPassword123!', 'Jane', 'Smith', 'editor');
SELECT create_app_user('mike.wilson@company.com', 'TempPassword123!', 'Mike', 'Wilson', 'viewer');
SELECT create_app_user('sarah.johnson@company.com', 'TempPassword123!', 'Sarah', 'Johnson', 'admin');

-- 11. Update system settings to use new database user
UPDATE system_settings 
SET value = 'docconverter_app' 
WHERE key = 'db_user';

INSERT INTO system_settings (key, value, description) VALUES
('db_user', 'docconverter_app', 'Database user for application connections'),
('db_connection_timeout', '30', 'Database connection timeout in seconds'),
('db_pool_size', '10', 'Connection pool size'),
('security_password_policy', 'strong', 'Password policy enforcement level');

-- 12. Create a view for user management (admin only)
CREATE VIEW user_management AS
SELECT 
    id,
    email,
    first_name,
    last_name,
    role,
    is_active,
    last_login,
    created_at,
    (SELECT COUNT(*) FROM documents WHERE user_id = u.id) as document_count,
    (SELECT COUNT(*) FROM conversions WHERE user_id = u.id) as conversion_count
FROM users u
ORDER BY created_at DESC;

-- Grant view access
GRANT SELECT ON user_management TO docconverter_app;
GRANT SELECT ON user_management TO docconverter_readonly;

-- 13. Display created users
SELECT 'Created Users:' as info;
SELECT id, email, first_name, last_name, role, is_active, created_at
FROM users 
ORDER BY created_at DESC;