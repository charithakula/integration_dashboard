"""
Enhanced File Handler with Converted File Storage
Handles file operations for both uploaded and converted OpenAPI specifications
FEATURES: Separate folders, file validation, cleanup, conversion tracking
"""
import os
import json
import yaml
import hashlib
import shutil
from typing import Dict, Any, Optional, List
from datetime import datetime
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename
import logging

logger = logging.getLogger(__name__)

class EnhancedFileHandler:
    """Enhanced file handler with converted file storage"""
    
    def __init__(self, base_folder: str = 'static/uploads'):
        """Initialize file handler with organized folder structure"""
        self.base_folder = base_folder
        self.upload_folder = os.path.join(base_folder, 'uploaded')
        self.converted_folder = os.path.join(base_folder, 'converted')
        self.temp_folder = os.path.join(base_folder, 'temp')
        
        # Create folders
        self._create_folders()
        
        # File size limits
        self.max_file_size = 16 * 1024 * 1024  # 16MB
        self.allowed_extensions = {'.json', '.yaml', '.yml', '.txt'}
        
    def _create_folders(self):
        """Create necessary folder structure"""
        folders = [self.base_folder, self.upload_folder, self.converted_folder, self.temp_folder]
        for folder in folders:
            os.makedirs(folder, exist_ok=True)
            logger.info(f"Ensured folder exists: {folder}")
    
    def save_uploaded_file(self, file: FileStorage, prefix: str = 'upload') -> Dict[str, Any]:
        """Save uploaded file with validation"""
        try:
            # Validate file
            validation_result = self._validate_file(file)
            if not validation_result['valid']:
                return {
                    'success': False,
                    'error': validation_result['error']
                }
            
            # Generate secure filename
            original_filename = file.filename
            file_extension = os.path.splitext(original_filename)[1].lower()
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            secure_base = secure_filename(os.path.splitext(original_filename)[0])
            filename = f"{prefix}_{timestamp}_{secure_base}{file_extension}"
            
            # Save file
            file_path = os.path.join(self.upload_folder, filename)
            file.save(file_path)
            
            # Get file info
            file_stats = os.stat(file_path)
            file_hash = self._calculate_file_hash(file_path)
            
            logger.info(f"Uploaded file saved: {filename}")
            
            return {
                'success': True,
                'filename': filename,
                'file_path': file_path,
                'original_filename': original_filename,
                'file_size': file_stats.st_size,
                'file_hash': file_hash,
                'upload_time': datetime.now().isoformat(),
                'folder_type': 'uploaded'
            }
            
        except Exception as e:
            logger.error(f"Failed to save uploaded file: {e}")
            return {
                'success': False,
                'error': f'Failed to save file: {str(e)}'
            }
    
    def save_converted_file(self, converted_spec: Dict[str, Any], 
                           original_filename: str, 
                           conversion_metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Save converted OpenAPI specification"""
        try:
            # Generate filename for converted file
            base_name = os.path.splitext(original_filename)[0]
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            converted_filename = f"converted_{timestamp}_{secure_filename(base_name)}.json"
            
            # Save converted spec
            converted_path = os.path.join(self.converted_folder, converted_filename)
            with open(converted_path, 'w', encoding='utf-8') as f:
                json.dump(converted_spec, f, indent=2, ensure_ascii=False)
            
            # Save metadata if provided
            metadata_filename = f"metadata_{timestamp}_{secure_filename(base_name)}.json"
            metadata_path = os.path.join(self.converted_folder, metadata_filename)
            
            metadata = {
                'original_filename': original_filename,
                'converted_filename': converted_filename,
                'conversion_timestamp': datetime.now().isoformat(),
                'openapi_version': converted_spec.get('openapi', 'Unknown'),
                'api_title': converted_spec.get('info', {}).get('title', 'Unknown'),
                'api_version': converted_spec.get('info', {}).get('version', 'Unknown'),
                'paths_count': len(converted_spec.get('paths', {})),
                'schemas_count': len(converted_spec.get('components', {}).get('schemas', {})),
                'conversion_metadata': conversion_metadata or {}
            }
            
            with open(metadata_path, 'w', encoding='utf-8') as f:
                json.dump(metadata, f, indent=2, ensure_ascii=False)
            
            # Get file stats
            file_stats = os.stat(converted_path)
            file_hash = self._calculate_file_hash(converted_path)
            
            logger.info(f"Converted file saved: {converted_filename}")
            
            return {
                'success': True,
                'filename': converted_filename,
                'file_path': converted_path,
                'metadata_filename': metadata_filename,
                'metadata_path': metadata_path,
                'file_size': file_stats.st_size,
                'file_hash': file_hash,
                'conversion_time': datetime.now().isoformat(),
                'folder_type': 'converted',
                'download_url': f'/api/files/converted/{converted_filename}',
                'metadata': metadata
            }
            
        except Exception as e:
            logger.error(f"Failed to save converted file: {e}")
            return {
                'success': False,
                'error': f'Failed to save converted file: {str(e)}'
            }
    
    def read_file_content(self, file_path: str) -> Dict[str, Any]:
        """Read and parse file content"""
        try:
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            # Read file content
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Determine content type and parse
            file_extension = os.path.splitext(file_path)[1].lower()
            content_type = 'json' if file_extension == '.json' else 'yaml'
            
            parsed_content = None
            try:
                if content_type == 'json' or content.strip().startswith('{'):
                    parsed_content = json.loads(content)
                    content_type = 'json'
                else:
                    parsed_content = yaml.safe_load(content)
                    content_type = 'yaml'
            except Exception as parse_error:
                logger.warning(f"Failed to parse content as {content_type}: {parse_error}")
            
            file_stats = os.stat(file_path)
            
            return {
                'success': True,
                'content': content,
                'parsed_content': parsed_content,
                'content_type': content_type,
                'file_size': file_stats.st_size,
                'encoding': 'utf-8'
            }
            
        except Exception as e:
            logger.error(f"Failed to read file content: {e}")
            return {
                'success': False,
                'error': f'Failed to read file: {str(e)}'
            }
    
    def get_file_info(self, filename: str, folder_type: str = 'uploaded') -> Dict[str, Any]:
        """Get file information with content preview"""
        try:
            folder = self.upload_folder if folder_type == 'uploaded' else self.converted_folder
            file_path = os.path.join(folder, filename)
            
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            # Read content
            content_result = self.read_file_content(file_path)
            if not content_result['success']:
                return content_result
            
            # Get file stats
            file_stats = os.stat(file_path)
            
            # Get metadata if it's a converted file
            metadata = None
            if folder_type == 'converted':
                metadata = self._get_conversion_metadata(filename)
            
            return {
                'success': True,
                'filename': filename,
                'folder_type': folder_type,
                'content': content_result['content'],
                'parsed_content': content_result['parsed_content'],
                'content_type': content_result['content_type'],
                'file_size': file_stats.st_size,
                'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                'metadata': metadata
            }
            
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return {
                'success': False,
                'error': f'Failed to get file info: {str(e)}'
            }
    
    def list_files(self, folder_type: str = 'all') -> Dict[str, Any]:
        """List files in specified folder(s)"""
        try:
            files = []
            
            if folder_type in ['all', 'uploaded']:
                uploaded_files = self._list_folder_files(self.upload_folder, 'uploaded')
                files.extend(uploaded_files)
            
            if folder_type in ['all', 'converted']:
                converted_files = self._list_folder_files(self.converted_folder, 'converted')
                files.extend(converted_files)
            
            # Sort by modification time (newest first)
            files.sort(key=lambda x: x['modified_time'], reverse=True)
            
            return {
                'success': True,
                'files': files,
                'total_count': len(files),
                'folder_type': folder_type
            }
            
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return {
                'success': False,
                'error': f'Failed to list files: {str(e)}'
            }
    
    def delete_file(self, filename: str, folder_type: str = 'uploaded') -> Dict[str, Any]:
        """Delete file and associated metadata"""
        try:
            folder = self.upload_folder if folder_type == 'uploaded' else self.converted_folder
            file_path = os.path.join(folder, filename)
            
            if not os.path.exists(file_path):
                return {
                    'success': False,
                    'error': 'File not found'
                }
            
            # Delete main file
            os.remove(file_path)
            
            # Delete metadata file if it's a converted file
            if folder_type == 'converted':
                metadata_filename = filename.replace('converted_', 'metadata_').replace('.json', '.json')
                metadata_path = os.path.join(self.converted_folder, metadata_filename)
                if os.path.exists(metadata_path):
                    os.remove(metadata_path)
            
            logger.info(f"Deleted file: {filename} from {folder_type}")
            
            return {
                'success': True,
                'message': f'File {filename} deleted successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to delete file: {e}")
            return {
                'success': False,
                'error': f'Failed to delete file: {str(e)}'
            }
    
    def cleanup_old_files(self, days_old: int = 7) -> Dict[str, Any]:
        """Clean up files older than specified days"""
        try:
            cutoff_time = datetime.now().timestamp() - (days_old * 24 * 60 * 60)
            deleted_files = []
            
            # Clean uploaded files
            for filename in os.listdir(self.upload_folder):
                file_path = os.path.join(self.upload_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"uploaded/{filename}")
            
            # Clean converted files
            for filename in os.listdir(self.converted_folder):
                file_path = os.path.join(self.converted_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"converted/{filename}")
            
            # Clean temp files
            for filename in os.listdir(self.temp_folder):
                file_path = os.path.join(self.temp_folder, filename)
                if os.path.isfile(file_path) and os.path.getmtime(file_path) < cutoff_time:
                    os.remove(file_path)
                    deleted_files.append(f"temp/{filename}")
            
            logger.info(f"Cleaned up {len(deleted_files)} old files")
            
            return {
                'success': True,
                'deleted_files': deleted_files,
                'count': len(deleted_files)
            }
            
        except Exception as e:
            logger.error(f"Failed to cleanup old files: {e}")
            return {
                'success': False,
                'error': f'Failed to cleanup: {str(e)}'
            }
    
    def get_storage_stats(self) -> Dict[str, Any]:
        """Get storage statistics"""
        try:
            stats = {}
            
            for folder_name, folder_path in [
                ('uploaded', self.upload_folder),
                ('converted', self.converted_folder),
                ('temp', self.temp_folder)
            ]:
                if os.path.exists(folder_path):
                    files = [f for f in os.listdir(folder_path) if os.path.isfile(os.path.join(folder_path, f))]
                    total_size = sum(os.path.getsize(os.path.join(folder_path, f)) for f in files)
                    
                    stats[folder_name] = {
                        'file_count': len(files),
                        'total_size_bytes': total_size,
                        'total_size_mb': round(total_size / (1024 * 1024), 2)
                    }
                else:
                    stats[folder_name] = {
                        'file_count': 0,
                        'total_size_bytes': 0,
                        'total_size_mb': 0
                    }
            
            # Calculate totals
            total_files = sum(s['file_count'] for s in stats.values())
            total_size = sum(s['total_size_bytes'] for s in stats.values())
            
            return {
                'success': True,
                'folders': stats,
                'totals': {
                    'total_files': total_files,
                    'total_size_bytes': total_size,
                    'total_size_mb': round(total_size / (1024 * 1024), 2)
                }
            }
            
        except Exception as e:
            logger.error(f"Failed to get storage stats: {e}")
            return {
                'success': False,
                'error': f'Failed to get storage stats: {str(e)}'
            }
    
    def _validate_file(self, file: FileStorage) -> Dict[str, Any]:
        """Validate uploaded file"""
        if not file or not file.filename:
            return {'valid': False, 'error': 'No file provided'}
        
        # Check file extension
        file_extension = os.path.splitext(file.filename)[1].lower()
        if file_extension not in self.allowed_extensions:
            return {
                'valid': False, 
                'error': f'Invalid file type. Allowed: {", ".join(self.allowed_extensions)}'
            }
        
        # Check file size (read current position first)
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)  # Reset to beginning
        
        if file_size > self.max_file_size:
            return {
                'valid': False,
                'error': f'File too large. Max size: {self.max_file_size // (1024*1024)}MB'
            }
        
        return {'valid': True}
    
    def _calculate_file_hash(self, file_path: str) -> str:
        """Calculate SHA-256 hash of file"""
        hash_sha256 = hashlib.sha256()
        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(4096), b""):
                hash_sha256.update(chunk)
        return hash_sha256.hexdigest()[:16]  # First 16 characters
    
    def _list_folder_files(self, folder_path: str, folder_type: str) -> List[Dict[str, Any]]:
        """List files in a specific folder"""
        files = []
        
        if not os.path.exists(folder_path):
            return files
        
        for filename in os.listdir(folder_path):
            file_path = os.path.join(folder_path, filename)
            
            if os.path.isfile(file_path):
                file_stats = os.stat(file_path)
                
                # Get basic file info
                file_info = {
                    'filename': filename,
                    'folder_type': folder_type,
                    'file_size': file_stats.st_size,
                    'modified_time': datetime.fromtimestamp(file_stats.st_mtime).isoformat(),
                    'file_extension': os.path.splitext(filename)[1].lower()
                }
                
                # Add metadata for converted files
                if folder_type == 'converted' and filename.startswith('converted_'):
                    metadata = self._get_conversion_metadata(filename)
                    if metadata:
                        file_info['metadata'] = metadata
                
                files.append(file_info)
        
        return files
    
    def _get_conversion_metadata(self, converted_filename: str) -> Optional[Dict[str, Any]]:
        """Get conversion metadata for a converted file"""
        try:
            # Generate metadata filename
            metadata_filename = converted_filename.replace('converted_', 'metadata_')
            metadata_path = os.path.join(self.converted_folder, metadata_filename)
            
            if os.path.exists(metadata_path):
                with open(metadata_path, 'r', encoding='utf-8') as f:
                    return json.load(f)
            
            return None
            
        except Exception as e:
            logger.warning(f"Failed to read metadata for {converted_filename}: {e}")
            return None