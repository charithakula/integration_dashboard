"""
Tests for service modules
Tests conversion, migration, and validation services
"""
import pytest
import json
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime
from . import (
    SAMPLE_OPENAPI_2_SPEC, 
    SAMPLE_OPENAPI_3_SPEC,
    generate_migration_record_data,
    generate_api_spec_data
)

class TestConversionService:
    """Test cases for ConversionService"""
    
    def test_initialization(self):
        """Test service initialization"""
        from services.conversion_service import ConversionService
        
        service = ConversionService()
        assert service is not None
        assert service.openai_connector is not None
        assert service.validation_service is not None
    
    @patch('services.conversion_service.AzureOpenAIConnector')
    def test_convert_specification_success(self, mock_connector):
        """Test successful specification conversion"""
        from services.conversion_service import ConversionService
        
        # Mock the OpenAI connector
        mock_connector_instance = Mock()
        mock_connector_instance.parse_api_spec.return_value = (SAMPLE_OPENAPI_2_SPEC, 'json')
        mock_connector_instance.convert_openapi_2_to_3.return_value = SAMPLE_OPENAPI_3_SPEC
        mock_connector_instance.is_available = True
        mock_connector.return_value = mock_connector_instance
        
        # Mock validation service
        with patch('services.conversion_service.ValidationService') as mock_validation:
            mock_validation_instance = Mock()
            mock_validation_instance.validate_openapi_2.return_value = {
                'is_valid': True,
                'errors': [],
                'warnings': []
            }
            mock_validation_instance.validate_openapi_3.return_value = {
                'is_valid': True,
                'errors': [],
                'warnings': []
            }
            mock_validation.return_value = mock_validation_instance
            
            service = ConversionService()
            result = service.convert_specification(json.dumps(SAMPLE_OPENAPI_2_SPEC))
            
            assert result['status'] == 'success'
            assert result['converted_spec'] == SAMPLE_OPENAPI_3_SPEC
            assert 'conversion_time_seconds' in result
            assert 'conversion_metadata' in result
    
    def test_convert_specification_invalid_input(self):
        """Test conversion with invalid input"""
        from services.conversion_service import ConversionService
        
        service = ConversionService()
        result = service.convert_specification("invalid json content")
        
        assert result['status'] == 'error'
        assert 'message' in result
    
    def test_batch_convert_specifications(self):
        """Test batch conversion of specifications"""
        from services.conversion_service import ConversionService
        
        with patch.object(ConversionService, 'convert_specification') as mock_convert:
            mock_convert.return_value = {
                'status': 'success',
                'conversion_time_seconds': 2.5
            }
            
            service = ConversionService()
            
            specifications = [
                {'content': json.dumps(SAMPLE_OPENAPI_2_SPEC), 'name': 'api1'},
                {'content': json.dumps(SAMPLE_OPENAPI_2_SPEC), 'name': 'api2'}
            ]
            
            result = service.batch_convert_specifications(specifications)
            
            assert result['status'] == 'completed'
            assert result['total_specifications'] == 2
            assert result['successful_conversions'] == 2
            assert result['failed_conversions'] == 0
            assert len(result['results']) == 2
    
    def test_get_conversion_preview(self):
        """Test conversion preview functionality"""
        from services.conversion_service import ConversionService
        
        with patch('services.conversion_service.ValidationService') as mock_validation:
            mock_validation_instance = Mock()
            mock_validation_instance.validate_openapi_2.return_value = {
                'is_valid': True,
                'errors': [],
                'warnings': []
            }
            mock_validation.return_value = mock_validation_instance
            
            with patch('services.conversion_service.AzureOpenAIConnector') as mock_connector:
                mock_connector_instance = Mock()
                mock_connector_instance.parse_api_spec.return_value = (SAMPLE_OPENAPI_2_SPEC, 'json')
                mock_connector_instance.is_available = True
                mock_connector.return_value = mock_connector_instance
                
                service = ConversionService()
                result = service.get_conversion_preview(json.dumps(SAMPLE_OPENAPI_2_SPEC))
                
                assert result['status'] == 'success'
                assert 'api_info' in result
                assert 'conversion_preview' in result
                assert 'paths_count' in result['conversion_preview']
    
    def test_calculate_conversion_complexity(self):
        """Test conversion complexity calculation"""
        from services.conversion_service import ConversionService
        
        service = ConversionService()
        
        # Test low complexity
        simple_spec = {
            "paths": {"/test": {}},
            "definitions": {"User": {}}
        }
        complexity = service._calculate_conversion_complexity(simple_spec)
        assert complexity in ['low', 'medium', 'high']
        
        # Test high complexity
        complex_spec = {
            "paths": {f"/path{i}": {} for i in range(10)},
            "definitions": {f"Schema{i}": {} for i in range(15)},
            "securityDefinitions": {f"Auth{i}": {} for i in range(3)}
        }
        complexity = service._calculate_conversion_complexity(complex_spec)
        assert complexity in ['medium', 'high']

class TestValidationService:
    """Test cases for ValidationService"""
    
    def test_initialization(self):
        """Test service initialization"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        assert service is not None
        assert service.openapi_2_required_fields == ['swagger', 'info', 'paths']
        assert service.openapi_3_required_fields == ['openapi', 'info', 'paths']
    
    def test_validate_openapi_2_valid(self):
        """Test validation of valid OpenAPI 2.0 specification"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        result = service.validate_openapi_2(SAMPLE_OPENAPI_2_SPEC)
        
        assert result['is_valid'] == True
        assert result['version'] == '2.0'
        assert len(result['errors']) == 0
    
    def test_validate_openapi_2_invalid(self):
        """Test validation of invalid OpenAPI 2.0 specification"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        # Missing required fields
        invalid_spec = {"swagger": "2.0"}
        result = service.validate_openapi_2(invalid_spec)
        
        assert result['is_valid'] == False
        assert len(result['errors']) > 0
        assert any('info' in error for error in result['errors'])
        assert any('paths' in error for error in result['errors'])
    
    def test_validate_openapi_3_valid(self):
        """Test validation of valid OpenAPI 3.0 specification"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        result = service.validate_openapi_3(SAMPLE_OPENAPI_3_SPEC)
        
        assert result['is_valid'] == True
        assert result['version'] == '3.0'
        assert len(result['errors']) == 0
    
    def test_validate_info_section(self):
        """Test info section validation"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        # Valid info
        valid_info = {"title": "Test API", "version": "1.0.0", "description": "Test description"}
        result = service._validate_info_section(valid_info)
        assert len(result['errors']) == 0
        
        # Invalid info - missing required fields
        invalid_info = {"description": "Test description"}
        result = service._validate_info_section(invalid_info)
        assert len(result['errors']) == 2  # Missing title and version
    
    def test_validate_paths_section(self):
        """Test paths section validation"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        # Valid paths
        valid_paths = {
            "/users": {
                "get": {
                    "responses": {"200": {"description": "Success"}}
                }
            }
        }
        result = service._validate_paths_section(valid_paths, "2.0")
        assert len(result['errors']) == 0
        
        # Invalid path - doesn't start with /
        invalid_paths = {
            "users": {
                "get": {"responses": {"200": {"description": "Success"}}}
            }
        }
        result = service._validate_paths_section(invalid_paths, "2.0")
        assert len(result['errors']) > 0
    
    def test_validate_conversion_quality(self):
        """Test conversion quality validation"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        result = service.validate_conversion_quality(
            SAMPLE_OPENAPI_2_SPEC,
            SAMPLE_OPENAPI_3_SPEC
        )
        
        assert 'conversion_score' in result
        assert 'issues' in result
        assert 'quality_rating' in result
        assert result['conversion_score'] >= 0
        assert result['conversion_score'] <= 100
    
    def test_is_valid_url(self):
        """Test URL validation"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        assert service._is_valid_url("https://api.example.com") == True
        assert service._is_valid_url("http://localhost:8080") == True
        assert service._is_valid_url("invalid-url") == False
        assert service._is_valid_url("") == False

class TestMigrationService:
    """Test cases for MigrationService"""
    
    def test_initialization(self):
        """Test service initialization"""
        from services.migration_service import MigrationService
        
        service = MigrationService()
        assert service is not None
        assert service.ibm_connector is not None
        assert service.azure_apim_connector is not None
        assert service.conversion_service is not None
    
    @patch('services.migration_service.IBMAPIConnector')
    @patch('services.migration_service.AzureAPIMConnector')
    @patch('services.migration_service.ConversionService')
    def test_migrate_single_api_success(self, mock_conversion, mock_azure, mock_ibm):
        """Test successful single API migration"""
        from services.migration_service import MigrationService
        
        # Mock IBM connector
        mock_ibm_instance = Mock()
        mock_ibm_instance.is_available = True
        mock_ibm_instance.export_api.return_value = {
            'status': 'success',
            'data': {
                'specification': SAMPLE_OPENAPI_2_SPEC,
                'api_info': {'name': 'Test API', 'version': '1.0.0'}
            }
        }
        mock_ibm.return_value = mock_ibm_instance
        
        # Mock Azure APIM connector
        mock_azure_instance = Mock()
        mock_azure_instance.is_available = True
        mock_azure_instance.create_api_from_openapi.return_value = {
            'status': 'success',
            'api_id': 'migrated-test-api',
            'display_name': 'Test API'
        }
        mock_azure.return_value = mock_azure_instance
        
        # Mock conversion service
        mock_conversion_instance = Mock()
        mock_conversion_instance.convert_specification.return_value = {
            'status': 'success',
            'converted_spec': SAMPLE_OPENAPI_3_SPEC,
            'conversion_metadata': {'api_title': 'Test API'},
            'validation': {}
        }
        mock_conversion.return_value = mock_conversion_instance
        
        service = MigrationService()
        result = service.migrate_single_api('test-api-id', 'test-org')
        
        assert result['status'] == 'success'
        assert result['api_id'] == 'test-api-id'
        assert 'migration_id' in result
        assert 'migration_time_seconds' in result
    
    def test_migrate_single_api_extraction_failure(self):
        """Test migration failure during extraction"""
        from services.migration_service import MigrationService
        
        with patch('services.migration_service.IBMAPIConnector') as mock_ibm:
            mock_ibm_instance = Mock()
            mock_ibm_instance.is_available = True
            mock_ibm_instance.export_api.return_value = {
                'status': 'error',
                'message': 'API not found'
            }
            mock_ibm.return_value = mock_ibm_instance
            
            service = MigrationService()
            result = service.migrate_single_api('nonexistent-api', 'test-org')
            
            assert result['status'] == 'error'
            assert 'extraction' in result['message']
    
    def test_migrate_multiple_apis(self):
        """Test multiple API migration"""
        from services.migration_service import MigrationService
        
        with patch.object(MigrationService, 'migrate_single_api') as mock_migrate:
            mock_migrate.side_effect = [
                {'status': 'success', 'api_id': 'api1', 'migration_time_seconds': 5.0},
                {'status': 'error', 'api_id': 'api2', 'message': 'Conversion failed'},
                {'status': 'success', 'api_id': 'api3', 'migration_time_seconds': 3.0}
            ]
            
            service = MigrationService()
            result = service.migrate_multiple_apis(['api1', 'api2', 'api3'], 'test-org')
            
            assert result['status'] == 'completed'
            assert result['total_apis'] == 3
            assert result['successful_migrations'] == 2
            assert result['failed_migrations'] == 1
            assert len(result['results']) == 3
    
    def test_validate_migration_prerequisites(self):
        """Test migration prerequisites validation"""
        from services.migration_service import MigrationService
        
        with patch('services.migration_service.IBMAPIConnector') as mock_ibm, \
             patch('services.migration_service.AzureAPIMConnector') as mock_azure, \
             patch('services.migration_service.AzureOpenAIConnector') as mock_openai:
            
            # Mock successful connections
            mock_ibm.return_value.test_connection.return_value = {'status': 'success'}
            mock_azure.return_value.test_connection.return_value = {'status': 'success'}
            mock_openai.return_value.test_connection.return_value = {'status': 'success'}
            
            service = MigrationService()
            result = service.validate_migration_prerequisites()
            
            assert result['all_services_available'] == True
            assert result['can_migrate'] == True
            assert 'service_status' in result
    
    def test_get_migration_statistics(self):
        """Test migration statistics retrieval"""
        from services.migration_service import MigrationService
        
        service = MigrationService()
        result = service.get_migration_statistics()
        
        assert 'total_migrations' in result
        assert 'successful_migrations' in result
        assert 'failed_migrations' in result
        assert 'migration_success_rate' in result
    
    def test_generate_azure_api_id(self):
        """Test Azure API ID generation"""
        from services.migration_service import MigrationService
        
        service = MigrationService()
        
        # Test with spec containing title
        spec = {'info': {'title': 'My Test API'}}
        api_id = service._generate_azure_api_id(spec, 'original-id')
        assert api_id == 'my-test-api'
        
        # Test with no title - should use original ID
        spec = {}
        api_id = service._generate_azure_api_id(spec, 'original-api-123')
        assert api_id == 'original-api-123'
        
        # Test length limitation
        spec = {'info': {'title': 'A' * 100}}
        api_id = service._generate_azure_api_id(spec, 'original')
        assert len(api_id) <= 50
    
    def test_get_spec_preview(self):
        """Test specification preview extraction"""
        from services.migration_service import MigrationService
        
        service = MigrationService()
        preview = service._get_spec_preview(SAMPLE_OPENAPI_3_SPEC)
        
        assert preview['title'] == 'Test API'
        assert preview['version'] == '1.0.0'
        assert preview['paths_count'] == 2  # /users and /users/{id}
        assert 'servers' in preview
        assert 'has_security' in preview

class TestServiceIntegration:
    """Integration tests between services"""
    
    def test_conversion_to_migration_flow(self):
        """Test flow from conversion to migration"""
        from services.conversion_service import ConversionService
        from services.migration_service import MigrationService
        
        # Mock the external dependencies
        with patch('services.conversion_service.AzureOpenAIConnector') as mock_openai, \
             patch('services.migration_service.AzureAPIMConnector') as mock_apim:
            
            # Mock conversion
            mock_openai_instance = Mock()
            mock_openai_instance.convert_openapi_2_to_3.return_value = SAMPLE_OPENAPI_3_SPEC
            mock_openai_instance.parse_api_spec.return_value = (SAMPLE_OPENAPI_2_SPEC, 'json')
            mock_openai_instance.is_available = True
            mock_openai.return_value = mock_openai_instance
            
            # Mock deployment
            mock_apim_instance = Mock()
            mock_apim_instance.is_available = True
            mock_apim_instance.create_api_from_openapi.return_value = {
                'status': 'success',
                'api_id': 'deployed-api'
            }
            mock_apim.return_value = mock_apim_instance
            
            # Test the flow
            conversion_service = ConversionService()
            migration_service = MigrationService()
            
            # First convert
            conversion_result = conversion_service.convert_specification(
                json.dumps(SAMPLE_OPENAPI_2_SPEC)
            )
            
            # Then deploy (simulate part of migration)
            if conversion_result['status'] == 'success':
                deployment_result = migration_service._deploy_to_azure_apim(
                    conversion_result['converted_spec'],
                    'original-api-id',
                    {}
                )
                
                assert deployment_result['status'] == 'success'

class TestServiceErrorHandling:
    """Test error handling in services"""
    
    def test_conversion_service_network_error(self):
        """Test conversion service handling network errors"""
        from services.conversion_service import ConversionService
        
        with patch('services.conversion_service.AzureOpenAIConnector') as mock_connector:
            mock_connector_instance = Mock()
            mock_connector_instance.convert_openapi_2_to_3.side_effect = Exception("Network error")
            mock_connector_instance.parse_api_spec.return_value = (SAMPLE_OPENAPI_2_SPEC, 'json')
            mock_connector.return_value = mock_connector_instance
            
            service = ConversionService()
            result = service.convert_specification(json.dumps(SAMPLE_OPENAPI_2_SPEC))
            
            assert result['status'] == 'error'
            assert 'Network error' in result['message']
    
    def test_migration_service_timeout_handling(self):
        """Test migration service handling timeouts"""
        from services.migration_service import MigrationService
        
        with patch('services.migration_service.IBMAPIConnector') as mock_ibm:
            mock_ibm_instance = Mock()
            mock_ibm_instance.is_available = True
            mock_ibm_instance.export_api.side_effect = TimeoutError("Request timeout")
            mock_ibm.return_value = mock_ibm_instance
            
            service = MigrationService()
            result = service.migrate_single_api('test-api', 'test-org')
            
            assert result['status'] == 'error'
            assert 'timeout' in result['message'].lower()
    
    def test_validation_service_malformed_spec(self):
        """Test validation service with malformed specifications"""
        from services.validation_service import ValidationService
        
        service = ValidationService()
        
        # Test with None
        result = service.validate_openapi_2(None)
        assert result['is_valid'] == False
        
        # Test with non-dict
        result = service.validate_openapi_2("not a dict")
        assert result['is_valid'] == False
        
        # Test with empty dict
        result = service.validate_openapi_2({})
        assert result['is_valid'] == False
        assert len(result['errors']) > 0

class TestServicePerformance:
    """Test service performance and optimization"""
    
    def test_batch_conversion_performance(self):
        """Test batch conversion doesn't degrade with size"""
        from services.conversion_service import ConversionService
        import time
        
        with patch.object(ConversionService, 'convert_specification') as mock_convert:
            # Simulate consistent conversion time
            mock_convert.return_value = {
                'status': 'success',
                'conversion_time_seconds': 1.0
            }
            
            service = ConversionService()
            
            # Test with small batch
            small_batch = [{'content': json.dumps(SAMPLE_OPENAPI_2_SPEC)} for _ in range(5)]
            start_time = time.time()
            small_result = service.batch_convert_specifications(small_batch)
            small_duration = time.time() - start_time
            
            # Test with larger batch
            large_batch = [{'content': json.dumps(SAMPLE_OPENAPI_2_SPEC)} for _ in range(20)]
            start_time = time.time()
            large_result = service.batch_convert_specifications(large_batch)
            large_duration = time.time() - start_time
            
            # Performance should scale reasonably
            assert large_duration < small_duration * 10  # Should not be more than 10x slower
            assert small_result['successful_conversions'] == 5
            assert large_result['successful_conversions'] == 20