import os
from dotenv import load_dotenv
from azure.identity import ClientSecretCredential
from azure.mgmt.apimanagement import ApiManagementClient
from azure.mgmt.apimanagement.models import ApiCreateOrUpdateParameter

# Load environment variables
load_dotenv()

subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
resource_group = os.getenv("AZURE_RESOURCE_GROUP")
apim_service_name = os.getenv("APIM_SERVICE_NAME")

tenant_id = os.getenv("AZURE_TENANT_ID")
client_id = os.getenv("AZURE_CLIENT_ID")
client_secret = os.getenv("AZURE_CLIENT_SECRET")

# Authenticate
credential = ClientSecretCredential(
    tenant_id=tenant_id,
    client_id=client_id,
    client_secret=client_secret
)

client = ApiManagementClient(credential, subscription_id)

# API ID in APIM
api_id = "charithapi"

# Path to your OpenAPI file
openapi_path = "sample_api.yaml"

# Create/Import API from OpenAPI
with open(openapi_path, "r") as f:
    openapi_content = f.read()

api_params = ApiCreateOrUpdateParameter(
    display_name="Charith",
    path="CharithAPI",
    protocols=["https"],
    format="openapi+json" if openapi_path.endswith(".json") else "openapi-link+yaml",
    value=openapi_content
)

print(f"Importing OpenAPI into API '{api_id}'...")
poller = client.api.begin_create_or_update(
    resource_group_name=resource_group,
    service_name=apim_service_name,
    api_id=api_id,
    parameters=api_params
)

result = poller.result()
print("✅ OpenAPI imported successfully:", result.name)
