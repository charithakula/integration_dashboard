import os
import requests
from dotenv import load_dotenv

load_dotenv()
subscription_key = os.getenv("APIM_SUBSCRIPTION_KEY")

url = "https://charith1.azure-api.net/sample/get"  # matches your OpenAPI operation
headers = {"Ocp-Apim-Subscription-Key": subscription_key}

response = requests.get(url, headers=headers)
print(response.status_code, response.json())
