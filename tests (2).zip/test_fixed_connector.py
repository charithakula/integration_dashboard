import os
import openai
import json
import yaml

# Load Azure OpenAI configuration from environment
AZURE_OPENAI_ENDPOINT = os.getenv("AZURE_OPENAI_ENDPOINT")
AZURE_OPENAI_KEY = os.getenv("AZURE_OPENAI_API_KEY")
AZURE_OPENAI_DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT")
AZURE_OPENAI_VERSION = os.getenv("AZURE_OPENAI_VERSION", "2025-01-01-preview")

openai.api_type = "azure"
openai.api_base = AZURE_OPENAI_ENDPOINT
openai.api_version = AZURE_OPENAI_VERSION
openai.api_key = AZURE_OPENAI_KEY

def convert_openapi_2_to_3(spec_path: str, output_path: str):
    # Load OpenAPI 2.0 spec
    with open(spec_path, 'r') as f:
        content = f.read()

    # Ensure YAML or JSON
    try:
        spec_data = yaml.safe_load(content)
    except Exception:
        spec_data = json.loads(content)

    # Create prompt for Azure OpenAI
    prompt = f"""
    Convert the following OpenAPI 2.0 (Swagger) specification to OpenAPI 3.0 specification.
    Please preserve all paths, components, parameters, responses, and security definitions.

    OpenAPI 2.0 Spec:
    {json.dumps(spec_data)}
    """

    response = openai.ChatCompletion.create(
        engine=AZURE_OPENAI_DEPLOYMENT,
        messages=[
            {"role": "system", "content": "You are an expert OpenAPI converter."},
            {"role": "user", "content": prompt}
        ],
        temperature=0,
        max_tokens=3000  # Increase if spec is large
    )

    converted_spec_text = response.choices[0].message.content

    # Try parsing as YAML/JSON
    try:
        converted_spec = yaml.safe_load(converted_spec_text)
    except Exception:
        converted_spec = json.loads(converted_spec_text)

    # Save to output file
    with open(output_path, 'w') as f:
        yaml.safe_dump(converted_spec, f, sort_keys=False)

    print(f"Converted OpenAPI 3.0 spec saved to: {output_path}")

# Example usage
convert_openapi_2_to_3("swagger_v2.yaml", "openapi_v3.yaml")
