"""
Tests package for API Migration Tool
Contains unit tests and integration tests for the application
"""

import os
import sys
import pytest
from flask import Flask
from flask.testing import FlaskClient

# Add the parent directory to the path for imports
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

# Test configuration
class TestConfig:
    """Test configuration class"""
    TESTING = True
    DEBUG = False
    SECRET_KEY = 'test-secret-key'
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    WTF_CSRF_ENABLED = False
    
    # Override service configurations for testing
    AZURE_CLIENT_ID = 'test-client-id'
    AZURE_CLIENT_SECRET = 'test-client-secret'
    AZURE_TENANT_ID = 'test-tenant-id'
    AZURE_SUBSCRIPTION_ID = 'test-subscription-id'
    
    AZURE_OPENAI_ENDPOINT = 'https://test-openai.openai.azure.com/'
    AZURE_OPENAI_API_KEY = 'test-openai-key'
    AZURE_OPENAI_DEPLOYMENT = 'test-deployment'
    
    AZURE_APIM_RESOURCE_GROUP = 'test-resource-group'
    AZURE_APIM_SERVICE_NAME = 'test-apim-service'
    
    IBM_API_CONNECT_URL = 'https://test-ibm-api-connect.com'
    IBM_API_CONNECT_USERNAME = 'test-user'
    IBM_API_CONNECT_PASSWORD = 'test-password'
    IBM_API_CONNECT_ORG = 'test-org'
    
    UPLOAD_FOLDER = 'test_uploads'

# Test fixtures and utilities
@pytest.fixture
def app():
    """Create test Flask application"""
    from app import app as flask_app
    
    # Configure for testing
    flask_app.config.from_object(TestConfig)
    
    # Create application context
    with flask_app.app_context():
        from models.database import db
        db.create_all()
        yield flask_app
        db.drop_all()

@pytest.fixture
def client(app) -> FlaskClient:
    """Create test client"""
    return app.test_client()

@pytest.fixture
def runner(app):
    """Create test CLI runner"""
    return app.test_cli_runner()

# Sample test data
SAMPLE_OPENAPI_2_SPEC = {
    "swagger": "2.0",
    "info": {
        "title": "Test API",
        "version": "1.0.0",
        "description": "A test API for unit testing"
    },
    "host": "api.test.com",
    "basePath": "/v1",
    "schemes": ["https"],
    "consumes": ["application/json"],
    "produces": ["application/json"],
    "paths": {
        "/users": {
            "get": {
                "summary": "Get all users",
                "description": "Retrieve a list of all users",
                "responses": {
                    "200": {
                        "description": "List of users",
                        "schema": {
                            "type": "array",
                            "items": {
                                "$ref": "#/definitions/User"
                            }
                        }
                    },
                    "500": {
                        "description": "Internal server error"
                    }
                }
            },
            "post": {
                "summary": "Create user",
                "description": "Create a new user",
                "parameters": [
                    {
                        "name": "user",
                        "in": "body",
                        "required": True,
                        "schema": {
                            "$ref": "#/definitions/User"
                        }
                    }
                ],
                "responses": {
                    "201": {
                        "description": "User created",
                        "schema": {
                            "$ref": "#/definitions/User"
                        }
                    },
                    "400": {
                        "description": "Invalid input"
                    }
                }
            }
        },
        "/users/{id}": {
            "get": {
                "summary": "Get user by ID",
                "parameters": [
                    {
                        "name": "id",
                        "in": "path",
                        "required": True,
                        "type": "integer"
                    }
                ],
                "responses": {
                    "200": {
                        "description": "User details",
                        "schema": {
                            "$ref": "#/definitions/User"
                        }
                    },
                    "404": {
                        "description": "User not found"
                    }
                }
            }
        }
    },
    "definitions": {
        "User": {
            "type": "object",
            "required": ["name", "email"],
            "properties": {
                "id": {
                    "type": "integer",
                    "description": "User ID"
                },
                "name": {
                    "type": "string",
                    "description": "User name"
                },
                "email": {
                    "type": "string",
                    "format": "email",
                    "description": "User email address"
                },
                "created_at": {
                    "type": "string",
                    "format": "date-time",
                    "description": "Account creation timestamp"
                }
            }
        }
    },
    "securityDefinitions": {
        "ApiKeyAuth": {
            "type": "apiKey",
            "in": "header",
            "name": "X-API-Key"
        },
        "OAuth2": {
            "type": "oauth2",
            "flow": "implicit",
            "authorizationUrl": "https://auth.test.com/oauth/authorize",
            "scopes": {
                "read:users": "Read user information",
                "write:users": "Modify user information"
            }
        }
    },
    "security": [
        {
            "ApiKeyAuth": []
        }
    ]
}

SAMPLE_OPENAPI_3_SPEC = {
    "openapi": "3.0.0",
    "info": {
        "title": "Test API",
        "version": "1.0.0",
        "description": "A test API for unit testing"
    },
    "servers": [
        {
            "url": "https://api.test.com/v1"
        }
    ],
    "paths": {
        "/users": {
            "get": {
                "summary": "Get all users",
                "description": "Retrieve a list of all users",
                "responses": {
                    "200": {
                        "description": "List of users",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "type": "array",
                                    "items": {
                                        "$ref": "#/components/schemas/User"
                                    }
                                }
                            }
                        }
                    },
                    "500": {
                        "description": "Internal server error"
                    }
                }
            },
            "post": {
                "summary": "Create user",
                "description": "Create a new user",
                "requestBody": {
                    "required": True,
                    "content": {
                        "application/json": {
                            "schema": {
                                "$ref": "#/components/schemas/User"
                            }
                        }
                    }
                },
                "responses": {
                    "201": {
                        "description": "User created",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "$ref": "#/components/schemas/User"
                                }
                            }
                        }
                    },
                    "400": {
                        "description": "Invalid input"
                    }
                }
            }
        },
        "/users/{id}": {
            "get": {
                "summary": "Get user by ID",
                "parameters": [
                    {
                        "name": "id",
                        "in": "path",
                        "required": True,
                        "schema": {
                            "type": "integer"
                        }
                    }
                ],
                "responses": {
                    "200": {
                        "description": "User details",
                        "content": {
                            "application/json": {
                                "schema": {
                                    "$ref": "#/components/schemas/User"
                                }
                            }
                        }
                    },
                    "404": {
                        "description": "User not found"
                    }
                }
            }
        }
    },
    "components": {
        "schemas": {
            "User": {
                "type": "object",
                "required": ["name", "email"],
                "properties": {
                    "id": {
                        "type": "integer",
                        "description": "User ID"
                    },
                    "name": {
                        "type": "string",
                        "description": "User name"
                    },
                    "email": {
                        "type": "string",
                        "format": "email",
                        "description": "User email address"
                    },
                    "created_at": {
                        "type": "string",
                        "format": "date-time",
                        "description": "Account creation timestamp"
                    }
                }
            }
        },
        "securitySchemes": {
            "ApiKeyAuth": {
                "type": "apiKey",
                "in": "header",
                "name": "X-API-Key"
            },
            "OAuth2": {
                "type": "oauth2",
                "flows": {
                    "implicit": {
                        "authorizationUrl": "https://auth.test.com/oauth/authorize",
                        "scopes": {
                            "read:users": "Read user information",
                            "write:users": "Modify user information"
                        }
                    }
                }
            }
        }
    },
    "security": [
        {
            "ApiKeyAuth": []
        }
    ]
}

# Test utilities
class MockResponse:
    """Mock HTTP response for testing"""
    
    def __init__(self, json_data=None, status_code=200, text="", headers=None):
        self.json_data = json_data or {}
        self.status_code = status_code
        self.text = text
        self.headers = headers or {}
    
    def json(self):
        return self.json_data
    
    def raise_for_status(self):
        if self.status_code >= 400:
            raise Exception(f"HTTP {self.status_code}")

def create_test_file(content, filename="test.json"):
    """Create a temporary test file"""
    import tempfile
    import os
    
    temp_dir = tempfile.mkdtemp()
    file_path = os.path.join(temp_dir, filename)
    
    with open(file_path, 'w') as f:
        if isinstance(content, dict):
            import json
            json.dump(content, f, indent=2)
        else:
            f.write(content)
    
    return file_path

def cleanup_test_file(file_path):
    """Clean up temporary test file"""
    import os
    import shutil
    
    if os.path.exists(file_path):
        dir_path = os.path.dirname(file_path)
        shutil.rmtree(dir_path, ignore_errors=True)

# Custom test decorators
def skip_if_no_azure_config(func):
    """Skip test if Azure configuration is not available"""
    import pytest
    
    def wrapper(*args, **kwargs):
        # Check if real Azure config is available
        # In real tests, you might check actual environment variables
        return func(*args, **kwargs)
    
    return wrapper

def skip_if_no_ibm_config(func):
    """Skip test if IBM configuration is not available"""
    import pytest
    
    def wrapper(*args, **kwargs):
        # Check if real IBM config is available
        return func(*args, **kwargs)
    
    return wrapper

# Test data generators
def generate_migration_record_data(**overrides):
    """Generate test migration record data"""
    import uuid
    from datetime import datetime
    
    default_data = {
        'migration_id': str(uuid.uuid4()),
        'original_api_id': 'test-api-123',
        'api_name': 'Test API',
        'api_version': '1.0.0',
        'status': 'completed',
        'source_platform': 'ibm_api_connect',
        'target_platform': 'azure_apim',
        'start_time': datetime.utcnow(),
        'completion_time': 5.5,
        'ai_conversion_used': True
    }
    
    default_data.update(overrides)
    return default_data

def generate_api_spec_data(**overrides):
    """Generate test API specification data"""
    import uuid
    
    default_data = {
        'api_id': 'test-api-' + str(uuid.uuid4())[:8],
        'name': 'Test API',
        'version': '1.0.0',
        'description': 'Test API description',
        'format': 'openapi_2.0',
        'specification': SAMPLE_OPENAPI_2_SPEC,
        'is_valid': True,
        'paths_count': 2,
        'operations_count': 3
    }
    
    default_data.update(overrides)
    return default_data

# Export common test utilities
__all__ = [
    'TestConfig',
    'SAMPLE_OPENAPI_2_SPEC',
    'SAMPLE_OPENAPI_3_SPEC',
    'MockResponse',
    'create_test_file',
    'cleanup_test_file',
    'skip_if_no_azure_config',
    'skip_if_no_ibm_config',
    'generate_migration_record_data',
    'generate_api_spec_data'
]