"""
Tests for connector modules
Tests Azure APIM, Azure OpenAI, and IBM API Connect connectors
"""
import pytest
import json
from unittest.mock import Mock, patch, MagicMock
from . import (
    SAMPLE_OPENAPI_2_SPEC, 
    SAMPLE_OPENAPI_3_SPEC,
    MockResponse,
    skip_if_no_azure_config,
    skip_if_no_ibm_config
)

class TestAzureOpenAIConnector:
    """Test cases for Azure OpenAI Connector"""
    
    def test_initialization(self):
        """Test connector initialization"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        assert connector is not None
        # In test environment, client might not be initialized due to missing config
    
    def test_parse_api_spec_json(self):
        """Test parsing JSON API specification"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        json_content = json.dumps(SAMPLE_OPENAPI_2_SPEC)
        
        spec, format_type = connector.parse_api_spec(json_content)
        
        assert spec == SAMPLE_OPENAPI_2_SPEC
        assert format_type == 'json'
    
    def test_parse_api_spec_yaml(self):
        """Test parsing YAML API specification"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        import yaml
        
        connector = AzureOpenAIConnector()
        yaml_content = yaml.dump(SAMPLE_OPENAPI_2_SPEC)
        
        spec, format_type = connector.parse_api_spec(yaml_content)
        
        assert spec == SAMPLE_OPENAPI_2_SPEC
        assert format_type == 'yaml'
    
    def test_parse_api_spec_invalid(self):
        """Test parsing invalid specification"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        invalid_content = "invalid json/yaml content {"
        
        with pytest.raises(ValueError):
            connector.parse_api_spec(invalid_content)
    
    def test_is_openapi_2_detection(self):
        """Test OpenAPI 2.0 detection"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        
        assert connector._is_openapi_2({"swagger": "2.0"}) == True
        assert connector._is_openapi_2({"swagger": "2.1"}) == True
        assert connector._is_openapi_2({"openapi": "3.0.0"}) == False
        assert connector._is_openapi_2({}) == False
    
    def test_is_openapi_3_detection(self):
        """Test OpenAPI 3.0 detection"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        
        assert connector._is_openapi_3({"openapi": "3.0.0"}) == True
        assert connector._is_openapi_3({"openapi": "3.1.0"}) == True
        assert connector._is_openapi_3({"swagger": "2.0"}) == False
        assert connector._is_openapi_3({}) == False
    
    def test_fallback_conversion(self):
        """Test fallback conversion without AI"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        spec_content = json.dumps(SAMPLE_OPENAPI_2_SPEC)
        
        result = connector._fallback_conversion(spec_content)
        
        assert result["openapi"] == "3.0.0"
        assert "servers" in result
        assert "components" in result
        assert "schemas" in result["components"]
        assert len(result["servers"]) > 0
    
    def test_convert_security_definitions(self):
        """Test conversion of security definitions"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        security_defs = {
            "ApiKeyAuth": {
                "type": "apiKey",
                "name": "X-API-Key",
                "in": "header"
            },
            "OAuth2": {
                "type": "oauth2",
                "flow": "implicit",
                "authorizationUrl": "https://example.com/oauth",
                "scopes": {"read": "Read access"}
            }
        }
        
        result = connector._convert_security_definitions(security_defs)
        
        assert "ApiKeyAuth" in result
        assert result["ApiKeyAuth"]["type"] == "apiKey"
        assert "OAuth2" in result
        assert result["OAuth2"]["type"] == "oauth2"
    
    def test_create_servers_from_v2(self):
        """Test creation of servers array from OpenAPI 2.0 fields"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        spec = {
            "host": "api.example.com",
            "basePath": "/v1",
            "schemes": ["https", "http"]
        }
        
        servers = connector._create_servers_from_v2(spec)
        
        assert len(servers) == 2
        assert servers[0]["url"] == "https://api.example.com/v1"
        assert servers[1]["url"] == "http://api.example.com/v1"
    
    def test_validation_conversion(self):
        """Test conversion validation"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        
        validation_result = connector.validate_conversion(
            SAMPLE_OPENAPI_2_SPEC,
            SAMPLE_OPENAPI_3_SPEC
        )
        
        assert "is_valid_openapi_3" in validation_result
        assert "has_required_fields" in validation_result
        assert "preserved_paths" in validation_result
        assert validation_result["is_valid_openapi_3"] == True
    
    @patch('connectors.azure_openai_connector.AzureOpenAI')
    def test_ai_conversion_success(self, mock_azure_openai):
        """Test successful AI conversion"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        # Mock Azure OpenAI response
        mock_response = Mock()
        mock_response.choices = [Mock()]
        mock_response.choices[0].message.content = json.dumps(SAMPLE_OPENAPI_3_SPEC)
        
        mock_client = Mock()
        mock_client.chat.completions.create.return_value = mock_response
        mock_azure_openai.return_value = mock_client
        
        connector = AzureOpenAIConnector()
        connector._client = mock_client
        
        spec_content = json.dumps(SAMPLE_OPENAPI_2_SPEC)
        result = connector.convert_openapi_2_to_3(spec_content)
        
        assert result["openapi"] == "3.0.0"
        mock_client.chat.completions.create.assert_called_once()
    
    def test_test_connection_no_client(self):
        """Test connection test when client is not available"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        
        connector = AzureOpenAIConnector()
        connector._client = None
        
        result = connector.test_connection()
        
        assert result["status"] == "error"
        assert "not initialized" in result["message"]

class TestAzureAPIMConnector:
    """Test cases for Azure APIM Connector"""
    
    def test_initialization(self):
        """Test connector initialization"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        assert connector is not None
    
    def test_extract_api_info(self):
        """Test API information extraction from OpenAPI spec"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        api_info = connector._extract_api_info(SAMPLE_OPENAPI_3_SPEC)
        
        assert api_info["title"] == "Test API"
        assert api_info["version"] == "1.0.0"
        assert api_info["description"] == "A test API for unit testing"
        assert api_info["service_url"] == "https://api.test.com/v1"
    
    def test_generate_api_id(self):
        """Test API ID generation"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        
        # Test with title from spec
        spec = {"info": {"title": "My Test API"}}
        api_id = connector._generate_api_id(spec, "original-id")
        assert api_id == "my-test-api"
        
        # Test with original ID fallback
        spec = {}
        api_id = connector._generate_api_id(spec, "original-api-123")
        assert api_id == "original-api-123"
    
    def test_get_api_management_url(self):
        """Test generation of Azure API Management URL"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        from config import AzureConfig
        
        connector = AzureAPIMConnector()
        url = connector.get_api_management_url("test-api")
        
        expected_url = f"https://portal.azure.com/#@{AzureConfig.TENANT_ID}/resource/subscriptions/{AzureConfig.SUBSCRIPTION_ID}/resourceGroups/{AzureConfig.APIM_RESOURCE_GROUP}/providers/Microsoft.ApiManagement/service/{AzureConfig.APIM_SERVICE_NAME}/apis/test-api"
        assert url == expected_url
    
    def test_get_developer_portal_url(self):
        """Test generation of developer portal URL"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        from config import AzureConfig
        
        connector = AzureAPIMConnector()
        url = connector.get_developer_portal_url()
        
        expected_url = f"https://{AzureConfig.APIM_SERVICE_NAME}.developer.azure-api.net"
        assert url == expected_url
    
    @patch('connectors.azure_apim_connector.ApiManagementClient')
    @patch('connectors.azure_apim_connector.ClientSecretCredential')
    def test_create_api_success(self, mock_credential, mock_client):
        """Test successful API creation"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        # Mock Azure APIM client
        mock_result = Mock()
        mock_result.display_name = "Test API"
        mock_result.path = "test-api"
        mock_result.service_url = "https://api.test.com"
        
        mock_apim_client = Mock()
        mock_apim_client.api.begin_create_or_update.return_value.result.return_value = mock_result
        mock_client.return_value = mock_apim_client
        
        connector = AzureAPIMConnector()
        connector._client = mock_apim_client
        
        result = connector.create_api_from_openapi(SAMPLE_OPENAPI_3_SPEC, "test-api")
        
        assert result["status"] == "success"
        assert result["api_id"] == "test-api"
        assert result["display_name"] == "Test API"
    
    def test_test_connection_no_client(self):
        """Test connection test when client is not available"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        connector._client = None
        
        result = connector.test_connection()
        
        assert result["status"] == "error"
        assert "not initialized" in result["message"]

class TestIBMAPIConnector:
    """Test cases for IBM API Connect Connector"""
    
    def test_initialization(self):
        """Test connector initialization"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        connector = IBMAPIConnector()
        assert connector is not None
    
    @patch('requests.Session')
    def test_authenticate_token_success(self, mock_session):
        """Test successful token authentication"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock successful authentication response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {"access_token": "test-token"}
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        
        result = connector._authenticate_token()
        
        assert result == True
        assert connector._auth_token == "test-token"
    
    @patch('requests.Session')
    def test_authenticate_basic_success(self, mock_session):
        """Test successful basic authentication"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock successful test request
        mock_response = Mock()
        mock_response.status_code = 200
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        
        result = connector._authenticate_basic()
        
        assert result == True
    
    @patch('requests.Session')
    def test_list_apis_success(self, mock_session):
        """Test successful API listing"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock API list response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "results": [
                {
                    "id": "api-1",
                    "name": "test-api-1",
                    "title": "Test API 1",
                    "version": "1.0.0",
                    "description": "First test API",
                    "state": "published"
                },
                {
                    "id": "api-2",
                    "name": "test-api-2",
                    "title": "Test API 2",
                    "version": "2.0.0",
                    "description": "Second test API",
                    "state": "draft"
                }
            ]
        }
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        connector._auth_token = "test-token"
        
        result = connector.list_apis("test-org")
        
        assert len(result) == 2
        assert result[0]["name"] == "test-api-1"
        assert result[1]["name"] == "test-api-2"
    
    @patch('requests.Session')
    def test_get_api_specification_success(self, mock_session):
        """Test successful API specification retrieval"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock specification response
        mock_response = Mock()
        mock_response.status_code = 200
        mock_response.json.return_value = SAMPLE_OPENAPI_2_SPEC
        
        mock_session_instance = Mock()
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        connector._auth_token = "test-token"
        
        result = connector.get_api_specification("test-api", "test-org")
        
        assert result["status"] == "success"
        assert result["specification"] == SAMPLE_OPENAPI_2_SPEC
        assert result["format"] == "openapi_2.0"
    
    @patch('requests.Session')
    def test_export_api_success(self, mock_session):
        """Test successful API export"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock API details response
        api_response = Mock()
        api_response.status_code = 200
        api_response.json.return_value = {
            "id": "test-api",
            "name": "test-api",
            "title": "Test API",
            "version": "1.0.0"
        }
        
        # Mock specification response  
        spec_response = Mock()
        spec_response.status_code = 200
        spec_response.json.return_value = SAMPLE_OPENAPI_2_SPEC
        
        mock_session_instance = Mock()
        mock_session_instance.get.side_effect = [api_response, spec_response]
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        connector._auth_token = "test-token"
        
        result = connector.export_api("test-api", "test-org")
        
        assert result["status"] == "success"
        assert result["api_id"] == "test-api"
        assert "api_info" in result["data"]
        assert "specification" in result["data"]
    
    def test_search_apis(self):
        """Test API search functionality"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        connector = IBMAPIConnector()
        
        # Mock list_apis to return test data
        test_apis = [
            {"name": "user-api", "title": "User Management API", "description": "Manage users"},
            {"name": "order-api", "title": "Order API", "description": "Handle customer orders"},
            {"name": "product-api", "title": "Product Catalog", "description": "Product information"}
        ]
        
        connector.list_apis = Mock(return_value=test_apis)
        
        # Test search
        results = connector.search_apis("user")
        
        assert len(results) == 1
        assert results[0]["name"] == "user-api"
    
    def test_test_connection_no_session(self):
        """Test connection test when session is not available"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        connector = IBMAPIConnector()
        connector._session = None
        
        result = connector.test_connection()
        
        assert result["status"] == "error"
        assert "not available" in result["message"]

# Integration tests (require actual services)
class TestConnectorIntegration:
    """Integration tests for connectors (require real services)"""
    
    @skip_if_no_azure_config
    def test_azure_openai_real_conversion(self):
        """Test real Azure OpenAI conversion (requires actual service)"""
        # This test would only run if real Azure OpenAI config is available
        pass
    
    @skip_if_no_azure_config
    def test_azure_apim_real_connection(self):
        """Test real Azure APIM connection (requires actual service)"""
        # This test would only run if real Azure APIM config is available
        pass
    
    @skip_if_no_ibm_config
    def test_ibm_api_connect_real_connection(self):
        """Test real IBM API Connect connection (requires actual service)"""
        # This test would only run if real IBM config is available
        pass

# Error handling tests
class TestConnectorErrorHandling:
    """Test error handling in connectors"""
    
    def test_azure_openai_invalid_config(self):
        """Test Azure OpenAI with invalid configuration"""
        from connectors.azure_openai_connector import AzureOpenAIConnector
        from config import AzureConfig
        
        # Temporarily break config
        original_endpoint = AzureConfig.OPENAI_ENDPOINT
        AzureConfig.OPENAI_ENDPOINT = None
        
        try:
            connector = AzureOpenAIConnector()
            assert not connector.is_available
        finally:
            # Restore config
            AzureConfig.OPENAI_ENDPOINT = original_endpoint
    
    def test_azure_apim_network_error(self):
        """Test Azure APIM with network error"""
        from connectors.azure_apim_connector import AzureAPIMConnector
        
        connector = AzureAPIMConnector()
        connector._client = None  # Simulate no client
        
        result = connector.create_api_from_openapi(SAMPLE_OPENAPI_3_SPEC)
        assert result["status"] == "error"
    
    @patch('requests.Session')
    def test_ibm_authentication_failure(self, mock_session):
        """Test IBM API Connect authentication failure"""
        from connectors.ibm_api_connector import IBMAPIConnector
        
        # Mock failed authentication
        mock_response = Mock()
        mock_response.status_code = 401
        
        mock_session_instance = Mock()
        mock_session_instance.post.return_value = mock_response
        mock_session_instance.get.return_value = mock_response
        mock_session.return_value = mock_session_instance
        
        connector = IBMAPIConnector()
        connector._session = mock_session_instance
        
        result = connector._authenticate()
        assert result == False
        
        # Test connection should also fail
        connection_result = connector.test_connection()
        assert connection_result["status"] == "error"