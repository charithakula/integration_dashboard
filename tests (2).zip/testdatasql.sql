-- Test Data for API Migration Tool
-- This script inserts sample data for testing and development
-- Run with: psql -U api_user -d api_migration_db -f 02_test_data.sql

-- Make sure the schema is initialized first by running 01_init_schema.sql

BEGIN;

-- Insert sample migration records
INSERT INTO migration_records (
    migration_id, original_api_id, azure_api_id, api_name, api_version,
    status, completion_time, original_filename, converted_filename,
    file_size, conversion_method, ai_conversion_used, conversion_notes,
    created_at, start_time, end_time
) VALUES 
(
    'migration_001_petstore', 'petstore-api-v1', 'petstore-api-migrated',
    'Petstore API', '1.0.0', 'completed', 45.2,
    'petstore-swagger.json', 'petstore-openapi3.json', 12456,
    'ai', true, 'Successfully converted with AI assistance. All endpoints migrated correctly.',
    NOW() - INTERVAL '2 hours', NOW() - INTERVAL '2 hours 1 minute', NOW() - INTERVAL '2 hours'
),
(
    'migration_002_users', 'users-api-v2', 'users-api-v2-migrated',
    'Users Management API', '2.1.0', 'completed', 32.8,
    'users-api.yaml', 'users-api-openapi3.json', 8921,
    'fallback', false, 'Converted using fallback method due to AI service temporary unavailability',
    NOW() - INTERVAL '4 hours', NOW() - INTERVAL '4 hours 1 minute', NOW() - INTERVAL '4 hours'
),
(
    'migration_003_payments', 'payments-api-v1', NULL,
    'Payments API', '1.0.0', 'failed', NULL,
    'payments-swagger.json', NULL, 15678,
    NULL, false, 'Migration failed during validation phase',
    NOW() - INTERVAL '6 hours', NOW() - INTERVAL '6 hours 1 minute', NULL
),
(
    'migration_004_orders', 'orders-api-v1', NULL,
    'Orders Management API', '1.2.0', 'in_progress', NULL,
    'orders-api.yaml', NULL, 9834,
    'ai', true, 'Currently processing with Azure OpenAI. Conversion in progress.',
    NOW() - INTERVAL '15 minutes', NOW() - INTERVAL '15 minutes', NULL
),
(
    'migration_005_inventory', 'inventory-api-v3', 'inventory-api-migrated',
    'Inventory Management API', '3.0.0', 'completed', 28.5,
    'inventory-openapi.json', 'inventory-openapi3.json', 18456,
    'ai', true, 'Complex API with multiple schemas successfully migrated',
    NOW() - INTERVAL '1 day', NOW() - INTERVAL '1 day 1 minute', NOW() - INTERVAL '1 day'
),
(
    'migration_006_auth', 'auth-service-v2', 'auth-service-migrated',
    'Authentication Service API', '2.0.0', 'completed', 19.3,
    'auth-service.json', 'auth-service-openapi3.json', 7234,
    'ai', true, 'OAuth2 and JWT endpoints successfully converted',
    NOW() - INTERVAL '3 days', NOW() - INTERVAL '3 days 1 minute', NOW() - INTERVAL '3 days'
),
(
    'migration_007_notifications', 'notifications-api-v1', NULL,
    'Notifications API', '1.1.0', 'failed', NULL,
    'notifications.yaml', NULL, 5432,
    'fallback', false, 'Conversion failed: Unsupported webhook definitions',
    NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days 1 minute', NULL
),
(
    'migration_008_analytics', 'analytics-api-v4', NULL,
    'Analytics Dashboard API', '4.2.1', 'pending', NULL,
    'analytics-swagger.json', NULL, 23456,
    NULL, false, 'Queued for processing',
    NOW() - INTERVAL '10 minutes', NULL, NULL
);

-- Insert sample API specifications
INSERT INTO api_specifications (
    api_id, name, version, description, format, specification,
    source_platform, original_filename, file_size, is_valid,
    paths_count, operations_count, definitions_count, security_schemes_count
) VALUES 
(
    'petstore-api-v1', 'Petstore API', '1.0.0',
    'A sample API that uses a petstore as an example to demonstrate features in the OpenAPI specification',
    'swagger_2.0',
    '{"swagger": "2.0", "info": {"title": "Petstore API", "version": "1.0.0", "description": "A sample API that uses a petstore as an example"}, "host": "petstore.swagger.io", "basePath": "/v2", "schemes": ["https"], "paths": {"/pets": {"get": {"summary": "List all pets", "operationId": "listPets", "responses": {"200": {"description": "A paged array of pets"}}}, "post": {"summary": "Create a pet", "operationId": "createPets", "responses": {"201": {"description": "Pet created"}}}}, "/pets/{petId}": {"get": {"summary": "Info for a specific pet", "operationId": "showPetById", "parameters": [{"name": "petId", "in": "path", "required": true, "type": "string"}], "responses": {"200": {"description": "Expected response to a valid request"}}}}}, "definitions": {"Pet": {"type": "object", "required": ["id", "name"], "properties": {"id": {"type": "integer", "format": "int64"}, "name": {"type": "string"}, "tag": {"type": "string"}}}}}'::jsonb,
    'ibm_api_connect', 'petstore-swagger.json', 12456, true,
    2, 3, 1, 0
),
(
    'users-api-v2', 'Users Management API', '2.1.0',
    'API for managing user accounts, profiles, and authentication',
    'openapi_2.0',
    '{"swagger": "2.0", "info": {"title": "Users Management API", "version": "2.1.0", "description": "API for managing user accounts and profiles"}, "host": "api.userservice.com", "basePath": "/v2", "schemes": ["https"], "paths": {"/users": {"get": {"summary": "Get all users", "responses": {"200": {"description": "List of users"}}}, "post": {"summary": "Create user", "responses": {"201": {"description": "User created"}}}}, "/users/{id}": {"get": {"summary": "Get user by ID", "responses": {"200": {"description": "User details"}}}}, "/auth/login": {"post": {"summary": "User login", "responses": {"200": {"description": "Login successful"}}}}}}'::jsonb,
    'ibm_api_connect', 'users-api.yaml', 8921, true,
    3, 4, 0, 0
),
(
    'inventory-api-v3', 'Inventory Management API', '3.0.0',
    'Comprehensive inventory management system with real-time tracking',
    'swagger_2.0',
    '{"swagger": "2.0", "info": {"title": "Inventory Management API", "version": "3.0.0"}, "paths": {"/inventory": {"get": {"summary": "List inventory"}}, "/inventory/{id}": {"get": {"summary": "Get item"}}, "/suppliers": {"get": {"summary": "List suppliers"}}}}'::jsonb,
    'ibm_api_connect', 'inventory-openapi.json', 18456, true,
    3, 3, 0, 0
);

-- Insert sample migration logs
INSERT INTO migration_logs (migration_id, level, stage, message, details, timestamp) VALUES
-- Migration 001 logs (Petstore - Completed)
('migration_001_petstore', 'INFO', 'extraction', 'Starting API extraction from IBM API Connect', 
 '{"source": "ibm_api_connect", "org": "demo-org", "catalog": "sandbox"}'::jsonb, 
 NOW() - INTERVAL '2 hours 1 minute'),
('migration_001_petstore', 'INFO', 'extraction', 'Successfully extracted API specification', 
 '{"api_id": "petstore-api-v1", "size_kb": 12.4, "format": "swagger_2.0", "paths": 2, "operations": 3}'::jsonb, 
 NOW() - INTERVAL '2 hours 50 seconds'),
('migration_001_petstore', 'INFO', 'conversion', 'Starting OpenAPI conversion using Azure OpenAI', 
 '{"source_format": "swagger_2.0", "target_format": "openapi_3.0", "model": "gpt-4"}'::jsonb, 
 NOW() - INTERVAL '2 hours 45 seconds'),
('migration_001_petstore', 'INFO', 'conversion', 'AI conversion completed successfully', 
 '{"conversion_time_seconds": 15.3, "method": "azure_openai", "tokens_used": 2456, "success": true}'::jsonb, 
 NOW() - INTERVAL '2 hours 30 seconds'),
('migration_001_petstore', 'INFO', 'deployment', 'Deploying converted API to Azure APIM', 
 '{"azure_api_id": "petstore-api-migrated", "resource_group": "ai-rg", "service": "charith-apim-001"}'::jsonb, 
 NOW() - INTERVAL '2 hours 15 seconds'),
('migration_001_petstore', 'INFO', 'deployment', 'Successfully deployed to Azure APIM', 
 '{"azure_api_id": "petstore-api-migrated", "management_url": "https://charith-apim-001.management.azure-api.net", "status": "active"}'::jsonb, 
 NOW() - INTERVAL '2 hours'),

-- Migration 002 logs (Users - Completed with fallback)
('migration_002_users', 'INFO', 'extraction', 'Successfully extracted Users Management API', 
 '{"file_size_kb": 8.9, "paths_count": 3, "format": "yaml"}'::jsonb, 
 NOW() - INTERVAL '4 hours 50 seconds'),
('migration_002_users', 'WARNING', 'conversion', 'Azure OpenAI service temporarily unavailable, using fallback converter', 
 '{"fallback_method": "programmatic", "reason": "service_timeout", "retry_attempts": 3}'::jsonb, 
 NOW() - INTERVAL '4 hours 35 seconds'),
('migration_002_users', 'INFO', 'conversion', 'Fallback conversion completed successfully', 
 '{"conversion_time_seconds": 8.1, "method": "fallback", "warnings": 2}'::jsonb, 
 NOW() - INTERVAL '4 hours 25 seconds'),
('migration_002_users', 'INFO', 'deployment', 'Successfully deployed to Azure APIM using fallback conversion', 
 '{"azure_api_id": "users-api-v2-migrated", "notes": "Review recommended due to fallback conversion"}'::jsonb, 
 NOW() - INTERVAL '4 hours'),

-- Migration 003 logs (Payments - Failed)
('migration_003_payments', 'INFO', 'extraction', 'Starting extraction of Payments API', 
 '{"source_file": "payments-swagger.json", "size_kb": 15.3}'::jsonb, 
 NOW() - INTERVAL '6 hours 1 minute'),
('migration_003_payments', 'ERROR', 'extraction', 'Invalid OpenAPI specification detected', 
 '{"error": "missing_paths_section", "validation_errors": ["paths section is required", "info.title is missing"], "line": 45}'::jsonb, 
 NOW() - INTERVAL '6 hours 50 seconds'),
('migration_003_payments', 'ERROR', 'extraction', 'Migration failed during validation phase', 
 '{"error_type": "validation_error", "stage": "pre_conversion", "recommendation": "Fix specification format"}'::jsonb, 
 NOW() - INTERVAL '6 hours 45 seconds'),

-- Migration 004 logs (Orders - In Progress)
('migration_004_orders', 'INFO', 'extraction', 'Successfully extracted Orders Management API', 
 '{"file_size_kb": 9.8, "format": "yaml", "complexity": "medium"}'::jsonb, 
 NOW() - INTERVAL '15 minutes'),
('migration_004_orders', 'INFO', 'conversion', 'Starting AI conversion with Azure OpenAI', 
 '{"deployment": "gpt-4", "estimated_time_seconds": 25, "complexity_score": 7.2}'::jsonb, 
 NOW() - INTERVAL '12 minutes'),

-- Migration 005 logs (Inventory - Completed)
('migration_005_inventory', 'INFO', 'extraction', 'Complex API specification detected', 
 '{"schemas_count": 12, "paths_count": 15, "complexity": "high"}'::jsonb, 
 NOW() - INTERVAL '1 day 1 minute'),
('migration_005_inventory', 'INFO', 'conversion', 'AI conversion handling complex schemas', 
 '{"processing_schemas": 12, "estimated_time": 30}'::jsonb, 
 NOW() - INTERVAL '1 day 45 seconds'),
('migration_005_inventory', 'INFO', 'conversion', 'Successfully converted complex API structure', 
 '{"conversion_time_seconds": 28.5, "schemas_converted": 12, "paths_converted": 15}'::jsonb, 
 NOW() - INTERVAL '1 day 15 seconds'),
('migration_005_inventory', 'INFO', 'deployment', 'Deployed complex API to Azure APIM', 
 '{"azure_api_id": "inventory-api-migrated", "complexity_handled": true}'::jsonb, 
 NOW() - INTERVAL '1 day'),

-- Migration 007 logs (Notifications - Failed)
('migration_007_notifications', 'INFO', 'extraction', 'Extracted Notifications API', 
 '{"webhooks_detected": 5, "event_types": 12}'::jsonb, 
 NOW() - INTERVAL '5 days 1 minute'),
('migration_007_notifications', 'WARNING', 'conversion', 'Webhook definitions detected - may require manual review', 
 '{"webhook_count": 5, "supported": false}'::jsonb, 
 NOW() - INTERVAL '5 days 45 seconds'),
('migration_007_notifications', 'ERROR', 'conversion', 'Conversion failed: Unsupported webhook definitions', 
 '{"error_type": "unsupported_feature", "feature": "webhooks", "recommendation": "Manual conversion required"}'::jsonb, 
 NOW() - INTERVAL '5 days 30 seconds'),

-- Migration 008 logs (Analytics - Pending)
('migration_008_analytics', 'INFO', 'queue', 'Migration queued for processing', 
 '{"queue_position": 1, "estimated_start": "2 minutes"}'::jsonb, 
 NOW() - INTERVAL '10 minutes');

COMMIT;

-- Display summary of inserted test data
DO $$
BEGIN
    RAISE NOTICE 'Test data inserted successfully!';
    RAISE NOTICE '';
    RAISE NOTICE 'Migration Records: % inserted', (SELECT COUNT(*) FROM migration_records);
    RAISE NOTICE '  - Completed: %', (SELECT COUNT(*) FROM migration_records WHERE status = 'completed');
    RAISE NOTICE '  - Failed: %', (SELECT COUNT(*) FROM migration_records WHERE status = 'failed');
    RAISE NOTICE '  - In Progress: %', (SELECT COUNT(*) FROM migration_records WHERE status = 'in_progress');
    RAISE NOTICE '  - Pending: %', (SELECT COUNT(*) FROM migration_records WHERE status = 'pending');
    RAISE NOTICE '';
    RAISE NOTICE 'API Specifications: % inserted', (SELECT COUNT(*) FROM api_specifications);
    RAISE NOTICE 'Migration Logs: % inserted', (SELECT COUNT(*) FROM migration_logs);
    RAISE NOTICE '';
    RAISE NOTICE 'You can now test the application:';
    RAISE NOTICE '  1. python app.py';
    RAISE NOTICE '  2. Visit http://localhost:5000/history';
    RAISE NOTICE '  3. Test API: curl http://localhost:5000/api/migrations/stats';
END $$;

-- Show recent migrations for verification
SELECT 
    migration_id,
    api_name,
    status,
    created_at,
    completion_time
FROM migration_records 
ORDER BY created_at DESC;