-- PostgreSQL initialization script for API Migration Tool
-- This script sets up the database with proper permissions and optimizations

-- Create extensions if needed
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements";

-- Set timezone
SET timezone = 'UTC';

-- Grant necessary permissions to api_user
GRANT ALL PRIVILEGES ON DATABASE api_migration_db TO api_user;
GRANT ALL ON SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO api_user;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO api_user;

-- Create indexes for better performance (tables will be created by SQLAlchemy)
-- These will be applied after table creation

-- Function to create indexes after tables are created
CREATE OR REPLACE FUNCTION create_migration_indexes()
RETURNS void AS $$
BEGIN
    -- Check if tables exist before creating indexes
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'migration_records') THEN
        -- Indexes for migration_records table
        CREATE INDEX IF NOT EXISTS idx_migration_records_status ON migration_records(status);
        CREATE INDEX IF NOT EXISTS idx_migration_records_created_at ON migration_records(created_at);
        CREATE INDEX IF NOT EXISTS idx_migration_records_api_name ON migration_records(api_name);
        CREATE INDEX IF NOT EXISTS idx_migration_records_migration_id ON migration_records(migration_id);
        CREATE INDEX IF NOT EXISTS idx_migration_records_original_api_id ON migration_records(original_api_id);
        
        RAISE NOTICE 'Indexes created for migration_records table';
    END IF;
    
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'api_specifications') THEN
        -- Indexes for api_specifications table
        CREATE INDEX IF NOT EXISTS idx_api_specifications_format ON api_specifications(format);
        CREATE INDEX IF NOT EXISTS idx_api_specifications_api_id ON api_specifications(api_id);
        CREATE INDEX IF NOT EXISTS idx_api_specifications_name ON api_specifications(name);
        CREATE INDEX IF NOT EXISTS idx_api_specifications_created_at ON api_specifications(created_at);
        
        RAISE NOTICE 'Indexes created for api_specifications table';
    END IF;
    
    IF EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'migration_logs') THEN
        -- Indexes for migration_logs table
        CREATE INDEX IF NOT EXISTS idx_migration_logs_migration_id ON migration_logs(migration_id);
        CREATE INDEX IF NOT EXISTS idx_migration_logs_timestamp ON migration_logs(timestamp);
        CREATE INDEX IF NOT EXISTS idx_migration_logs_level ON migration_logs(level);
        
        RAISE NOTICE 'Indexes created for migration_logs table';
    END IF;
END;
$$ LANGUAGE plpgsql;

-- Configure PostgreSQL settings for better performance
ALTER SYSTEM SET shared_preload_libraries = 'pg_stat_statements';
ALTER SYSTEM SET pg_stat_statements.track = 'all';
ALTER SYSTEM SET log_statement = 'mod';
ALTER SYSTEM SET log_min_duration_statement = 1000;

-- Create a function to get database statistics
CREATE OR REPLACE FUNCTION get_migration_stats()
RETURNS TABLE(
    table_name text,
    row_count bigint,
    table_size text
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.table_name::text,
        (SELECT COUNT(*) FROM migration_records WHERE t.table_name = 'migration_records')::bigint as row_count,
        pg_size_pretty(pg_total_relation_size(t.table_name::regclass))::text as table_size
    FROM information_schema.tables t
    WHERE t.table_schema = 'public' 
    AND t.table_type = 'BASE TABLE'
    AND t.table_name IN ('migration_records', 'api_specifications', 'migration_logs');
END;
$$ LANGUAGE plpgsql;

-- Create a cleanup function for old logs
CREATE OR REPLACE FUNCTION cleanup_old_logs(days_to_keep integer DEFAULT 30)
RETURNS integer AS $$
DECLARE
    deleted_count integer;
BEGIN
    DELETE FROM migration_logs 
    WHERE timestamp < NOW() - INTERVAL '1 day' * days_to_keep
    AND level = 'INFO';
    
    GET DIAGNOSTICS deleted_count = ROW_COUNT;
    
    RAISE NOTICE 'Cleaned up % old log entries', deleted_count;
    RETURN deleted_count;
END;
$$ LANGUAGE plpgsql;

-- Grant execute permissions on functions
GRANT EXECUTE ON FUNCTION create_migration_indexes() TO api_user;
GRANT EXECUTE ON FUNCTION get_migration_stats() TO api_user;
GRANT EXECUTE ON FUNCTION cleanup_old_logs(integer) TO api_user;

-- Set up a simple view for migration dashboard
CREATE OR REPLACE VIEW migration_dashboard AS
SELECT 
    COUNT(*) FILTER (WHERE status = 'completed') as completed_migrations,
    COUNT(*) FILTER (WHERE status = 'failed') as failed_migrations,
    COUNT(*) FILTER (WHERE status = 'in_progress') as in_progress_migrations,
    COUNT(*) as total_migrations,
    ROUND(
        (COUNT(*) FILTER (WHERE status = 'completed')::numeric / 
         NULLIF(COUNT(*), 0) * 100), 2
    ) as success_rate,
    AVG(completion_time) FILTER (WHERE completion_time IS NOT NULL) as avg_completion_time
FROM migration_records;

GRANT SELECT ON migration_dashboard TO api_user;

-- Log successful initialization
INSERT INTO pg_stat_statements_info DEFAULT VALUES ON CONFLICT DO NOTHING;

-- Notify that initialization is complete
DO $$
BEGIN
    RAISE NOTICE 'API Migration Tool PostgreSQL database initialized successfully';
    RAISE NOTICE 'Database: %', current_database();
    RAISE NOTICE 'User: api_user has been granted all necessary permissions';
    RAISE NOTICE 'Performance optimizations and indexes will be created after table creation';
END $$;