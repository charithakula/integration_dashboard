"""
Models package for database models and data structures
Contains SQLAlchemy models and Pydantic schemas
"""

from .database import db, MigrationRecord, APISpecification, MigrationLog
from .schemas import (
    MigrationRecordSchema,
    APISpecificationSchema,
    ConversionRequestSchema,
    ConversionResponseSchema,
    MigrationRequestSchema,
    MigrationResponseSchema,
    ValidationResultSchema
)

__all__ = [
    # Database models
    'db',
    'MigrationRecord',
    'APISpecification', 
    'MigrationLog',
    
    # Pydantic schemas
    'MigrationRecordSchema',
    'APISpecificationSchema',
    'ConversionRequestSchema',
    'ConversionResponseSchema',
    'MigrationRequestSchema',
    'MigrationResponseSchema',
    'ValidationResultSchema'
]