import os
from pathlib import Path

# Define the folder and file structure
project_structure = {
    "": [  # root files
        "requirements.txt",
        ".env.example",
        ".gitignore",
        "config.py",
        "app.py",
    ],
    "connectors": [
        "__init__.py",
        "azure_openai_connector.py",
        "azure_apim_connector.py",
        "ibm_api_connector.py",
    ],
    "services": [
        "__init__.py",
        "conversion_service.py",
        "migration_service.py",
        "validation_service.py",
    ],
    "models": [
        "__init__.py",
        "database.py",
        "schemas.py",
    ],
    "utils": [
        "__init__.py",
        "logger.py",
        "file_handler.py",
        "helpers.py",
    ],
    "templates": [
        "base.html",
        "index.html",
        "upload.html",
        "migration_history.html",
    ],
    "static/css": [
        "style.css",
    ],
    "static/js": [
        "app.js",
    ],
    "tests": [
        "__init__.py",
        "test_connectors.py",
        "test_services.py",
        "test_app.py",
    ],
    "": [
        "README.md",
    ],
}


def create_project_structure(base_path="."):
    base = Path(base_path)

    for folder, files in project_structure.items():
        folder_path = base / folder
        folder_path.mkdir(parents=True, exist_ok=True)

        for file in files:
            file_path = folder_path / file
            if not file_path.exists():  # avoid overwriting existing files
                file_path.write_text("")  # create empty file
                print(f"Created: {file_path}")


if __name__ == "__main__":
    create_project_structure("my_project")
