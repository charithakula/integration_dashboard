"""
Main Flask Application
Entry point for the API Migration Tool
Updated for Flask 3.x compatibility
"""
import os
import json
from flask import Flask, render_template, request, jsonify, redirect, url_for, flash, send_file
from flask_cors import CORS
from werkzeug.exceptions import RequestEntityTooLarge
from datetime import datetime
import logging

# Import configuration
from config import get_config, validate_all_configurations, get_missing_configurations

# Import database
from models.database import db, init_database, get_database_statistics

# Import services
from services import ConversionService, MigrationService, ValidationService

# Import connectors
from connectors import AzureAPIMConnector, AzureOpenAIConnector, IBMAPIConnector

# Import utilities
from utils import setup_logger, FileHandler, generate_id

# Import schemas for validation
from models.schemas import (
    ConversionRequestSchema, MigrationRequestSchema, BatchMigrationRequestSchema,
    FileUploadSchema, ValidationErrorSchema
)

def create_app():
    """Application factory pattern for Flask 3.x"""
    # Initialize Flask app
    app = Flask(__name__)

    # Load configuration
    config = get_config()
    app.config.from_object(config)

    # Initialize extensions
    CORS(app)
    db.init_app(app)

    # Initialize logging
    logger = setup_logger('app')

    # Global variables for tracking
    app_start_time = datetime.now()

    # Initialize application within app context
    with app.app_context():
        try:
            # Initialize database
            init_database(app)
            
            # Validate configurations
            missing_configs = get_missing_configurations()
            if missing_configs:
                logger.warning(f"Missing configurations: {missing_configs}")
            
            logger.info("Application initialized successfully")
            
        except Exception as e:
            logger.error(f"Failed to initialize application: {e}")

    # Initialize services (moved outside app context)
    conversion_service = ConversionService()
    migration_service = MigrationService()
    validation_service = ValidationService()

    # Initialize file handler
    file_handler = FileHandler()

    # Error handlers
    @app.errorhandler(404)
    def not_found_error(error):
        """Handle 404 errors"""
        if request.is_json:
            return jsonify({'error': 'Resource not found'}), 404
        # Return simple HTML response instead of missing template
        return '''
        <html>
        <head><title>404 - Page Not Found</title></head>
        <body>
        <h1>404 - Page Not Found</h1>
        <p>The page you are looking for could not be found.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 404

    @app.errorhandler(500)
    def internal_error(error):
        """Handle 500 errors"""
        logger.error(f"Internal server error: {error}")
        if request.is_json:
            return jsonify({'error': 'Internal server error'}), 500
        # Return simple HTML response instead of missing template
        return '''
        <html>
        <head><title>500 - Internal Server Error</title></head>
        <body>
        <h1>500 - Internal Server Error</h1>
        <p>Something went wrong on our end.</p>
        <a href="/">Go back to home</a>
        </body>
        </html>
        ''', 500

    @app.errorhandler(RequestEntityTooLarge)
    def file_too_large(error):
        """Handle file too large errors"""
        if request.is_json:
            return jsonify({'error': 'File too large', 'max_size': '16MB'}), 413
        flash('File is too large. Maximum size is 16MB.', 'error')
        return redirect(url_for('upload_page'))

    # Main routes
    @app.route('/')
    def index():
        """Main dashboard page"""
        try:
            # Get basic statistics
            db_stats = get_database_statistics()
            
            # Check service availability
            prerequisites = migration_service.validate_migration_prerequisites()
            
            # Get recent migrations (placeholder for now)
            recent_migrations = []
            
            return render_template('index.html', 
                                 stats=db_stats,
                                 prerequisites=prerequisites,
                                 recent_migrations=recent_migrations)
            
        except Exception as e:
            logger.error(f"Failed to load dashboard: {e}")
            flash('Failed to load dashboard data', 'error')
            return render_template('index.html', stats={}, prerequisites={}, recent_migrations=[])

    @app.route('/upload')
    def upload_page():
        """File upload page"""
        return render_template('upload.html')

    @app.route('/history')
    def migration_history():
        """Migration history page"""
        try:
            # Get pagination parameters
            page = request.args.get('page', 1, type=int)
            per_page = request.args.get('per_page', 20, type=int)
            
            # Get migration history (placeholder)
            migrations = []
            total_migrations = 0
            
            pagination = {
                'page': page,
                'per_page': per_page,
                'total': total_migrations,
                'pages': (total_migrations + per_page - 1) // per_page
            }
            
            return render_template('migration_history.html', 
                                 migrations=migrations, 
                                 pagination=pagination)
            
        except Exception as e:
            logger.error(f"Failed to load migration history: {e}")
            flash('Failed to load migration history', 'error')
            return render_template('migration_history.html', migrations=[], pagination={})

    # API endpoints
    @app.route('/api/health')
    def health_check():
        """Health check endpoint"""
        uptime = (datetime.now() - app_start_time).total_seconds()
        
        # Check service connections
        service_status = {
            'ibm_api_connect': IBMAPIConnector().test_connection(),
            'azure_apim': AzureAPIMConnector().test_connection(),
            'azure_openai': AzureOpenAIConnector().test_connection()
        }
        
        # Determine overall health
        all_services_healthy = all(
            status.get('status') == 'success' 
            for status in service_status.values()
        )
        
        return jsonify({
            'status': 'healthy' if all_services_healthy else 'degraded',
            'timestamp': datetime.now().isoformat(),
            'uptime_seconds': int(uptime),
            'version': '1.0.0',
            'services': service_status
        })

    @app.route('/api/upload', methods=['POST'])
    def upload_file():
        """Handle file upload"""
        try:
            if 'file' not in request.files:
                return jsonify({'error': 'No file provided'}), 400
            
            file = request.files['file']
            if file.filename == '':
                return jsonify({'error': 'No file selected'}), 400
            
            # Save uploaded file
            save_result = file_handler.save_uploaded_file(file, prefix='upload')
            
            if not save_result['success']:
                return jsonify({'error': save_result['error']}), 400
            
            # Read and parse file content
            content_result = file_handler.read_file_content(save_result['file_path'])
            
            if not content_result['success']:
                # Clean up failed file
                file_handler.delete_file(save_result['filename'])
                return jsonify({'error': content_result['error']}), 400
            
            # Extract API information
            if content_result['parsed_content']:
                from utils.helpers import extract_api_info
                api_info = extract_api_info(content_result['parsed_content'])
            else:
                api_info = {}
            
            return jsonify({
                'success': True,
                'file_info': save_result,
                'content_info': {
                    'type': content_result['content_type'],
                    'size': content_result['file_size']
                },
                'api_info': api_info,
                'message': 'File uploaded successfully'
            })
            
        except Exception as e:
            logger.error(f"File upload failed: {e}")
            return jsonify({'error': f'Upload failed: {str(e)}'}), 500

    @app.route('/api/convert', methods=['POST'])
    def convert_api():
        """Convert OpenAPI specification"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            # Validate request data
            try:
                request_data = ConversionRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            # Perform conversion
            conversion_result = conversion_service.convert_specification(
                request_data.spec_content,
                request_data.source_format
            )
            
            return jsonify(conversion_result)
            
        except Exception as e:
            logger.error(f"Conversion failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Conversion failed: {str(e)}'
            }), 500

    @app.route('/api/convert/preview', methods=['POST'])
    def conversion_preview():
        """Get conversion preview without performing full conversion"""
        try:
            data = request.get_json()
            if not data or 'spec_content' not in data:
                return jsonify({'error': 'No specification content provided'}), 400
            
            # Get conversion preview
            preview_result = conversion_service.get_conversion_preview(data['spec_content'])
            
            return jsonify(preview_result)
            
        except Exception as e:
            logger.error(f"Conversion preview failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Preview failed: {str(e)}'
            }), 500

    @app.route('/api/migrate', methods=['POST'])
    def migrate_api():
        """Migrate single API"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            # Validate request data
            try:
                request_data = MigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            # Handle single API migration
            api_id = request_data.api_ids[0] if isinstance(request_data.api_ids, list) else request_data.api_ids
            
            migration_result = migration_service.migrate_single_api(
                api_id,
                request_data.org_name,
                request_data.options
            )
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Migration failed: {str(e)}'
            }), 500

    @app.route('/api/migrate/batch', methods=['POST'])
    def migrate_batch():
        """Migrate multiple APIs"""
        try:
            data = request.get_json()
            if not data:
                return jsonify({'error': 'No JSON data provided'}), 400
            
            # Validate request data
            try:
                request_data = BatchMigrationRequestSchema(**data)
            except Exception as e:
                return jsonify({'error': f'Invalid request data: {str(e)}'}), 400
            
            # Perform batch migration based on type
            if request_data.migration_type == 'apis':
                migration_result = migration_service.migrate_multiple_apis(
                    request_data.api_ids,
                    request_data.org_name,
                    request_data.options
                )
            elif request_data.migration_type == 'catalog':
                migration_result = migration_service.migrate_by_catalog(
                    request_data.org_name,
                    request_data.catalog_name,
                    request_data.options
                )
            else:
                return jsonify({'error': 'Invalid migration type'}), 400
            
            return jsonify(migration_result)
            
        except Exception as e:
            logger.error(f"Batch migration failed: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Batch migration failed: {str(e)}'
            }), 500

    @app.route('/api/prerequisites')
    @app.route('/api/migrate/prerequisites')
    def check_prerequisites():
        """Check migration prerequisites"""
        try:
            prerequisites = migration_service.validate_migration_prerequisites()
            return jsonify(prerequisites)
            
        except Exception as e:
            logger.error(f"Prerequisites check failed: {e}")
            return jsonify({
                'all_services_available': False,
                'error': f'Prerequisites check failed: {str(e)}'
            }), 500

    @app.route('/api/migrations')
    def list_migrations():
        """List migrations with pagination"""
        try:
            limit = request.args.get('limit', 50, type=int)
            offset = request.args.get('offset', 0, type=int)
            
            migrations_result = migration_service.list_migrations(limit, offset)
            
            return jsonify(migrations_result)
            
        except Exception as e:
            logger.error(f"Failed to list migrations: {e}")
            return jsonify({
                'migrations': [],
                'total_count': 0,
                'error': f'Failed to list migrations: {str(e)}'
            }), 500

    @app.route('/api/migrations/<migration_id>')
    def get_migration_status(migration_id):
        """Get specific migration status"""
        try:
            migration_status = migration_service.get_migration_status(migration_id)
            return jsonify(migration_status)
            
        except Exception as e:
            logger.error(f"Failed to get migration status: {e}")
            return jsonify({
                'error': f'Failed to get migration status: {str(e)}'
            }), 500

    @app.route('/api/migrations/<migration_id>/rollback', methods=['POST'])
    def rollback_migration(migration_id):
        """Rollback migration"""
        try:
            rollback_result = migration_service.rollback_migration(migration_id)
            return jsonify(rollback_result)
            
        except Exception as e:
            logger.error(f"Failed to rollback migration: {e}")
            return jsonify({
                'status': 'error',
                'message': f'Rollback failed: {str(e)}'
            }), 500

    @app.route('/api/ibm/apis')
    def list_ibm_apis():
        """List APIs from IBM API Connect"""
        try:
            org_name = request.args.get('org_name')
            
            ibm_connector = IBMAPIConnector()
            if not ibm_connector.is_available:
                return jsonify({
                    'error': 'IBM API Connect connection not available'
                }), 503
            
            apis = ibm_connector.list_apis(org_name)
            
            return jsonify({
                'status': 'success',
                'apis': apis,
                'total_apis': len(apis)
            })
            
        except Exception as e:
            logger.error(f"Failed to list IBM APIs: {e}")
            return jsonify({
                'error': f'Failed to list IBM APIs: {str(e)}'
            }), 500

    @app.route('/api/azure/apis')
    def list_azure_apis():
        """List APIs from Azure APIM"""
        try:
            azure_connector = AzureAPIMConnector()
            if not azure_connector.is_available:
                return jsonify({
                    'error': 'Azure APIM connection not available'
                }), 503
            
            apis = azure_connector.list_apis()
            
            return jsonify({
                'status': 'success',
                'apis': apis,
                'total_apis': len(apis)
            })
            
        except Exception as e:
            logger.error(f"Failed to list Azure APIs: {e}")
            return jsonify({
                'error': f'Failed to list Azure APIs: {str(e)}'
            }), 500

    @app.route('/api/statistics')
    def get_statistics():
        """Get application statistics"""
        try:
            db_stats = get_database_statistics()
            migration_stats = migration_service.get_migration_statistics()
            
            uptime = (datetime.now() - app_start_time).total_seconds()
            
            return jsonify({
                'database': db_stats,
                'migrations': migration_stats,
                'application': {
                    'uptime_seconds': int(uptime),
                    'start_time': app_start_time.isoformat(),
                    'version': '1.0.0'
                }
            })
            
        except Exception as e:
            logger.error(f"Failed to get statistics: {e}")
            return jsonify({
                'error': f'Failed to get statistics: {str(e)}'
            }), 500

    @app.route('/api/files')
    def list_files():
        """List uploaded files"""
        try:
            files_result = file_handler.list_files()
            return jsonify(files_result)
            
        except Exception as e:
            logger.error(f"Failed to list files: {e}")
            return jsonify({
                'error': f'Failed to list files: {str(e)}'
            }), 500

    @app.route('/api/files/<filename>')
    def get_file_info(filename):
        """Get file information"""
        try:
            file_info = file_handler.get_file_info(filename)
            return jsonify(file_info)
            
        except Exception as e:
            logger.error(f"Failed to get file info: {e}")
            return jsonify({
                'error': f'Failed to get file info: {str(e)}'
            }), 500

    @app.route('/api/files/<filename>/download')
    def download_file(filename):
        """Download file"""
        try:
            file_path = os.path.join(file_handler.upload_folder, filename)
            
            if not os.path.exists(file_path):
                return jsonify({'error': 'File not found'}), 404
            
            return send_file(file_path, as_attachment=True)
            
        except Exception as e:
            logger.error(f"Failed to download file: {e}")
            return jsonify({
                'error': f'Failed to download file: {str(e)}'
            }), 500

    # Template filters
    @app.template_filter('datetime')
    def datetime_filter(value, format='%Y-%m-%d %H:%M:%S'):
        """Format datetime for templates"""
        if isinstance(value, str):
            try:
                value = datetime.fromisoformat(value.replace('Z', '+00:00'))
            except:
                return value
        
        if isinstance(value, datetime):
            return value.strftime(format)
        
        return value

    @app.template_filter('filesize')
    def filesize_filter(value):
        """Format file size for templates"""
        from utils.helpers import format_file_size
        return format_file_size(value)

    @app.route('/test-static')
    def test_static():
        """Test route to verify static files are working"""
        return '''
        <!DOCTYPE html>
        <html>
        <head>
            <title>Static File Test</title>
            <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
            <link href="/static/css/style.css" rel="stylesheet">
        </head>
        <body>
            <div class="container mt-5">
                <div class="alert alert-success">
                    <h4>Static Files Test</h4>
                    <p>If you can see this styled properly, your static files are working!</p>
                    <div class="card mt-3">
                        <div class="card-body">
                            <h5 class="card-title">Test Card</h5>
                            <p class="card-text">This should be styled with your custom CSS.</p>
                        </div>
                    </div>
                </div>
            </div>
        </body>
        </html>
        '''

    # Template context processors
    @app.context_processor
    def inject_global_vars():
        """Inject global variables into templates"""
        return {
            'app_version': '1.0.0',
            'current_year': datetime.now().year
        }

    return app

# Create app instance
app = create_app()

if __name__ == '__main__':
    # Create necessary directories
    os.makedirs('logs', exist_ok=True)
    os.makedirs('static/uploads', exist_ok=True)
    
    # Initialize logging
    logger = setup_logger('app')
    
    # Run the application
    port = int(os.environ.get('PORT', 5000))
    debug = os.environ.get('FLASK_DEBUG', 'False').lower() == 'true'
    
    logger.info(f"Starting API Migration Tool on port {port}")
    app.run(host='0.0.0.0', port=port, debug=debug)