"""
Azure API Management Connector
Handles CRUD operations for APIs in Azure API Management
"""
import json
import logging
import requests
from typing import Dict, Any, List, Optional
from azure.identity import ClientSecretCredential
from azure.mgmt.apimanagement import ApiManagementClient
from azure.mgmt.apimanagement.models import (
    ApiCreateOrUpdateParameter,
    ApiContract,
    ApiVersionSetContract,
    ApiVersionSetEntityBase
)
from config import AzureConfig

logger = logging.getLogger(__name__)

class AzureAPIMConnector:
    """Azure API Management service connector"""
    
    def __init__(self):
        """Initialize Azure APIM client"""
        self.config = AzureConfig
        self._credential = None
        self._client = None
        self._initialize_client()
    
    def _initialize_client(self) -> bool:
        """Initialize Azure APIM client with service principal authentication"""
        try:
            # Validate configuration
            missing_config = self.config.validate_azure_config() + self.config.validate_apim_config()
            if missing_config:
                logger.error(f"Missing Azure APIM configuration: {missing_config}")
                return False
            
            # Create credential
            self._credential = ClientSecretCredential(
                tenant_id=self.config.TENANT_ID,
                client_id=self.config.CLIENT_ID,
                client_secret=self.config.CLIENT_SECRET
            )
            
            # Initialize APIM client
            self._client = ApiManagementClient(
                credential=self._credential,
                subscription_id=self.config.SUBSCRIPTION_ID
            )
            
            logger.info("Azure APIM client initialized successfully")
            return True
            
        except Exception as e:
            logger.error(f"Failed to initialize Azure APIM client: {e}")
            self._client = None
            return False
    
    @property
    def is_available(self) -> bool:
        """Check if Azure APIM service is available"""
        return self._client is not None
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to Azure APIM service"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': 'Azure APIM client not initialized'
            }
        
        try:
            # Test by listing APIs (should return even if empty)
            apis = self._client.api.list_by_service(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME
            )
            
            api_count = sum(1 for _ in apis)
            
            return {
                'status': 'success',
                'message': 'Azure APIM connection successful',
                'service_name': self.config.APIM_SERVICE_NAME,
                'api_count': api_count
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Azure APIM connection failed: {str(e)}'
            }
    
    def list_apis(self) -> List[Dict[str, Any]]:
        """List all APIs in the APIM service"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            apis = self._client.api.list_by_service(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME
            )
            
            api_list = []
            for api in apis:
                api_info = {
                    'id': api.name,
                    'display_name': api.display_name,
                    'description': api.description,
                    'service_url': api.service_url,
                    'path': api.path,
                    'protocols': api.protocols,
                    'api_version': api.api_version,
                    'api_version_set_id': api.api_version_set_id,
                    'is_current': api.is_current,
                    'subscription_required': api.subscription_required
                }
                api_list.append(api_info)
            
            logger.info(f"Retrieved {len(api_list)} APIs from Azure APIM")
            return api_list
            
        except Exception as e:
            logger.error(f"Failed to list APIs: {e}")
            raise
    
    def get_api(self, api_id: str) -> Optional[Dict[str, Any]]:
        """Get specific API details"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            api = self._client.api.get(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                api_id=api_id
            )
            
            return {
                'id': api.name,
                'display_name': api.display_name,
                'description': api.description,
                'service_url': api.service_url,
                'path': api.path,
                'protocols': api.protocols,
                'api_version': api.api_version,
                'api_version_set_id': api.api_version_set_id,
                'is_current': api.is_current,
                'subscription_required': api.subscription_required
            }
            
        except Exception as e:
            logger.error(f"Failed to get API {api_id}: {e}")
            return None
    
    def create_api_from_openapi(self, openapi_spec: Dict[str, Any], api_id: Optional[str] = None) -> Dict[str, Any]:
        """Create API in APIM from OpenAPI 3.0 specification"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # Extract API information from OpenAPI spec
            api_info = self._extract_api_info(openapi_spec)
            
            # Generate API ID if not provided
            if not api_id:
                api_id = self._generate_api_id(api_info['title'])
            
            # Prepare API creation parameters
            api_params = ApiCreateOrUpdateParameter(
                display_name=api_info['title'],
                description=api_info.get('description', ''),
                service_url=api_info.get('service_url'),
                path=api_info.get('path', api_id),
                protocols=api_info.get('protocols', ['https']),
                api_version=api_info.get('version'),
                format='openapi+json',
                value=json.dumps(openapi_spec)
            )
            
            # Create the API
            result = self._client.api.begin_create_or_update(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                api_id=api_id,
                parameters=api_params
            ).result()
            
            logger.info(f"Successfully created API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'display_name': result.display_name,
                'path': result.path,
                'service_url': result.service_url,
                'message': f'API {api_id} created successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to create API: {e}")
            return {
                'status': 'error',
                'message': f'Failed to create API: {str(e)}'
            }
    
    def update_api(self, api_id: str, openapi_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Update existing API with new OpenAPI specification"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # Extract API information from OpenAPI spec
            api_info = self._extract_api_info(openapi_spec)
            
            # Prepare API update parameters
            api_params = ApiCreateOrUpdateParameter(
                display_name=api_info['title'],
                description=api_info.get('description', ''),
                service_url=api_info.get('service_url'),
                api_version=api_info.get('version'),
                format='openapi+json',
                value=json.dumps(openapi_spec)
            )
            
            # Update the API
            result = self._client.api.begin_create_or_update(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                api_id=api_id,
                parameters=api_params
            ).result()
            
            logger.info(f"Successfully updated API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'display_name': result.display_name,
                'message': f'API {api_id} updated successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to update API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to update API: {str(e)}'
            }
    
    def delete_api(self, api_id: str) -> Dict[str, Any]:
        """Delete API from APIM"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            self._client.api.delete(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                api_id=api_id,
                if_match='*'
            )
            
            logger.info(f"Successfully deleted API: {api_id}")
            
            return {
                'status': 'success',
                'api_id': api_id,
                'message': f'API {api_id} deleted successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to delete API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to delete API: {str(e)}'
            }
    
    def _extract_api_info(self, openapi_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Extract API information from OpenAPI specification"""
        info = openapi_spec.get('info', {})
        servers = openapi_spec.get('servers', [])
        
        # Extract service URL from servers
        service_url = None
        if servers:
            service_url = servers[0].get('url')
        
        # Extract path prefix
        path = info.get('title', '').lower().replace(' ', '-')
        
        return {
            'title': info.get('title', 'Migrated API'),
            'description': info.get('description', 'API migrated from IBM API Connect'),
            'version': info.get('version', '1.0.0'),
            'service_url': service_url,
            'path': path,
            'protocols': ['https']  # Default to HTTPS
        }
    
    def _generate_api_id(self, title: str) -> str:
        """Generate API ID from title"""
        return title.lower().replace(' ', '-').replace('_', '-')
    
    def create_product(self, product_name: str, api_ids: List[str], description: str = "") -> Dict[str, Any]:
        """Create a product and associate APIs with it"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            from azure.mgmt.apimanagement.models import ProductContract
            
            # Create product parameters
            product_params = ProductContract(
                display_name=product_name,
                description=description or f"Product for {product_name}",
                subscription_required=True,
                approval_required=False,
                state='published'
            )
            
            # Create product
            product = self._client.product.create_or_update(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                product_id=product_name.lower().replace(' ', '-'),
                parameters=product_params
            )
            
            # Associate APIs with product
            for api_id in api_ids:
                self._client.product_api.create_or_update(
                    resource_group_name=self.config.APIM_RESOURCE_GROUP,
                    service_name=self.config.APIM_SERVICE_NAME,
                    product_id=product.name,
                    api_id=api_id
                )
            
            logger.info(f"Successfully created product: {product_name} with {len(api_ids)} APIs")
            
            return {
                'status': 'success',
                'product_id': product.name,
                'display_name': product.display_name,
                'api_count': len(api_ids),
                'message': f'Product {product_name} created successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to create product {product_name}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to create product: {str(e)}'
            }
    
    def get_api_management_url(self, api_id: str) -> str:
        """Get the management URL for an API"""
        return f"https://portal.azure.com/#@{self.config.TENANT_ID}/resource/subscriptions/{self.config.SUBSCRIPTION_ID}/resourceGroups/{self.config.APIM_RESOURCE_GROUP}/providers/Microsoft.ApiManagement/service/{self.config.APIM_SERVICE_NAME}/apis/{api_id}"
    
    def get_developer_portal_url(self) -> str:
        """Get the developer portal URL"""
        return f"https://{self.config.APIM_SERVICE_NAME}.developer.azure-api.net"
    
    def export_api(self, api_id: str, export_format: str = 'openapi+json') -> Dict[str, Any]:
        """Export API specification from APIM"""
        if not self.is_available:
            raise RuntimeError("Azure APIM client not available")
        
        try:
            # Export API
            export_result = self._client.api_export.get(
                resource_group_name=self.config.APIM_RESOURCE_GROUP,
                service_name=self.config.APIM_SERVICE_NAME,
                api_id=api_id,
                format=export_format
            )
            
            return {
                'status': 'success',
                'api_id': api_id,
                'format': export_format,
                'specification': export_result.value,
                'message': f'API {api_id} exported successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to export API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to export API: {str(e)}'
            }