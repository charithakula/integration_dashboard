"""
Azure OpenAI Connector
Handles OpenAPI 2.0 to 3.0 conversion using Azure OpenAI services
Updated for OpenAI v1.108.1 and graceful error handling
"""
import json
import logging
import yaml
from typing import Dict, Any, Optional, Tuple
from config import AzureConfig

logger = logging.getLogger(__name__)

class AzureOpenAIConnector:
    """Azure OpenAI service connector for API specification conversion"""
    
    def __init__(self):
        """Initialize Azure OpenAI client"""
        self.config = AzureConfig
        self._client = None
        self.is_initialized = False
        self._initialization_error = None
        
        # Try to initialize, but don't fail if it doesn't work
        try:
            self._initialize_client()
        except Exception as e:
            logger.warning(f"Azure OpenAI connector initialization failed: {e}")
            self._initialization_error = str(e)
    
    def _initialize_client(self) -> bool:
        """Initialize Azure OpenAI client with configuration validation"""
        try:
            # Validate configuration first
            missing_config = self.config.validate_openai_config()
            if missing_config:
                logger.warning(f"Missing Azure OpenAI configuration: {missing_config}")
                self._initialization_error = f"Missing configuration: {missing_config}"
                return False
            
            # Only import and initialize if config is valid
            try:
                from openai import AzureOpenAI
                
                # Initialize client with new v1.108.1 syntax
                self._client = AzureOpenAI(
                    azure_endpoint=self.config.OPENAI_ENDPOINT,
                    api_key=self.config.OPENAI_API_KEY,
                    api_version=self.config.OPENAI_VERSION,
                    # Add timeout and other options for better reliability
                    timeout=30.0,
                    max_retries=2
                )
                
                self.is_initialized = True
                logger.info("Azure OpenAI client initialized successfully")
                return True
                
            except ImportError as e:
                logger.warning(f"OpenAI library not properly installed: {e}")
                self._initialization_error = f"OpenAI library import failed: {e}"
                return False
            
        except Exception as e:
            logger.warning(f"Failed to initialize Azure OpenAI client: {e}")
            self._client = None
            self.is_initialized = False
            self._initialization_error = str(e)
            return False
    
    @property
    def is_available(self) -> bool:
        """Check if Azure OpenAI service is available"""
        return self._client is not None and self.is_initialized
    
    def get_initialization_error(self) -> Optional[str]:
        """Get the initialization error if any"""
        return self._initialization_error
    
    def parse_api_spec(self, content: str) -> Tuple[Dict[str, Any], str]:
        """
        Parse API specification from JSON or YAML
        Returns: (parsed_spec, original_format)
        """
        try:
            # Try JSON first
            spec = json.loads(content)
            return spec, 'json'
        except json.JSONDecodeError:
            try:
                # Try YAML
                spec = yaml.safe_load(content)
                return spec, 'yaml'
            except yaml.YAMLError as e:
                raise ValueError(f"Invalid JSON or YAML format: {e}")
    
    def convert_openapi_2_to_3(self, spec_content: str) -> Dict[str, Any]:
        """
        Convert OpenAPI 2.0 to 3.0 using Azure OpenAI
        Returns converted OpenAPI 3.0 specification
        """
        if not self.is_available:
            logger.warning(f"Azure OpenAI not available ({self._initialization_error}), using fallback conversion")
            return self._fallback_conversion(spec_content)
        
        try:
            # Parse the original specification
            original_spec, original_format = self.parse_api_spec(spec_content)
            
            # Validate it's OpenAPI 2.0
            if not self._is_openapi_2(original_spec):
                raise ValueError("Input specification is not OpenAPI 2.0 format")
            
            # Perform AI conversion
            converted_spec = self._ai_convert_spec(original_spec)
            
            # Validate conversion result
            if not self._is_openapi_3(converted_spec):
                logger.warning("AI conversion produced invalid OpenAPI 3.0, using fallback")
                return self._fallback_conversion(spec_content)
            
            logger.info(f"Successfully converted API spec using Azure OpenAI")
            return converted_spec
            
        except Exception as e:
            logger.error(f"AI conversion failed: {e}")
            return self._fallback_conversion(spec_content)
    
    def _ai_convert_spec(self, original_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Use Azure OpenAI to convert the specification"""
        
        if not self.is_available:
            raise Exception("Azure OpenAI client not available")
        
        # Create conversion prompt
        prompt = self._create_conversion_prompt(original_spec)
        
        try:
            # Call Azure OpenAI with new v1.108.1 syntax
            response = self._client.chat.completions.create(
                model=self.config.OPENAI_DEPLOYMENT,
                messages=[
                    {
                        "role": "system", 
                        "content": self._get_system_prompt()
                    },
                    {
                        "role": "user", 
                        "content": prompt
                    }
                ],
                max_tokens=4000,
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            # Parse response
            converted_content = response.choices[0].message.content
            converted_spec = json.loads(converted_content)
            
            # Post-process conversion
            return self._post_process_conversion(converted_spec, original_spec)
            
        except Exception as e:
            logger.error(f"Azure OpenAI API call failed: {e}")
            raise
    
    def _get_system_prompt(self) -> str:
        """Get system prompt for OpenAPI conversion"""
        return """You are an expert API specification converter. Your task is to convert OpenAPI 2.0 specifications to OpenAPI 3.0 format with high accuracy.

Key conversion rules:
1. Change 'swagger: "2.0"' to 'openapi: "3.0.0"'
2. Convert 'host', 'basePath', and 'schemes' to 'servers' array
3. Move 'definitions' to 'components/schemas'
4. Convert 'parameters' and 'responses' to new structure
5. Move 'securityDefinitions' to 'components/securitySchemes'
6. Convert 'consumes'/'produces' to 'requestBody'/'responses' content types
7. Update parameter locations and structures
8. Handle nested schemas and references correctly

Always return valid JSON in OpenAPI 3.0 format. Preserve all original functionality and data."""
    
    def _create_conversion_prompt(self, spec: Dict[str, Any]) -> str:
        """Create detailed conversion prompt"""
        return f"""Convert the following OpenAPI 2.0 specification to OpenAPI 3.0 format.

Original OpenAPI 2.0 Specification:
{json.dumps(spec, indent=2)}

Requirements:
- Maintain all API paths, operations, and parameters
- Preserve authentication schemes and security requirements
- Keep all schema definitions and references
- Ensure proper content type handling
- Maintain backward compatibility where possible

Return the converted OpenAPI 3.0 specification as valid JSON."""
    
    def _post_process_conversion(self, converted_spec: Dict[str, Any], original_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Post-process the AI conversion to ensure completeness"""
        
        # Ensure required OpenAPI 3.0 fields
        if 'openapi' not in converted_spec:
            converted_spec['openapi'] = '3.0.0'
        
        # Preserve info section
        if 'info' in original_spec:
            converted_spec['info'] = converted_spec.get('info', original_spec['info'])
        
        # Ensure components section exists
        if 'components' not in converted_spec:
            converted_spec['components'] = {}
        
        # Handle missing servers section
        if 'servers' not in converted_spec and any(key in original_spec for key in ['host', 'basePath', 'schemes']):
            converted_spec['servers'] = self._create_servers_from_v2(original_spec)
        
        return converted_spec
    
    def _create_servers_from_v2(self, spec: Dict[str, Any]) -> list:
        """Create servers array from OpenAPI 2.0 host/basePath/schemes"""
        servers = []
        host = spec.get('host', 'localhost')
        base_path = spec.get('basePath', '')
        schemes = spec.get('schemes', ['http'])
        
        for scheme in schemes:
            url = f"{scheme}://{host}{base_path}"
            servers.append({"url": url})
        
        return servers
    
    def _fallback_conversion(self, spec_content: str) -> Dict[str, Any]:
        """Fallback conversion when AI is not available"""
        try:
            spec, _ = self.parse_api_spec(spec_content)
            
            # Basic OpenAPI 2.0 to 3.0 conversion
            converted = {
                "openapi": "3.0.0",
                "info": spec.get("info", {"title": "Converted API", "version": "1.0.0"}),
                "servers": self._create_servers_from_v2(spec),
                "paths": spec.get("paths", {}),
                "components": {
                    "schemas": spec.get("definitions", {}),
                    "securitySchemes": self._convert_security_definitions(spec.get("securityDefinitions", {}))
                }
            }
            
            # Add security if present
            if "security" in spec:
                converted["security"] = spec["security"]
            
            logger.info("Used fallback conversion method")
            return converted
            
        except Exception as e:
            logger.error(f"Fallback conversion failed: {e}")
            raise ValueError(f"Unable to convert specification: {e}")
    
    def _convert_security_definitions(self, security_defs: Dict[str, Any]) -> Dict[str, Any]:
        """Convert OpenAPI 2.0 securityDefinitions to 3.0 securitySchemes"""
        converted = {}
        
        for name, definition in security_defs.items():
            if definition.get('type') == 'apiKey':
                converted[name] = {
                    'type': 'apiKey',
                    'name': definition.get('name'),
                    'in': definition.get('in')
                }
            elif definition.get('type') == 'oauth2':
                converted[name] = {
                    'type': 'oauth2',
                    'flows': {
                        definition.get('flow', 'implicit'): {
                            'authorizationUrl': definition.get('authorizationUrl'),
                            'tokenUrl': definition.get('tokenUrl'),
                            'scopes': definition.get('scopes', {})
                        }
                    }
                }
            elif definition.get('type') == 'basic':
                converted[name] = {
                    'type': 'http',
                    'scheme': 'basic'
                }
        
        return converted
    
    def _is_openapi_2(self, spec: Dict[str, Any]) -> bool:
        """Check if specification is OpenAPI 2.0"""
        return spec.get('swagger') == '2.0' or spec.get('swagger', '').startswith('2.')
    
    def _is_openapi_3(self, spec: Dict[str, Any]) -> bool:
        """Check if specification is OpenAPI 3.0"""
        return spec.get('openapi', '').startswith('3.')
    
    def validate_conversion(self, original_spec: Dict[str, Any], converted_spec: Dict[str, Any]) -> Dict[str, Any]:
        """Validate the conversion quality"""
        validation_results = {
            'is_valid_openapi_3': self._is_openapi_3(converted_spec),
            'has_required_fields': all(field in converted_spec for field in ['openapi', 'info', 'paths']),
            'preserved_paths': len(original_spec.get('paths', {})) == len(converted_spec.get('paths', {})),
            'preserved_definitions': len(original_spec.get('definitions', {})) == len(converted_spec.get('components', {}).get('schemas', {})),
            'has_servers': 'servers' in converted_spec,
            'conversion_warnings': []
        }
        
        # Check for potential issues
        if not validation_results['preserved_paths']:
            validation_results['conversion_warnings'].append("Number of API paths differs between versions")
        
        if not validation_results['preserved_definitions']:
            validation_results['conversion_warnings'].append("Number of schema definitions differs between versions")
        
        return validation_results
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to Azure OpenAI service"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': f'Azure OpenAI client not initialized: {self._initialization_error or "Unknown error"}'
            }
        
        try:
            # Simple test call
            response = self._client.chat.completions.create(
                model=self.config.OPENAI_DEPLOYMENT,
                messages=[{"role": "user", "content": "test"}],
                max_tokens=10
            )
            
            return {
                'status': 'success',
                'message': 'Azure OpenAI connection successful',
                'model': self.config.OPENAI_DEPLOYMENT
            }
            
        except Exception as e:
            return {
                'status': 'error',
                'message': f'Azure OpenAI connection failed: {str(e)}'
            }