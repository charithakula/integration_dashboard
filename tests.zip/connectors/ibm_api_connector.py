"""
IBM API Connect Connector
Handles API extraction from IBM API Connect and Developer Portal
"""
import json
import logging
import requests
import base64
from typing import Dict, Any, List, Optional, Tuple
from urllib.parse import urljoin, urlparse
from config import IBMConfig

logger = logging.getLogger(__name__)

class IBMAPIConnector:
    """IBM API Connect service connector"""
    
    def __init__(self):
        """Initialize IBM API Connect connector"""
        self.config = IBMConfig
        self._session = None
        self._auth_token = None
        self._base_url = None
        self._initialize_session()
    
    def _initialize_session(self) -> bool:
        """Initialize HTTP session and authenticate with IBM API Connect"""
        try:
            # Validate configuration
            missing_config = self.config.validate_ibm_config()
            if missing_config:
                logger.error(f"Missing IBM API Connect configuration: {missing_config}")
                return False
            
            self._base_url = self.config.API_CONNECT_URL.rstrip('/')
            self._session = requests.Session()
            
            # Set up session headers
            self._session.headers.update({
                'Content-Type': 'application/json',
                'Accept': 'application/json',
                'User-Agent': 'API-Migration-Tool/1.0'
            })
            
            # Authenticate
            if self._authenticate():
                logger.info("IBM API Connect session initialized successfully")
                return True
            else:
                logger.error("Failed to authenticate with IBM API Connect")
                return False
                
        except Exception as e:
            logger.error(f"Failed to initialize IBM API Connect session: {e}")
            self._session = None
            return False
    
    @property
    def is_available(self) -> bool:
        """Check if IBM API Connect service is available"""
        return self._session is not None and self._auth_token is not None
    
    def _authenticate(self) -> bool:
        """Authenticate with IBM API Connect"""
        try:
            # IBM API Connect authentication endpoints vary by version
            # Try multiple authentication methods
            
            # Method 1: Token-based authentication
            if self._authenticate_token():
                return True
            
            # Method 2: Basic authentication
            if self._authenticate_basic():
                return True
            
            # Method 3: Cloud Manager authentication
            if self._authenticate_cloud_manager():
                return True
            
            return False
            
        except Exception as e:
            logger.error(f"Authentication failed: {e}")
            return False
    
    def _authenticate_token(self) -> bool:
        """Authenticate using token endpoint"""
        try:
            auth_url = f"{self._base_url}/api/token"
            
            auth_data = {
                'username': self.config.USERNAME,
                'password': self.config.PASSWORD,
                'realm': 'provider/default-idp-1',
                'client_id': 'caa87d9a-8cd7-4686-8b6e-ee2cdc5ee267',
                'client_secret': '3ecff363-7eb3-44be-9e07-6d4386239d42',
                'grant_type': 'password'
            }
            
            response = self._session.post(auth_url, json=auth_data)
            
            if response.status_code == 200:
                token_data = response.json()
                self._auth_token = token_data.get('access_token')
                
                if self._auth_token:
                    self._session.headers['Authorization'] = f'Bearer {self._auth_token}'
                    logger.info("Successfully authenticated using token method")
                    return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Token authentication failed: {e}")
            return False
    
    def _authenticate_basic(self) -> bool:
        """Authenticate using basic authentication"""
        try:
            # Encode credentials
            credentials = f"{self.config.USERNAME}:{self.config.PASSWORD}"
            encoded_credentials = base64.b64encode(credentials.encode()).decode()
            
            self._session.headers['Authorization'] = f'Basic {encoded_credentials}'
            
            # Test authentication with a simple API call
            test_url = f"{self._base_url}/api/orgs"
            response = self._session.get(test_url)
            
            if response.status_code == 200:
                logger.info("Successfully authenticated using basic authentication")
                return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Basic authentication failed: {e}")
            return False
    
    def _authenticate_cloud_manager(self) -> bool:
        """Authenticate with IBM Cloud Manager"""
        try:
            auth_url = f"{self._base_url}/api/cloud/integrations/user-registry/authenticate"
            
            auth_data = {
                'username': self.config.USERNAME,
                'password': self.config.PASSWORD
            }
            
            response = self._session.post(auth_url, json=auth_data)
            
            if response.status_code == 200:
                auth_data = response.json()
                self._auth_token = auth_data.get('token') or auth_data.get('access_token')
                
                if self._auth_token:
                    self._session.headers['Authorization'] = f'Bearer {self._auth_token}'
                    logger.info("Successfully authenticated using cloud manager method")
                    return True
            
            return False
            
        except Exception as e:
            logger.debug(f"Cloud manager authentication failed: {e}")
            return False
    
    def test_connection(self) -> Dict[str, Any]:
        """Test connection to IBM API Connect service"""
        if not self.is_available:
            return {
                'status': 'error',
                'message': 'IBM API Connect session not available'
            }
        
        try:
            # Test with organizations endpoint
            test_url = f"{self._base_url}/api/orgs"
            response = self._session.get(test_url)
            
            if response.status_code == 200:
                orgs_data = response.json()
                org_count = len(orgs_data.get('results', []))
                
                return {
                    'status': 'success',
                    'message': 'IBM API Connect connection successful',
                    'base_url': self._base_url,
                    'organization_count': org_count,
                    'current_org': self.config.ORGANIZATION
                }
            else:
                return {
                    'status': 'error',
                    'message': f'Connection test failed: HTTP {response.status_code}'
                }
                
        except Exception as e:
            return {
                'status': 'error',
                'message': f'IBM API Connect connection failed: {str(e)}'
            }
    
    def list_apis(self, org_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """List all APIs in the specified organization"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        
        try:
            # Get APIs from the organization
            apis_url = f"{self._base_url}/api/orgs/{org_name}/apis"
            response = self._session.get(apis_url)
            
            if response.status_code != 200:
                logger.error(f"Failed to list APIs: HTTP {response.status_code}")
                return []
            
            apis_data = response.json()
            api_list = []
            
            for api in apis_data.get('results', []):
                api_info = {
                    'id': api.get('id'),
                    'name': api.get('name'),
                    'title': api.get('title'),
                    'version': api.get('version'),
                    'description': api.get('description'),
                    'state': api.get('state'),
                    'created_at': api.get('created_at'),
                    'updated_at': api.get('updated_at'),
                    'url': api.get('url')
                }
                api_list.append(api_info)
            
            logger.info(f"Retrieved {len(api_list)} APIs from IBM API Connect")
            return api_list
            
        except Exception as e:
            logger.error(f"Failed to list APIs: {e}")
            raise
    
    def get_api_specification(self, api_id: str, org_name: Optional[str] = None) -> Dict[str, Any]:
        """Get OpenAPI specification for a specific API"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        
        try:
            # Get API specification
            spec_url = f"{self._base_url}/api/orgs/{org_name}/apis/{api_id}/document"
            response = self._session.get(spec_url)
            
            if response.status_code != 200:
                logger.error(f"Failed to get API specification: HTTP {response.status_code}")
                return None
            
            # Parse API specification
            api_spec = response.json()
            
            # Add metadata
            result = {
                'status': 'success',
                'api_id': api_id,
                'specification': api_spec,
                'format': 'openapi_2.0' if api_spec.get('swagger') else 'unknown',
                'retrieved_at': None
            }
            
            logger.info(f"Retrieved API specification for: {api_id}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to get API specification for {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to retrieve API specification: {str(e)}'
            }
    
    def export_api(self, api_id: str, org_name: Optional[str] = None) -> Dict[str, Any]:
        """Export API with full details including policies"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        
        try:
            # Get basic API info
            api_url = f"{self._base_url}/api/orgs/{org_name}/apis/{api_id}"
            api_response = self._session.get(api_url)
            
            if api_response.status_code != 200:
                return {
                    'status': 'error',
                    'message': f'Failed to get API details: HTTP {api_response.status_code}'
                }
            
            api_data = api_response.json()
            
            # Get API specification
            spec_result = self.get_api_specification(api_id, org_name)
            if spec_result.get('status') == 'error':
                return spec_result
            
            # Combine API data with specification
            export_data = {
                'api_info': api_data,
                'specification': spec_result.get('specification'),
                'format': spec_result.get('format'),
                'exported_at': None
            }
            
            return {
                'status': 'success',
                'api_id': api_id,
                'data': export_data,
                'message': f'API {api_id} exported successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to export API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to export API: {str(e)}'
            }
    
    def list_products(self, org_name: Optional[str] = None, catalog_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """List products in the specified catalog"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        catalog_name = catalog_name or self.config.CATALOG
        
        try:
            products_url = f"{self._base_url}/api/orgs/{org_name}/catalogs/{catalog_name}/products"
            response = self._session.get(products_url)
            
            if response.status_code != 200:
                logger.error(f"Failed to list products: HTTP {response.status_code}")
                return []
            
            products_data = response.json()
            product_list = []
            
            for product in products_data.get('results', []):
                product_info = {
                    'id': product.get('id'),
                    'name': product.get('name'),
                    'title': product.get('title'),
                    'version': product.get('version'),
                    'description': product.get('description'),
                    'state': product.get('state'),
                    'apis': product.get('apis', [])
                }
                product_list.append(product_info)
            
            logger.info(f"Retrieved {len(product_list)} products from catalog {catalog_name}")
            return product_list
            
        except Exception as e:
            logger.error(f"Failed to list products: {e}")
            return []
    
    def export_catalog(self, org_name: Optional[str] = None, catalog_name: Optional[str] = None) -> Dict[str, Any]:
        """Export entire catalog with all APIs and products"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        catalog_name = catalog_name or self.config.CATALOG
        
        try:
            # Get catalog info
            catalog_url = f"{self._base_url}/api/orgs/{org_name}/catalogs/{catalog_name}"
            catalog_response = self._session.get(catalog_url)
            
            if catalog_response.status_code != 200:
                return {
                    'status': 'error',
                    'message': f'Failed to get catalog info: HTTP {catalog_response.status_code}'
                }
            
            catalog_data = catalog_response.json()
            
            # Get all APIs in the organization
            apis = self.list_apis(org_name)
            
            # Get all products in the catalog
            products = self.list_products(org_name, catalog_name)
            
            export_data = {
                'catalog_info': catalog_data,
                'apis': apis,
                'products': products,
                'api_count': len(apis),
                'product_count': len(products)
            }
            
            return {
                'status': 'success',
                'catalog': catalog_name,
                'organization': org_name,
                'data': export_data,
                'message': f'Catalog {catalog_name} exported successfully'
            }
            
        except Exception as e:
            logger.error(f"Failed to export catalog {catalog_name}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to export catalog: {str(e)}'
            }
    
    def search_apis(self, query: str, org_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Search for APIs by name, title, or description"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        try:
            apis = self.list_apis(org_name)
            
            # Filter APIs based on search query
            matching_apis = []
            query_lower = query.lower()
            
            for api in apis:
                # Search in name, title, and description
                searchable_text = ' '.join([
                    api.get('name', ''),
                    api.get('title', ''),
                    api.get('description', '')
                ]).lower()
                
                if query_lower in searchable_text:
                    matching_apis.append(api)
            
            logger.info(f"Found {len(matching_apis)} APIs matching query: {query}")
            return matching_apis
            
        except Exception as e:
            logger.error(f"Failed to search APIs: {e}")
            return []
    
    def get_api_analytics(self, api_id: str, org_name: Optional[str] = None, 
                         catalog_name: Optional[str] = None, days: int = 30) -> Dict[str, Any]:
        """Get analytics data for an API"""
        if not self.is_available:
            raise RuntimeError("IBM API Connect session not available")
        
        org_name = org_name or self.config.ORGANIZATION
        catalog_name = catalog_name or self.config.CATALOG
        
        try:
            # IBM API Connect analytics endpoints vary by version
            # Try common analytics endpoint patterns
            analytics_url = f"{self._base_url}/api/orgs/{org_name}/catalogs/{catalog_name}/analytics/apis/{api_id}"
            
            params = {
                'days': days,
                'resolution': 'day'
            }
            
            response = self._session.get(analytics_url, params=params)
            
            if response.status_code == 200:
                analytics_data = response.json()
                return {
                    'status': 'success',
                    'api_id': api_id,
                    'analytics': analytics_data,
                    'period_days': days
                }
            else:
                # Analytics might not be available or endpoint different
                return {
                    'status': 'warning',
                    'message': 'Analytics data not available or not accessible',
                    'api_id': api_id
                }
                
        except Exception as e:
            logger.warning(f"Failed to get analytics for API {api_id}: {e}")
            return {
                'status': 'error',
                'message': f'Failed to retrieve analytics: {str(e)}'
            }