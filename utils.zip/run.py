#!/usr/bin/env python3
"""
Safe startup script for DocConverter Pro
This script includes error handling to prevent segmentation faults
"""

import sys
import os
import traceback

def check_dependencies():
    """Check if required dependencies are available"""
    missing_deps = []
    
    try:
        import flask
        print(f"✓ Flask {flask.__version__}")
    except ImportError:
        missing_deps.append("Flask")
    
    try:
        import flask_sqlalchemy
        print(f"✓ Flask-SQLAlchemy {flask_sqlalchemy.__version__}")
    except ImportError:
        missing_deps.append("Flask-SQLAlchemy")
    
    try:
        import flask_cors
        print("✓ Flask-CORS")
    except ImportError:
        missing_deps.append("Flask-CORS")
    
    # Optional dependencies
    try:
        import PyPDF2
        print("✓ PyPDF2 (optional)")
    except ImportError:
        print("⚠ PyPDF2 not installed (PDF processing disabled)")
    
    try:
        import docx
        print("✓ python-docx (optional)")
    except ImportError:
        print("⚠ python-docx not installed (DOCX processing disabled)")
    
    if missing_deps:
        print(f"\n❌ Missing required dependencies: {', '.join(missing_deps)}")
        print("Install with: pip install " + " ".join(missing_deps))
        return False
    
    print("\n✓ All required dependencies found")
    return True

def create_directories():
    """Create necessary directories"""
    directories = [
        'uploads',
        'uploads/documents',
        'uploads/results',
        'uploads/temp',
        'logs',
        'templates'
    ]
    
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            print(f"✓ Directory: {directory}")
        except Exception as e:
            print(f"⚠ Could not create directory {directory}: {e}")

def main():
    """Main startup function with error handling"""
    print("=" * 50)
    print("DocConverter Pro - Startup")
    print("=" * 50)
    
    # Check Python version
    python_version = sys.version_info
    print(f"Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    if python_version < (3, 8):
        print("❌ Python 3.8+ required")
        sys.exit(1)
    
    # Check dependencies
    if not check_dependencies():
        sys.exit(1)
    
    # Create directories
    print("\nCreating directories...")
    create_directories()
    
    # Set environment variables
    os.environ.setdefault('FLASK_ENV', 'development')
    os.environ.setdefault('FLASK_DEBUG', '1')
    
    print("\nStarting application...")
    print("=" * 50)
    
    try:
        # Import and run the app
        from app import app
        
        # Test basic app functionality
        with app.app_context():
            print("✓ Application context created")
        
        print("✓ Application loaded successfully")
        print(f"✓ Upload folder: {app.config.get('UPLOAD_FOLDER', 'uploads')}")
        print(f"✓ Debug mode: {app.debug}")
        print(f"✓ Database URI: {app.config.get('SQLALCHEMY_DATABASE_URI', 'sqlite:///doc_converter.db')}")
        
        print("\nStarting Flask development server...")
        print("Access the application at: http://localhost:5000")
        print("Press Ctrl+C to stop the server")
        print("-" * 50)
        
        app.run(
            debug=True,
            host='0.0.0.0',
            port=5000,
            use_reloader=False  # Disable reloader to prevent issues
        )
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("Make sure all required files are present:")
        print("- app.py")
        print("- config.py")
        print("- database.py")
        print("- models.py")
        traceback.print_exc()
        sys.exit(1)
        
    except Exception as e:
        print(f"❌ Startup error: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nShutting down gracefully...")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        traceback.print_exc()
        sys.exit(1)