-- Drop tables in correct order (child tables first due to foreign keys)
-- Connect as postgres user to run this

-- Drop views first
DROP VIEW IF EXISTS user_management;

-- Drop triggers
DROP TRIGGER IF EXISTS update_users_updated_at ON users;
DROP TRIGGER IF EXISTS update_documents_updated_at ON documents;
DROP TRIGGER IF EXISTS update_conversions_updated_at ON conversions;
DROP TRIGGER IF EXISTS update_system_settings_updated_at ON system_settings;

-- Drop functions
DROP FUNCTION IF EXISTS update_updated_at_column();
DROP FUNCTION IF EXISTS create_app_user(VARCHAR, VARCHAR, VARCHAR, VARCHAR, user_role);

-- Drop tables (in order to avoid foreign key constraint errors)
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS conversions CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS system_settings CASCADE;
DROP TABLE IF EXISTS users CASCADE;

-- Drop ENUM types
DROP TYPE IF EXISTS conversion_status;
DROP TYPE IF EXISTS user_role;

-- Note: Keep the database users (docconverter_app, etc.) - they don't need to be recreated
SELECT 'All tables dropped successfully!' as status;