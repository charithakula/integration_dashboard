#!/usr/bin/env python3
"""
Database Connection Diagnostic Script
Run this to diagnose PostgreSQL connection issues
"""

import os
import psycopg2
from dotenv import load_dotenv

def test_postgresql_connection():
    """Test PostgreSQL connection with detailed error reporting"""
    
    print("=" * 60)
    print("PostgreSQL Connection Diagnostic Test")
    print("=" * 60)
    
    # Load environment variables
    load_dotenv()
    
    # Get configuration
    db_config = {
        'host': os.getenv('DB_HOST', 'localhost'),
        'port': int(os.getenv('DB_PORT', '5432')),
        'database': os.getenv('DB_NAME', 'doc_converter'),
        'user': os.getenv('DB_USER', 'docconverter_app'),
        'password': os.getenv('DB_PASSWORD', 'DocConverter2024!')
    }
    
    print(f"Configuration from .env:")
    print(f"  Host: {db_config['host']}")
    print(f"  Port: {db_config['port']}")
    print(f"  Database: {db_config['database']}")
    print(f"  User: {db_config['user']}")
    print(f"  Password: {'*' * len(db_config['password'])}")
    print()
    
    # Test different port combinations
    ports_to_test = [db_config['port'], 5432, 5433, 5434]
    
    for port in ports_to_test:
        print(f"Testing connection to port {port}...")
        test_config = db_config.copy()
        test_config['port'] = port
        
        try:
            # Test basic connection
            conn = psycopg2.connect(**test_config)
            cursor = conn.cursor()
            
            # Test basic query
            cursor.execute("SELECT version();")
            version = cursor.fetchone()[0]
            
            cursor.execute("SELECT current_user, current_database();")
            user_db = cursor.fetchone()
            
            cursor.close()
            conn.close()
            
            print(f"  ✓ SUCCESS on port {port}")
            print(f"    PostgreSQL version: {version[:50]}...")
            print(f"    Connected as: {user_db[0]} to database: {user_db[1]}")
            return test_config
            
        except psycopg2.OperationalError as e:
            print(f"  ✗ FAILED on port {port}: {e}")
        except Exception as e:
            print(f"  ✗ ERROR on port {port}: {e}")
    
    print("\nNo successful connections found.")
    
    # Additional diagnostics
    print("\nDiagnostic suggestions:")
    print("1. Check if PostgreSQL is running:")
    print("   sudo systemctl status postgresql")
    print("   sudo systemctl start postgresql")
    print()
    print("2. Check PostgreSQL port:")
    print("   sudo -u postgres psql -c 'SHOW port;'")
    print()
    print("3. Create database user:")
    print("   sudo -u postgres createuser -P docconverter_app")
    print("   sudo -u postgres createdb -O docconverter_app doc_converter")
    print()
    print("4. Test manual connection:")
    print("   PGPASSWORD='DocConverter2024!' psql -h localhost -p 5432 -U docconverter_app -d doc_converter")
    
    return None

def test_azure_openai_simple():
    """Simple Azure OpenAI test"""
    print("=" * 60)
    print("Azure OpenAI Simple Connection Test")
    print("=" * 60)
    
    # Load environment variables
    load_dotenv()
    
    config = {
        'endpoint': os.getenv('AZURE_OPENAI_ENDPOINT'),
        'api_key': os.getenv('AZURE_OPENAI_API_KEY') or os.getenv('AZURE_OPENAI_KEY'),
        'deployment': os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-5-mini'),
        'api_version': os.getenv('AZURE_OPENAI_VERSION', '2025-01-01-preview')
    }
    
    print(f"Configuration:")
    print(f"  Endpoint: {config['endpoint']}")
    print(f"  Deployment: {config['deployment']}")
    print(f"  API Version: {config['api_version']}")
    print(f"  API Key: {'*' * len(config['api_key']) if config['api_key'] else 'NOT SET'}")
    print()
    
    if not config['endpoint'] or not config['api_key']:
        print("✗ FAILED: Missing Azure OpenAI configuration")
        return
    
    try:
        from openai import AzureOpenAI
        
        client = AzureOpenAI(
            azure_endpoint=config['endpoint'],
            api_key=config['api_key'],
            api_version=config['api_version']
        )
        
        # Test with minimal parameters (no temperature, let model use defaults)
        response = client.chat.completions.create(
            model=config['deployment'],
            messages=[{"role": "user", "content": "Hello"}],
            max_completion_tokens=5
        )
        
        print("✓ SUCCESS: Azure OpenAI connection working")
        print(f"  Response: {response.choices[0].message.content}")
        
    except Exception as e:
        if "max_completion_tokens" in str(e):
            try:
                # Try with max_tokens instead
                response = client.chat.completions.create(
                    model=config['deployment'],
                    messages=[{"role": "user", "content": "Hello"}],
                    max_tokens=5
                )
                print("✓ SUCCESS: Azure OpenAI connection working (with max_tokens)")
                print(f"  Response: {response.choices[0].message.content}")
            except Exception as e2:
                print(f"✗ FAILED: {e2}")
        else:
            print(f"✗ FAILED: {e}")

if __name__ == "__main__":
    # Test database connection
    working_config = test_postgresql_connection()
    
    print()
    
    # Test Azure OpenAI
    test_azure_openai_simple()
    
    if working_config:
        print(f"\n{'='*60}")
        print("SOLUTION FOUND:")
        print(f"Update your .env file with: DB_PORT={working_config['port']}")
        print(f"{'='*60}")