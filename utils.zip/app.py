from flask import Flask, render_template, request, jsonify, session, redirect, url_for, current_app
from flask_cors import CORS
from werkzeug.utils import secure_filename
import os
from datetime import datetime, timezone
import uuid
import logging
from dotenv import load_dotenv
from sqlalchemy import text
from flask import send_file
from datetime import datetime
import threading
from io import BytesIO
from reportlab.lib.pagesizes import letter, A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib import colors
import re
import tempfile
from io import BytesIO
import zipfile
from datetime import datetime, timezone, timedelta  # Add timedelta here
# Import our organized connection modules
from connections import connection_manager

# Load environment variables from .env file
load_dotenv()

def create_app():
    """Create Flask application with organized connections"""
    app = Flask(__name__)
    
    # Configure logging
    log_level = os.environ.get('LOG_LEVEL', 'INFO')
    logging.basicConfig(
        level=getattr(logging, log_level),
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    logger = logging.getLogger(__name__)
    
    try:
        # Load configuration
        from config import Config
        app.config.from_object(Config)
        logger.info("Configuration loaded successfully")
    except ImportError as e:
        logger.warning(f"Could not import config.py: {e}")
        # Fallback configuration using environment variables
        app.config.update({
            'SECRET_KEY': os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production'),
            'SQLALCHEMY_DATABASE_URI': os.environ.get('DATABASE_URL', 
                f"postgresql://{os.environ.get('DB_USER', 'postgres')}:"
                f"{os.environ.get('DB_PASSWORD', 'postgres')}@"
                f"{os.environ.get('DB_HOST', 'localhost')}:"
                f"{os.environ.get('DB_PORT', '5432')}/"
                f"{os.environ.get('DB_NAME', 'doc_converter')}"
            ),
            'SQLALCHEMY_TRACK_MODIFICATIONS': False,
            'SQLALCHEMY_ENGINE_OPTIONS': {
                'pool_size': 10,
                'pool_recycle': 60,
                'pool_pre_ping': True
            },
            'UPLOAD_FOLDER': os.environ.get('UPLOAD_FOLDER', 'uploads'),
            'MAX_CONTENT_LENGTH': 50 * 1024 * 1024,  # 50MB
            'AZURE_OPENAI_ENDPOINT': os.environ.get('AZURE_OPENAI_ENDPOINT', ''),
            'AZURE_OPENAI_KEY': os.environ.get('AZURE_OPENAI_KEY', ''),
            'AZURE_OPENAI_MODEL': os.environ.get('AZURE_OPENAI_MODEL', 'gpt-4'),
            'DEBUG': os.environ.get('FLASK_DEBUG', '1') == '1'
        })
    
    # Initialize CORS
    CORS(app)

     # Add session configuration here
    app.config.update({
        'SESSION_COOKIE_SECURE': not app.debug,
        'SESSION_COOKIE_HTTPONLY': True,
        'SESSION_COOKIE_SAMESITE': 'Lax',
        'PERMANENT_SESSION_LIFETIME': timedelta(hours=24)
    })
    
    # Initialize connections
    logger.info("Initializing connections...")
    connection_status = connection_manager.initialize_all_connections()
    
    # Store connection status in app
    app.connection_status = connection_status
    app.connection_manager = connection_manager

    # Initialize database with SQLAlchemy - CRITICAL FIX
    try:
        # Import the db instance from models.py (this is the key fix)
        from models import db
        from database import init_db
        
        # Initialize the SAME db instance that models.py uses with our Flask app
        db.init_app(app)
        logger.info("Database extension initialized with models db instance")
        
        # Store db reference in app for access
        app.db = db
        
        # Initialize database tables within app context
        with app.app_context():
            success = init_db()
            if success:
                logger.info("Database tables created/verified")
                
                # Try to create admin user and settings within the same app context
                try:
                    from models import User, SystemSetting, UserRole
                    from werkzeug.security import generate_password_hash
                    
                    # Check if admin user exists
                    admin_user = User.query.filter_by(email='admin@docconverter.com').first()
                    if not admin_user:
                        admin_user = User(
                            email='admin@docconverter.com',
                            password_hash=generate_password_hash('AdminPassword123!'),
                            first_name='System',
                            last_name='Administrator',
                            role=UserRole.ADMIN,
                            is_active=True
                        )
                        db.session.add(admin_user)
                        logger.info("Admin user created")
                    
                    # Create default settings
                    default_settings = [
                        ('max_file_size_mb', '50', 'Maximum file size for uploads in MB'),
                        ('supported_formats', 'pdf,docx,txt,md,pptx', 'Supported file formats'),
                        ('default_conversion_depth', 'comprehensive', 'Default conversion depth'),
                        ('ai_processing_timeout', '300', 'AI processing timeout in seconds'),
                    ]
                    
                    for key, value, description in default_settings:
                        setting = SystemSetting.query.filter_by(key=key).first()
                        if not setting:
                            setting = SystemSetting(
                                key=key,
                                value=value,
                                description=description
                            )
                            db.session.add(setting)
                    
                    db.session.commit()
                    logger.info("Database initialization completed successfully")
                    app.db_available = True
                    app.models_available = True
                    
                except Exception as e:
                    logger.error(f"Failed to create default data: {e}")
                    db.session.rollback()
                    app.db_available = True  # Database works, just default data failed
                    app.models_available = True
            else:
                logger.warning("Database initialization had issues")
                app.db_available = connection_status.get('postgresql', False)
                app.models_available = False
                
    except ImportError as e:
        logger.error(f"Could not import database or models module: {e}")
        app.db_available = connection_status.get('postgresql', False)
        app.models_available = False
        app.db = None
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        app.db_available = False
        app.models_available = False
        app.db = None

    # FIXED: Register blueprints OUTSIDE of exception blocks - they should always be registered
    # Register auth blueprint with error handling
    try:
        from auth import auth_bp
        app.register_blueprint(auth_bp, url_prefix='/auth')
        logger.info("Auth blueprint registered")
        app.auth_available = True
    except ImportError as e:
        logger.warning(f"Could not import auth blueprint: {e}")
        app.auth_available = False
    except Exception as e:
        logger.error(f"Failed to register auth blueprint: {e}")
        app.auth_available = False
    
    # Register API blueprint with error handling
    try:
        from api import api_bp  
        app.register_blueprint(api_bp, url_prefix='/api')
        logger.info("API blueprint registered")
        app.api_available = True
    except ImportError as e:
        logger.warning(f"Could not import API blueprint: {e}")
        app.api_available = False
    except Exception as e:
        logger.error(f"Failed to register API blueprint: {e}")
        app.api_available = False
    
    # Initialize utilities
    try:
        from utils.file_handler import FileHandler
        app.file_handler = FileHandler(app.config['UPLOAD_FOLDER'])
        logger.info("File handler initialized")
    except ImportError as e:
        logger.warning(f"Could not import file handler: {e}")
        app.file_handler = None
    
    # AI processor is now managed by connection_manager
    app.ai_processor_available = connection_status.get('azure_openai', False)
    if app.ai_processor_available:
        logger.info("AI processor available through connection manager")
    else:
        logger.info("AI processor not available")
    
    # Create upload directories
    upload_folder = app.config['UPLOAD_FOLDER']
    directories = [upload_folder]
    for subdir in ['documents', 'results', 'temp']:
        directories.append(os.path.join(upload_folder, subdir))
    
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            logger.debug(f"Directory ensured: {directory}")
        except Exception as e:
            logger.warning(f"Could not create directory {directory}: {e}")
    
    # Create logs directory
    log_file = os.environ.get('LOG_FILE', 'logs/app.log')
    log_dir = os.path.dirname(log_file)
    if log_dir:
        os.makedirs(log_dir, exist_ok=True)
    
    # DEBUG: Print all registered routes for troubleshooting
    if logger.isEnabledFor(logging.DEBUG):
        logger.debug("Registered routes:")
        for rule in app.url_map.iter_rules():
            logger.debug(f"  {rule.rule} -> {rule.endpoint} ({rule.methods})")
    
    logger.info(f"Application initialized - Debug: {app.debug}")
    return app

# Create the Flask app
app = create_app()

# Import dependencies with fallbacks AFTER app creation
try:
    from auth import login_required
except ImportError:
    def login_required(f):
        def decorated_function(*args, **kwargs):
            # Simple fallback - no authentication when auth module unavailable
            return f(*args, **kwargs)
        return decorated_function

# Import models AFTER app creation - they should now work with the initialized db
try:
    from models import User, Document, Conversion, UserRole, ConversionStatus
    MODELS_AVAILABLE = True
except ImportError as e:
    MODELS_AVAILABLE = False
    app.logger.warning(f"Models not available - some features will be limited: {e}")


# 1. First, check if the admin user was actually created
# Add this debug route to your app.py to check user creation:

@app.route('/debug/users')
def debug_users():
    """Debug route to check if users exist in database"""
    try:
        if not MODELS_AVAILABLE or not app.db:
            return jsonify({'error': 'Database not available'})
        
        users = User.query.all()
        user_data = []
        for user in users:
            user_data.append({
                'id': user.id,
                'email': user.email,
                'first_name': user.first_name,
                'last_name': user.last_name,
                'role': user.role.value,
                'is_active': user.is_active,
                'created_at': user.created_at.isoformat() if user.created_at else None
            })
        
        return jsonify({
            'total_users': len(users),
            'users': user_data
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Main application routes
@app.route('/status') 
def status_page():
    """Main dashboard route"""
    try:
        return render_template('index.html')
    except Exception as e:
        app.logger.error(f"Template rendering failed: {e}")
        connection_status = app.connection_status
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>DocConverter Pro</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 40px; }}
                .container {{ max-width: 800px; margin: 0 auto; }}
                .status {{ padding: 10px; margin: 10px 0; border-radius: 5px; }}
                .success {{ background: #d4edda; color: #155724; }}
                .warning {{ background: #fff3cd; color: #856404; }}
                .error {{ background: #f8d7da; color: #721c24; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>DocConverter Pro</h1>
                <p>Enterprise Document Converter is starting up...</p>
                
                <div class="status {'success' if connection_status.get('postgresql') else 'error'}">
                    PostgreSQL Database: {'Connected' if connection_status.get('postgresql') else 'Not Connected'}
                </div>
                
                <div class="status {'success' if connection_status.get('azure_openai') else 'warning'}">
                    Azure OpenAI: {'Connected' if connection_status.get('azure_openai') else 'Not Connected'}
                </div>
                
                <p>Upload folder: {app.config.get('UPLOAD_FOLDER', 'uploads')}</p>
                <p>Environment: {os.environ.get('FLASK_ENV', 'development')}</p>
                
                <h3>Connection Details</h3>
                <pre>{app.connection_manager.get_connection_status()}</pre>
                
                <h3>Quick Test</h3>
                <form action="/upload" method="post" enctype="multipart/form-data">
                    <input type="file" name="file" accept=".pdf,.docx,.txt,.md" required>
                    <button type="submit">Test Upload</button>
                </form>
            </div>
        </body>
        </html>
        """

@app.route('/dashboard')
def dashboard():
    """Dashboard with user stats"""
    try:
        if not MODELS_AVAILABLE or not app.connection_status.get('postgresql'):
            stats = {
                'total_documents': 0,
                'success_rate': 0.0,
                'active_users': 1,
                'time_saved': 0
            }
        else:
            # Get real stats from database using connection manager
            try:
                result = app.connection_manager.execute_database_query(
                    "SELECT COUNT(*) FROM documents",
                    fetch=True
                )
                doc_count = result[0][0] if result else 0
                
                stats = {
                    'total_documents': doc_count,
                    'success_rate': 95.0,
                    'active_users': 1,
                    'time_saved': doc_count * 2.5
                }
            except Exception as e:
                app.logger.error(f"Failed to get database stats: {e}")
                stats = {
                    'total_documents': 0,
                    'success_rate': 0.0,
                    'active_users': 0,
                    'time_saved': 0
                }
        
        return jsonify({
            'stats': stats,
            'recent_conversions': [],
            'connection_status': app.connection_status
        })
        
    except Exception as e:
        app.logger.error(f"Dashboard error: {str(e)}")
        return jsonify({'error': 'Dashboard unavailable'}), 500

def allowed_file(filename):
    """Check if file extension is allowed"""
    allowed_extensions = {'pdf', 'docx', 'txt', 'md', 'pptx'}
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in allowed_extensions

@app.route('/api/auth/status')
def auth_status():
    """Check if user is authenticated"""
    if 'user_id' in session:
        return jsonify({
            'authenticated': True,
            'user': {
                'id': session.get('user_id'),
                'email': session.get('user_email'),
                'name': session.get('user_name'),
                'role': session.get('user_role')
            }
        })
    else:
        return jsonify({'authenticated': False})

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload - Now using the properly initialized db from models.py"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    try:
        # Validate file
        if not allowed_file(file.filename):
            return jsonify({'error': 'Invalid file type. Allowed: PDF, DOCX, TXT, MD, PPTX'}), 400
        
        # Check file size
        file.seek(0, 2)  # Seek to end
        file_size = file.tell()
        file.seek(0)     # Reset to beginning
        
        max_size = app.config.get('MAX_CONTENT_LENGTH', 50 * 1024 * 1024)
        if file_size > max_size:
            return jsonify({'error': f'File too large. Max size: {max_size // (1024*1024)}MB'}), 400
        
        # Save file
        filename = secure_filename(file.filename)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_filename = f"{timestamp}_{uuid.uuid4().hex[:8]}_{filename}"
        
        upload_path = os.path.join(app.config['UPLOAD_FOLDER'], 'documents', unique_filename)
        file.save(upload_path)
        
        # Create document record if models available and database connected
        document_id = None
        if MODELS_AVAILABLE and app.connection_status.get('postgresql') and app.db:
            try:
                # Now this should work because we're using the same db instance from models.py
                document = Document(
                    filename=unique_filename,
                    original_name=filename,
                    file_path=upload_path,
                    file_size=file_size,
                    file_type=file.content_type or 'application/octet-stream',
                    user_id=session.get('user_id', 1)
                )
                app.db.session.add(document)
                app.db.session.commit()
                document_id = document.id
                app.logger.info(f"Document record created: {document_id}")
                
            except Exception as e:
                app.logger.warning(f"Could not create document record: {e}")
                try:
                    app.db.session.rollback()
                except:
                    pass
        
        return jsonify({
            'message': 'File uploaded successfully',
            'document_id': document_id,
            'filename': unique_filename,
            'original_name': filename,
            'file_size': file_size,
            'connection_status': app.connection_status
        })
        
    except Exception as e:
        app.logger.error(f"Upload error: {str(e)}")
        return jsonify({'error': 'Upload failed'}), 500

@app.route('/convert', methods=['POST'])
def start_conversion():

    from models import ConversionStatus
    print(f"DEBUG: ConversionStatus.QUEUED = '{ConversionStatus.QUEUED.value}'")
    print(f"DEBUG: Available enum values: {[status.value for status in ConversionStatus]}")

    """Start document conversion process - Now using the properly initialized db from models.py"""
    data = request.get_json()
    
    required_fields = ['filename', 'target_tech']
    missing_fields = [field for field in required_fields if not data.get(field)]
    if missing_fields:
        return jsonify({'error': f'Missing required fields: {", ".join(missing_fields)}'}), 400
    
    try:
        conversion_id = str(uuid.uuid4())
        
        # Create conversion record if available
        if MODELS_AVAILABLE and app.connection_status.get('postgresql') and app.db:
            try:
                # Find the document - this should work now with the same db instance
                document = Document.query.filter_by(filename=data['filename']).first()
                if not document:
                    return jsonify({'error': 'Document not found'}), 404
                
                # Create conversion record
                conversion = Conversion(
                    id=conversion_id,
                    document_id=document.id,
                    user_id=session.get('user_id', 1),
                    source_technology=data.get('source_tech', 'auto-detect'),
                    target_technology=data['target_tech'],
                    conversion_depth=data.get('depth', 'comprehensive'),
                    output_format=data.get('format', 'markdown'),
                    # status=ConversionStatus.QUEUED
                    status=ConversionStatus.QUEUED
                )
                app.db.session.add(conversion)
                app.db.session.commit()
                
                app.logger.info(f"Conversion queued: {conversion_id}")
                
                # Start AI processing if available
                if app.connection_status.get('azure_openai'):
                    # Use connection manager for AI processing
                    app.logger.info(f"Conversion sent to AI processor: {conversion_id}")
                else:
                    app.logger.warning("Azure OpenAI not available - conversion queued only")
                    
            except Exception as e:
                app.logger.error(f"Failed to create conversion record: {e}")
                try:
                    app.db.session.rollback()
                except:
                    pass
                return jsonify({'error': 'Failed to queue conversion'}), 500
        else:
            app.logger.warning("Database or models not available - conversion not persisted")
        
        return jsonify({
            'message': 'Conversion started successfully',
            'conversion_id': conversion_id,
            'status': 'queued',
            'ai_available': app.connection_status.get('azure_openai', False),
            'persisted': bool(MODELS_AVAILABLE and app.connection_status.get('postgresql') and app.db)
        })
        
    except Exception as e:
        app.logger.error(f"Conversion error: {str(e)}")
        return jsonify({'error': 'Conversion failed to start'}), 500

@app.route('/conversion/<conversion_id>/status')
def conversion_status(conversion_id):
    """Get conversion status - Updated to redirect to result page when complete"""
    try:
        if not MODELS_AVAILABLE or not app.connection_status.get('postgresql') or not app.db:
            return jsonify({
                'id': conversion_id,
                'status': 'unknown',
                'message': 'Database not available'
            })
        
        conversion = Conversion.query.get(conversion_id)
        if not conversion:
            return jsonify({'error': 'Conversion not found'}), 404
        
        status_data = conversion.to_dict()
        
        # Add a redirect URL for completed conversions
        if conversion.status == ConversionStatus.COMPLETED:
            status_data['result_url'] = url_for('conversion_result_page', conversion_id=conversion_id)
        
        return jsonify(status_data)
        
    except Exception as e:
        app.logger.error(f"Status check error: {str(e)}")
        return jsonify({'error': 'Status check failed'}), 500

# Also add a markdown filter for better formatting (optional)
@app.template_filter('markdown')
def markdown_filter(text):
    """Convert markdown to HTML for display"""
    if not text:
        return ""
    
    import re
    
    # Simple markdown conversion (you could use a library like markdown for more features)
    # Convert headers
    text = re.sub(r'^### (.*$)', r'<h3>\1</h3>', text, flags=re.MULTILINE)
    text = re.sub(r'^## (.*$)', r'<h2>\1</h2>', text, flags=re.MULTILINE)  
    text = re.sub(r'^# (.*$)', r'<h1>\1</h1>', text, flags=re.MULTILINE)
    
    # Convert bold text
    text = re.sub(r'\*\*(.*?)\*\*', r'<strong>\1</strong>', text)
    
    # Convert code blocks
    text = re.sub(r'^```(\w+)?\n(.*?)^```', r'<pre><code>\2</code></pre>', text, flags=re.MULTILINE | re.DOTALL)
    
    # Convert inline code
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', text)
    
    # Convert line breaks to paragraphs
    paragraphs = text.split('\n\n')
    formatted_paragraphs = []
    for para in paragraphs:
        if para.strip():
            if not para.startswith('<'):
                para = f'<p>{para.replace(chr(10), "<br>")}</p>'
            formatted_paragraphs.append(para)
    

@app.route('/conversion/<conversion_id>/result')
def conversion_result_page(conversion_id):
    """Display formatted conversion result page"""
    try:
        if not MODELS_AVAILABLE or not app.connection_status.get('postgresql') or not app.db:
            return jsonify({'error': 'Database not available'}), 500
            
        conversion = Conversion.query.get(conversion_id)
        if not conversion:
            return render_template('error.html', 
                                 error_title="Conversion Not Found",
                                 error_message="The requested conversion could not be found."), 404
        
        # Read the conversion result file if it exists
        conversion_content = ""
        if conversion.result_path and os.path.exists(conversion.result_path):
            try:
                with open(conversion.result_path, 'r', encoding='utf-8') as f:
                    conversion_content = f.read()
            except Exception as e:
                app.logger.error(f"Failed to read conversion result: {e}")
                conversion_content = "Error reading conversion result file."
        
        # Prepare conversion data for template
        conversion_data = {
            'id': conversion.id,
            'source_technology': conversion.source_technology,
            'target_technology': conversion.target_technology,
            'conversion_depth': conversion.conversion_depth,
            'status': conversion.status,
            'content': conversion_content,
            'processing_time': conversion.processing_time or 0,
            'error_message': conversion.error_message,
            'created_at': conversion.created_at,
            'completed_at': conversion.completed_at
        }
        
        return render_template('conversion_result.html', conversion=conversion_data)
        
    except Exception as e:
        app.logger.error(f"Conversion result page error: {str(e)}")
        return render_template('error.html',
                             error_title="Error Loading Conversion",
                             error_message="An error occurred while loading the conversion result."), 500


@app.route('/health')
def health_check():
    """System health check"""
    try:
        health_status = {
            'status': 'healthy',
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'version': '1.0.0',
            'environment': os.environ.get('FLASK_ENV', 'development'),
            'connections': app.connection_status,
            'components': {
                'database': 'healthy' if app.connection_status.get('postgresql') else 'unavailable',
                'auth': 'available' if getattr(app, 'auth_available', False) else 'unavailable',
                'api': 'available' if getattr(app, 'api_available', False) else 'unavailable',
                'file_handler': 'available' if app.file_handler else 'unavailable',
                'ai_processor': 'available' if app.connection_status.get('azure_openai') else 'unavailable'
            }
        }
        
        # Test connections
        if app.connection_status.get('postgresql'):
            try:
                app.connection_manager.execute_database_query('SELECT 1', fetch=True)
            except Exception:
                health_status['components']['database'] = 'connection_failed'
                health_status['status'] = 'degraded'
        
        return jsonify(health_status)
        
    except Exception as e:
        app.logger.error(f"Health check failed: {str(e)}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }), 500

@app.route('/connections/status')
def connections_status():
    """Get detailed connection status"""
    try:
        return jsonify(app.connection_manager.get_connection_status())
    except Exception as e:
        app.logger.error(f"Connection status check failed: {str(e)}")
        return jsonify({'error': 'Connection status check failed'}), 500

@app.route('/connections/test')
def test_connections():
    """Test all connections"""
    try:
        results = app.connection_manager.initialize_all_connections()
        app.connection_status = results
        return jsonify({
            'message': 'Connection tests completed',
            'results': results,
            'timestamp': datetime.now(timezone.utc).isoformat()
        })
    except Exception as e:
        app.logger.error(f"Connection test failed: {str(e)}")
        return jsonify({'error': 'Connection test failed'}), 500

# Add debug routes for troubleshooting
@app.route('/debug/routes')
def debug_routes():
    """Debug route to show all registered routes"""
    routes = []
    for rule in app.url_map.iter_rules():
        routes.append({
            'rule': rule.rule,
            'endpoint': rule.endpoint,
            'methods': list(rule.methods)
        })
    return jsonify(routes)


# Add these routes to your app.py file after your existing routes

@app.route('/process-conversion/<conversion_id>', methods=['POST'])
def process_conversion_manually(conversion_id):
    """Manually trigger conversion processing"""
    try:
        if not MODELS_AVAILABLE or not app.connection_status.get('postgresql') or not app.db:
            return jsonify({'error': 'Database not available'}), 500
            
        conversion = Conversion.query.get(conversion_id)
        if not conversion:
            return jsonify({'error': 'Conversion not found'}), 404
            
        if conversion.status != ConversionStatus.QUEUED:
            return jsonify({'error': f'Conversion is already {conversion.status.value}'}), 400
            
        # Start background processing
        import threading
        
        def process_in_background():
            try:
                with app.app_context():
                    process_conversion_job(conversion_id)
            except Exception as e:
                app.logger.error(f"Background processing failed for {conversion_id}: {str(e)}")
        
        thread = threading.Thread(target=process_in_background)
        thread.daemon = True
        thread.start()
        
        return jsonify({
            'message': 'Processing started',
            'conversion_id': conversion_id,
            'status': 'processing'
        })
        
    except Exception as e:
        app.logger.error(f"Manual processing trigger failed: {str(e)}")
        return jsonify({'error': str(e)}), 500

def process_conversion_job(conversion_id):
    """Process a conversion job with AI - Enhanced with timeout and better error handling"""
    try:
        conversion = Conversion.query.get(conversion_id)
        if not conversion:
            return
            
        app.logger.info(f"Starting conversion processing: {conversion_id}")
        
        # Update status to processing
        conversion.status = ConversionStatus.PROCESSING
        conversion.started_at = datetime.now(timezone.utc)
        conversion.progress = 10
        app.db.session.commit()
        
        # Get document content
        document = conversion.document
        if not document or not os.path.exists(document.file_path):
            raise Exception("Document file not found")
            
        app.logger.info(f"Extracting content from: {document.file_path}")
        
        # Extract text content based on file type
        content = extract_document_content(document.file_path)
        conversion.progress = 30
        app.db.session.commit()
        
        app.logger.info(f"Content extracted, length: {len(content)} characters")
        
        # Check if Azure OpenAI is available
        if not app.connection_status.get('azure_openai'):
            raise Exception("AI service not available")
            
        # Generate conversion using Azure OpenAI with timeout
        conversion.progress = 50
        app.db.session.commit()
        
        app.logger.info(f"Starting AI conversion: {conversion.source_technology} -> {conversion.target_technology}")
        
        # Set a timeout for AI processing (5 minutes)
        import signal
        
        class TimeoutException(Exception):
            pass
        
        def timeout_handler(signum, frame):
            raise TimeoutException("AI processing timeout")
        
        # Set timeout signal (Unix systems only - for Windows, we'll use a different approach)
        try:
            signal.signal(signal.SIGALRM, timeout_handler)
            signal.alarm(300)  # 5 minutes timeout
            
            ai_result = generate_ai_conversion(
                content=content,
                source_tech=conversion.source_technology,
                target_tech=conversion.target_technology,
                depth=conversion.conversion_depth,
                config=conversion.get_configuration()
            )
            
            signal.alarm(0)  # Cancel timeout
            
        except (AttributeError, OSError):
            # Windows or no signal support - use simple approach
            app.logger.info("Using simple timeout approach (Windows compatible)")
            ai_result = generate_ai_conversion(
                content=content,
                source_tech=conversion.source_technology,
                target_tech=conversion.target_technology,
                depth=conversion.conversion_depth,
                config=conversion.get_configuration()
            )
        except TimeoutException:
            raise Exception("AI processing timed out after 5 minutes")
        
        conversion.progress = 80
        app.db.session.commit()
        
        app.logger.info(f"AI conversion completed, saving result")
        
        # Save result
        result_path = save_conversion_result(
            content=ai_result['content'],
            original_filename=document.original_name,
            output_format=conversion.output_format
        )
        
        # Update conversion record
        conversion.status = ConversionStatus.COMPLETED
        conversion.completed_at = datetime.now(timezone.utc)
        conversion.progress = 100
        conversion.result_path = result_path
        conversion.processing_time = (conversion.completed_at - conversion.started_at).total_seconds()
        conversion.ai_tokens_used = ai_result.get('tokens_used', 0)
        
        app.db.session.commit()
        app.logger.info(f"Conversion completed successfully: {conversion_id} in {conversion.processing_time:.2f}s")
        
    except Exception as e:
        app.logger.error(f"Conversion processing failed for {conversion_id}: {str(e)}")
        try:
            conversion = Conversion.query.get(conversion_id)
            if conversion:
                conversion.status = ConversionStatus.FAILED
                conversion.error_message = str(e)[:500]  # Limit error message length
                conversion.completed_at = datetime.now(timezone.utc)
                if conversion.started_at:
                    conversion.processing_time = (conversion.completed_at - conversion.started_at).total_seconds()
                app.db.session.commit()
                app.logger.info(f"Conversion marked as failed: {conversion_id}")
        except Exception as db_error:
            app.logger.error(f"Failed to update failed conversion status: {str(db_error)}")

def extract_document_content(file_path):
    """Extract text content from document"""
    file_ext = os.path.splitext(file_path)[1].lower()
    
    try:
        if file_ext == '.txt' or file_ext == '.md':
            with open(file_path, 'r', encoding='utf-8') as f:
                return f.read()
        elif file_ext == '.docx':
            try:
                from docx import Document as DocxDocument
                doc = DocxDocument(file_path)
                text_content = []
                for paragraph in doc.paragraphs:
                    if paragraph.text.strip():
                        text_content.append(paragraph.text)
                return '\n\n'.join(text_content)
            except ImportError:
                return f"[DOCX file: {os.path.basename(file_path)} - Text extraction requires python-docx]"
        elif file_ext == '.pdf':
            # PDF extraction code remains the same
            try:
                import PyPDF2
                with open(file_path, 'rb') as f:
                    reader = PyPDF2.PdfReader(f)
                    text = []
                    for page in reader.pages:
                        text.append(page.extract_text())
                    return '\n'.join(text)
            except ImportError:
                return f"[PDF file: {os.path.basename(file_path)} - Text extraction requires PyPDF2]"
        else:
            return f"[Document: {os.path.basename(file_path)} - Content extraction not implemented for {file_ext}]"
            
    except Exception as e:
        app.logger.error(f"Content extraction failed: {str(e)}")
        return f"[Error extracting content from {os.path.basename(file_path)}]"

def generate_ai_conversion(content, source_tech, target_tech, depth, config):
    """Generate conversion using Azure OpenAI - Enhanced with better error handling"""
    try:
        app.logger.info(f"Calling Azure OpenAI for conversion: {len(content)} chars")
        
        # Use the connection manager's Azure OpenAI client
        if not app.connection_manager.azure_openai:
            raise Exception("Azure OpenAI not available")
        
        # Limit content size to prevent token limit issues
        max_content_length = 8000  # Adjust based on your needs
        if len(content) > max_content_length:
            app.logger.warning(f"Content truncated from {len(content)} to {max_content_length} characters")
            content = content[:max_content_length] + "\n\n[Content truncated for processing...]"
        
        result = app.connection_manager.generate_ai_conversion(
            source_content=content,
            source_technology=source_tech,
            target_technology=target_tech,
            conversion_depth=depth,
            additional_instructions=None,
            custom_config=config
        )
        
        app.logger.info(f"Azure OpenAI conversion successful, tokens used: {result.get('tokens_used', 0)}")
        return result
        
    except Exception as e:
        app.logger.error(f"AI conversion failed: {str(e)}")
        app.logger.info("Falling back to placeholder conversion")
        
        # Fallback: generate a simple placeholder conversion
        return {
            'content': generate_fallback_conversion(content, source_tech, target_tech, str(e)),
            'tokens_used': 0
        }

def generate_fallback_conversion(content, source_tech, target_tech, error_reason=None):
    """Generate a simple fallback conversion when AI is not available"""
    error_section = ""
    if error_reason:
        error_section = f"""

## AI Processing Error

The automatic conversion failed with the following error:
```
{error_reason}
```

This document was generated using fallback processing instead.
"""
    
    return f"""# Document Conversion Report

**Source Technology:** {source_tech}
**Target Technology:** {target_tech}
**Conversion Date:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC
**Status:** Fallback Conversion{' (AI Error)' if error_reason else ' (AI not available)'}
{error_section}

## Original Content Preview

{content[:1000]}{'...' if len(content) > 1000 else ''}

## Conversion Notes

This conversion was generated using fallback processing. 
For a complete AI-powered conversion, please ensure Azure OpenAI is properly configured and accessible.

**Manual Steps Required:**
1. Review the original content above
2. Identify {source_tech}-specific components
3. Map to equivalent {target_tech} components
4. Update syntax, imports, and configurations
5. Test the converted implementation

**Key Areas to Focus On:**
- Configuration files and settings
- API endpoints and routing
- Data models and schemas
- Authentication and security
- Deployment and infrastructure

**Technology-Specific Guidance:**

### {source_tech} to {target_tech} Conversion
- Research equivalent features and components
- Check compatibility and migration paths  
- Update dependencies and libraries
- Modify configuration syntax
- Test functionality after conversion

---
*Generated by DocConverter Pro - Fallback Mode*
"""

def save_conversion_result(content, original_filename, output_format):
    """Save conversion result to file"""
    try:
        # Create results directory if it doesn't exist
        results_dir = os.path.join(app.config['UPLOAD_FOLDER'], 'results')
        os.makedirs(results_dir, exist_ok=True)
        
        # Generate unique filename - FIX: Use utcnow() instead of now()
        name = os.path.splitext(original_filename)[0]
        timestamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
        result_filename = f"{name}_converted_{timestamp}.{output_format}"
        result_path = os.path.join(results_dir, result_filename)
        
        # Save content
        with open(result_path, 'w', encoding='utf-8') as f:
            f.write(content)
            
        app.logger.info(f"Conversion result saved: {result_path}")
        return result_path
        
    except Exception as e:
        app.logger.error(f"Failed to save conversion result: {str(e)}")
        raise


# Add these routes to your existing app.py file

@app.route('/login')
def login_page():
    """Serve the login page"""
    # If user is already logged in, redirect to appropriate dashboard
    if 'user_id' in session:
        user_role = session.get('user_role')
        if user_role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
    
    try:
        return render_template('login.html')
    except Exception as e:
        app.logger.error(f"Login template rendering failed: {e}")
        return '''
        <!DOCTYPE html>
        <html>
        <head><title>Login - DocConverter Pro</title></head>
        <body>
            <h1>DocConverter Pro Login</h1>
            <p>Login template not found. Please create templates/login.html</p>
            <a href="/">Return to Home</a>
        </body>
        </html>
        '''

@app.route('/auth/login', methods=['POST'])
def api_login_fixed():
    """Fixed login API request handler"""
    try:
        data = request.get_json()
        if not data:
            return jsonify({'error': 'No data provided'}), 400
            
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        remember_me = data.get('remember_me', False)

        app.logger.info(f"Login attempt for email: {email}")

        if not email or not password:
            return jsonify({'error': 'Email and password are required'}), 400

        # Check if models are available
        if not MODELS_AVAILABLE or not app.db:
            app.logger.error("Authentication system unavailable - no models or db")
            return jsonify({'error': 'Authentication system unavailable'}), 503

        # Find user by email
        user = User.query.filter_by(email=email).first()
        if not user:
            app.logger.warning(f"User not found: {email}")
            return jsonify({'error': 'Invalid email or password'}), 401

        app.logger.info(f"User found: {user.email}, role: {user.role.value}, active: {user.is_active}")

        # Check password
        from werkzeug.security import check_password_hash
        if not check_password_hash(user.password_hash, password):
            app.logger.warning(f"Invalid password for user: {email}")
            return jsonify({'error': 'Invalid email or password'}), 401

        # Check if user is active
        if not user.is_active:
            app.logger.warning(f"Inactive user tried to login: {email}")
            return jsonify({'error': 'Account is deactivated'}), 401

        # Update last login
        user.last_login = datetime.now(timezone.utc)
        app.db.session.commit()

        # Set session
        session['user_id'] = user.id
        session['user_email'] = user.email
        session['user_role'] = user.role.value
        session['user_name'] = f"{user.first_name} {user.last_name}"
        
        if remember_me:
            session.permanent = True

        app.logger.info(f"User logged in successfully: {email}")

        return jsonify({
            'message': 'Login successful',
            'user': {
                'id': user.id,
                'email': user.email,
                'name': f"{user.first_name} {user.last_name}",
                'role': user.role.value,
                'is_admin': user.role == UserRole.ADMIN
            },
            'redirect_url': '/admin/dashboard' if user.role == UserRole.ADMIN else '/user/dashboard'
        })

    except Exception as e:
        app.logger.error(f"Login error: {str(e)}")
        return jsonify({'error': 'Login failed', 'details': str(e)}), 500
    
@app.route('/create-demo-users', methods=['POST'])
def create_demo_users():
    """Manually create demo users - for testing only"""
    try:
        if not MODELS_AVAILABLE or not app.db:
            return jsonify({'error': 'Database not available'}), 500
            
        from models import User, UserRole
        from werkzeug.security import generate_password_hash
        
        # Create admin user
        admin_user = User.query.filter_by(email='admin@docconverter.com').first()
        if not admin_user:
            admin_user = User(
                email='admin@docconverter.com',
                password_hash=generate_password_hash('Password123!'),
                first_name='System',
                last_name='Administrator',
                role=UserRole.ADMIN,
                is_active=True
            )
            app.db.session.add(admin_user)
        else:
            # Update existing admin password
            admin_user.password_hash = generate_password_hash('Password123!')
        
        # Create regular user
        demo_user = User.query.filter_by(email='user@docconverter.com').first()
        if not demo_user:
            demo_user = User(
                email='user@docconverter.com',
                password_hash=generate_password_hash('Password123!'),
                first_name='Demo',
                last_name='User',
                role=UserRole.USER,
                is_active=True
            )
            app.db.session.add(demo_user)
        else:
            # Update existing user password
            demo_user.password_hash = generate_password_hash('Password123!')
        
        app.db.session.commit()
        
        return jsonify({
            'message': 'Demo users created/updated successfully',
            'users': [
                {'email': 'admin@docconverter.com', 'role': 'admin'},
                {'email': 'user@docconverter.com', 'role': 'user'}
            ]
        })
        
    except Exception as e:
        app.db.session.rollback()
        return jsonify({'error': str(e)}), 500


@app.route('/debug/enums')
def debug_enums():
    """Debug route to check enum values"""
    try:
        from models import UserRole, ConversionStatus
        return jsonify({
            'UserRole': [role.value for role in UserRole],
            'ConversionStatus': [status.value for status in ConversionStatus]
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/auth/register', methods=['POST'])
def api_register():
    """Handle registration API request"""
    try:
        data = request.get_json()
        
        # Extract and validate data
        first_name = data.get('first_name', '').strip()
        last_name = data.get('last_name', '').strip()
        email = data.get('email', '').lower().strip()
        password = data.get('password', '')
        role = data.get('role', 'user')

        # Validation
        if not all([first_name, last_name, email, password]):
            return jsonify({'error': 'All fields are required'}), 400

        if len(password) < 8:
            return jsonify({'error': 'Password must be at least 8 characters'}), 400

        # Validate email format
        import re
        if not re.match(r'^[^@]+@[^@]+\.[^@]+$', email):
            return jsonify({'error': 'Invalid email format'}), 400

        # Check if models are available
        if not MODELS_AVAILABLE or not app.db:
            return jsonify({'error': 'Registration system unavailable'}), 503

        # Check if user already exists
        existing_user = User.query.filter_by(email=email).first()
        if existing_user:
            return jsonify({'error': 'User with this email already exists'}), 409

        # Create new user
        from werkzeug.security import generate_password_hash
        
        user_role = UserRole.ADMIN if role == 'admin' else UserRole.USER
        
        new_user = User(
            first_name=first_name,
            last_name=last_name,
            email=email,
            password_hash=generate_password_hash(password),
            role=user_role,
            is_active=True
        )

        app.db.session.add(new_user)
        app.db.session.commit()

        app.logger.info(f"New user registered: {email} ({role})")

        return jsonify({
            'message': 'Registration successful',
            'user': {
                'email': email,
                'name': f"{first_name} {last_name}",
                'role': role
            }
        }), 201

    except Exception as e:
        app.db.session.rollback()
        app.logger.error(f"Registration error: {str(e)}")
        return jsonify({'error': 'Registration failed'}), 500

@app.route('/auth/logout', methods=['POST'])
def api_logout():
    """Handle logout"""
    try:
        user_email = session.get('user_email', 'Unknown')
        session.clear()
        app.logger.info(f"User logged out: {user_email}")
        return jsonify({'message': 'Logout successful'})
    except Exception as e:
        app.logger.error(f"Logout error: {str(e)}")
        return jsonify({'error': 'Logout failed'}), 500

@app.route('/admin/dashboard')
def admin_dashboard():
    """Admin dashboard page"""
    try:
        # Check if user is logged in and is admin
        if 'user_id' not in session:
            return redirect(url_for('login_page'))
        
        if session.get('user_role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403

        # Pass current configuration to template
        return render_template('admin_dashboard.html', 
                             config=app.config,
                             session=session)
    except Exception as e:
        app.logger.error(f"Admin dashboard error: {str(e)}")
        return render_template('error.html',
                             error_title="Dashboard Error",
                             error_message="Unable to load admin dashboard"), 500

@app.route('/user/dashboard')
def user_dashboard():
    """User dashboard page"""
    try:
        # Check if user is logged in
        if 'user_id' not in session:
            return redirect(url_for('login_page'))

        return render_template('user_dashboard.html')
    except Exception as e:
        app.logger.error(f"User dashboard error: {str(e)}")
        return render_template('error.html',
                             error_title="Dashboard Error", 
                             error_message="Unable to load user dashboard"), 500

# Update the main index route to redirect to login if not authenticated
@app.route('/')
def index():
    """Main dashboard route - redirect to login if not authenticated"""
    try:
        # Check if user is logged in
        if 'user_id' not in session:
            return redirect(url_for('login_page'))
        
        # Redirect based on user role
        user_role = session.get('user_role')
        if user_role == 'admin':
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('user_dashboard'))
            
    except Exception as e:
        app.logger.error(f"Index route error: {str(e)}")
        return redirect(url_for('login_page'))

# Add configuration routes for admin
@app.route('/api/admin/azure-config', methods=['GET', 'POST'])
def admin_azure_config():
    """Get or update Azure OpenAI configuration"""
    try:
        # Check admin access
        if session.get('user_role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403

        if request.method == 'GET':
            # Get current configuration (masked for security)
            config = {
                'endpoint': app.config.get('AZURE_OPENAI_ENDPOINT', ''),
                'model': app.config.get('AZURE_OPENAI_MODEL', 'gpt-4'),
                'deployment': app.config.get('AZURE_OPENAI_DEPLOYMENT', 'doc-converter-gpt4'),
                'api_version': '2024-02-15-preview',
                'has_key': bool(app.config.get('AZURE_OPENAI_KEY')),
                'status': app.connection_status.get('azure_openai', False)
            }
            return jsonify(config)

        elif request.method == 'POST':
            data = request.get_json()
            
            # Update environment variables and app config
            if data.get('endpoint'):
                os.environ['AZURE_OPENAI_ENDPOINT'] = data['endpoint']
                app.config['AZURE_OPENAI_ENDPOINT'] = data['endpoint']
            
            if data.get('api_key'):
                os.environ['AZURE_OPENAI_KEY'] = data['api_key']
                app.config['AZURE_OPENAI_KEY'] = data['api_key']
            
            if data.get('model'):
                os.environ['AZURE_OPENAI_MODEL'] = data['model']
                app.config['AZURE_OPENAI_MODEL'] = data['model']
            
            if data.get('deployment'):
                os.environ['AZURE_OPENAI_DEPLOYMENT'] = data['deployment']
                app.config['AZURE_OPENAI_DEPLOYMENT'] = data['deployment']

            # Reinitialize Azure OpenAI connection
            app.connection_manager.initialize_azure_openai()
            app.connection_status['azure_openai'] = app.connection_manager.test_azure_openai()

            app.logger.info("Azure OpenAI configuration updated")
            
            return jsonify({
                'message': 'Configuration updated successfully',
                'status': app.connection_status.get('azure_openai', False)
            })

    except Exception as e:
        app.logger.error(f"Azure config error: {str(e)}")
        return jsonify({'error': 'Configuration update failed'}), 500

@app.route('/api/admin/db-config', methods=['GET', 'POST'])
def admin_db_config():
    """Get or update database configuration"""
    try:
        # Check admin access
        if session.get('user_role') != 'admin':
            return jsonify({'error': 'Admin access required'}), 403

        if request.method == 'GET':
            # Get current configuration (masked for security)
            config = {
                'host': os.environ.get('DB_HOST', 'localhost'),
                'port': os.environ.get('DB_PORT', '5432'),
                'name': os.environ.get('DB_NAME', 'doc_converter'),
                'user': os.environ.get('DB_USER', 'postgres'),
                'has_password': bool(os.environ.get('DB_PASSWORD')),
                'status': app.connection_status.get('postgresql', False)
            }
            return jsonify(config)

        elif request.method == 'POST':
            data = request.get_json()
            
            # Update environment variables
            if data.get('host'):
                os.environ['DB_HOST'] = data['host']
            if data.get('port'):
                os.environ['DB_PORT'] = str(data['port'])
            if data.get('name'):
                os.environ['DB_NAME'] = data['name']
            if data.get('user'):
                os.environ['DB_USER'] = data['user']
            if data.get('password'):
                os.environ['DB_PASSWORD'] = data['password']

            # Update app config
            app.config['SQLALCHEMY_DATABASE_URI'] = (
                f"postgresql://{os.environ.get('DB_USER')}:"
                f"{os.environ.get('DB_PASSWORD')}@"
                f"{os.environ.get('DB_HOST')}:"
                f"{os.environ.get('DB_PORT')}/"
                f"{os.environ.get('DB_NAME')}"
            )

            # Note: Database reconnection would require app restart in production
            app.logger.info("Database configuration updated (restart required)")
            
            return jsonify({
                'message': 'Configuration updated successfully. Restart required for database changes.',
                'restart_required': True
            })

    except Exception as e:
        app.logger.error(f"Database config error: {str(e)}")
        return jsonify({'error': 'Configuration update failed'}), 500

# Add session configuration to your create_app() function
# Add this inside create_app() after creating the app instance:
app.config.update({
    'SESSION_COOKIE_SECURE': not app.debug,
    'SESSION_COOKIE_HTTPONLY': True,
    'SESSION_COOKIE_SAMESITE': 'Lax',
    'PERMANENT_SESSION_LIFETIME': timedelta(hours=24)
})

# Enhanced download route with multiple format support
@app.route('/download-result/<conversion_id>')
def download_conversion_result_enhanced(conversion_id):
    """Download conversion result in multiple formats"""
    try:
        if not MODELS_AVAILABLE or not app.db:
            return jsonify({'error': 'Database not available'}), 500
            
        conversion = Conversion.query.get(conversion_id)
        if not conversion:
            return jsonify({'error': 'Conversion not found'}), 404
            
        if conversion.status != ConversionStatus.COMPLETED:
            return jsonify({'error': 'Conversion not completed'}), 400
            
        if not conversion.result_path or not os.path.exists(conversion.result_path):
            return jsonify({'error': 'Result file not found'}), 404
        
        # Read the conversion content
        with open(conversion.result_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Get requested format
        format_type = request.args.get('format', 'md').lower()
        original_name = conversion.document.original_name
        base_name = os.path.splitext(original_name)[0]
        
        if format_type == 'docx':
            return download_as_docx(content, f"{base_name}_converted.docx", conversion)
        elif format_type == 'pdf':
            return download_as_pdf(content, f"{base_name}_converted.pdf", conversion)
        elif format_type == 'txt':
            return download_as_txt(content, f"{base_name}_converted.txt")
        else:  # markdown (default)
            return download_as_markdown(content, f"{base_name}_converted.md")
            
    except Exception as e:
        app.logger.error(f"Download failed: {str(e)}")
        return jsonify({'error': 'Download failed'}), 500


def download_as_docx(content, filename, conversion):
    """Convert markdown content to DOCX format"""
    try:
        from docx import Document
        from docx.shared import Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH
        import re
        
        doc = Document()
        
        # Add title
        title = doc.add_heading('Document Conversion Report', 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER
        
        # Add conversion metadata
        doc.add_paragraph(f"Source Technology: {conversion.source_technology}")
        doc.add_paragraph(f"Target Technology: {conversion.target_technology}")
        doc.add_paragraph(f"Conversion Date: {conversion.completed_at.strftime('%Y-%m-%d %H:%M:%S')} UTC")
        doc.add_paragraph(f"Processing Time: {conversion.processing_time:.2f} seconds")
        doc.add_paragraph("")
        
        # Process markdown content
        lines = content.split('\n')
        current_paragraph = ""
        in_code_block = False
        
        for line in lines:
            # Skip the header section (already added above)
            if line.startswith('---') or 'Document Conversion Report' in line or 'Generated by:' in line:
                continue
                
            # Handle headers
            if line.startswith('### '):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                doc.add_heading(line[4:], level=3)
            elif line.startswith('## '):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                doc.add_heading(line[3:], level=2)
            elif line.startswith('# '):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                doc.add_heading(line[2:], level=1)
            
            # Handle code blocks
            elif line.startswith('```'):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                in_code_block = not in_code_block
                if not in_code_block:
                    continue
            elif in_code_block:
                p = doc.add_paragraph(line)
                # Style code blocks with monospace font
                for run in p.runs:
                    run.font.name = 'Courier New'
                    run.font.size = Inches(0.1)
            
            # Handle bullet points
            elif line.startswith('- ') or line.startswith('* '):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                doc.add_paragraph(line[2:], style='List Bullet')
            
            # Handle numbered lists
            elif re.match(r'^\d+\. ', line):
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
                doc.add_paragraph(line[3:], style='List Number')
            
            # Regular content
            elif line.strip():
                if current_paragraph:
                    current_paragraph += " " + line
                else:
                    current_paragraph = line
            else:
                if current_paragraph:
                    doc.add_paragraph(current_paragraph)
                    current_paragraph = ""
        
        # Add any remaining paragraph
        if current_paragraph:
            doc.add_paragraph(current_paragraph)
        
        # Save to memory
        doc_buffer = BytesIO()
        doc.save(doc_buffer)
        doc_buffer.seek(0)
        
        return send_file(
            doc_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document'
        )
        
    except ImportError:
        return jsonify({'error': 'DOCX export not available. Install python-docx package.'}), 500
    except Exception as e:
        app.logger.error(f"DOCX conversion failed: {str(e)}")
        return jsonify({'error': 'DOCX conversion failed'}), 500

def download_as_pdf(content, filename, conversion):
    """Convert markdown content to PDF format"""
    try:
        # Add the missing imports
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.lib import colors
        import re
        from io import BytesIO
        from flask import send_file, jsonify, current_app
        
        pdf_buffer = BytesIO()
        doc = SimpleDocTemplate(pdf_buffer, pagesize=A4)
        styles = getSampleStyleSheet()
        story = []
        
        # Custom styles
        title_style = ParagraphStyle(
            'CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            alignment=1,  # Center
            textColor=colors.HexColor('#4f46e5')
        )
        
        heading1_style = ParagraphStyle(
            'CustomHeading1',
            parent=styles['Heading1'],
            fontSize=16,
            textColor=colors.HexColor('#1f2937')
        )
        
        heading2_style = ParagraphStyle(
            'CustomHeading2', 
            parent=styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#4f46e5')
        )
        
        code_style = ParagraphStyle(
            'Code',
            parent=styles['Code'],
            fontSize=10,
            fontName='Courier',
            backColor=colors.HexColor('#f8fafc'),
            borderColor=colors.HexColor('#e5e7eb'),
            borderWidth=1,
            leftIndent=12,
            rightIndent=12,
            spaceAbove=6,
            spaceBelow=6
        )
        
        # Add title
        story.append(Paragraph("Document Conversion Report", title_style))
        story.append(Spacer(1, 12))
        
        # Add metadata
        story.append(Paragraph(f"<b>Source Technology:</b> {conversion.source_technology}", styles['Normal']))
        story.append(Paragraph(f"<b>Target Technology:</b> {conversion.target_technology}", styles['Normal']))
        story.append(Paragraph(f"<b>Conversion Date:</b> {conversion.completed_at.strftime('%Y-%m-%d %H:%M:%S')} UTC", styles['Normal']))
        story.append(Paragraph(f"<b>Processing Time:</b> {conversion.processing_time:.2f} seconds", styles['Normal']))
        story.append(Spacer(1, 12))
        
        # Process content
        lines = content.split('\n')
        in_code_block = False
        code_content = []
        
        for line in lines:
            # Skip header section
            if line.startswith('---') or 'Document Conversion Report' in line or 'Generated by:' in line:
                continue
                
            # Handle code blocks
            if line.startswith('```'):
                if in_code_block:
                    # End of code block
                    if code_content:
                        story.append(Paragraph('<br/>'.join(code_content), code_style))
                        story.append(Spacer(1, 6))
                        code_content = []
                in_code_block = not in_code_block
                continue
            elif in_code_block:
                code_content.append(line.replace('<', '&lt;').replace('>', '&gt;'))
                continue
            
            # Handle headers
            if line.startswith('### '):
                story.append(Paragraph(line[4:], styles['Heading3']))
            elif line.startswith('## '):
                story.append(Paragraph(line[3:], heading2_style))
            elif line.startswith('# '):
                story.append(Paragraph(line[2:], heading1_style))
            
            # Handle lists
            elif line.startswith('- ') or line.startswith('* '):
                story.append(Paragraph(f"• {line[2:]}", styles['Normal']))
            elif re.match(r'^\d+\. ', line):
                number = re.match(r'^(\d+)\. ', line).group(1)
                story.append(Paragraph(f"{number}. {line[len(number)+2:]}", styles['Normal']))
            
            # Regular paragraphs
            elif line.strip():
                # Convert bold markdown to HTML
                line = re.sub(r'\*\*(.*?)\*\*', r'<b>\1</b>', line)
                # Convert inline code to monospace
                line = re.sub(r'`([^`]+)`', r'<font name="Courier">\1</font>', line)
                story.append(Paragraph(line, styles['Normal']))
            else:
                story.append(Spacer(1, 6))
        
        # Build PDF
        doc.build(story)
        pdf_buffer.seek(0)
        
        return send_file(
            pdf_buffer,
            as_attachment=True,
            download_name=filename,
            mimetype='application/pdf'
        )
        
    except ImportError as e:
        current_app.logger.error(f"PDF import error: {str(e)}")
        return jsonify({'error': 'PDF export not available. Install reportlab package.'}), 500
    except Exception as e:
        current_app.logger.error(f"PDF conversion failed: {str(e)}")
        return jsonify({'error': f'PDF conversion failed: {str(e)}'}), 500


def download_as_txt(content, filename):
    """Convert markdown to plain text"""
    import re
    
    # Remove markdown formatting
    text = content
    text = re.sub(r'^#{1,6}\s+', '', text, flags=re.MULTILINE)  # Remove headers
    text = re.sub(r'\*\*(.*?)\*\*', r'\1', text)  # Remove bold
    text = re.sub(r'`([^`]+)`', r'\1', text)  # Remove inline code
    text = re.sub(r'^```.*?^```', '', text, flags=re.MULTILINE | re.DOTALL)  # Remove code blocks
    text = re.sub(r'^\* ', '• ', text, flags=re.MULTILINE)  # Convert bullets
    text = re.sub(r'^- ', '• ', text, flags=re.MULTILINE)  # Convert bullets
    
    return send_file(
        BytesIO(text.encode('utf-8')),
        as_attachment=True,
        download_name=filename,
        mimetype='text/plain'
    )


def download_as_markdown(content, filename):
    """Download as markdown (original format)"""
    return send_file(
        BytesIO(content.encode('utf-8')),
        as_attachment=True,
        download_name=filename,
        mimetype='text/markdown'
    )

# @app.route('/download-result/<conversion_id>')
# def download_conversion_result(conversion_id):
#     """Download conversion result file"""
#     try:
#         if not MODELS_AVAILABLE or not app.db:
#             return jsonify({'error': 'Database not available'}), 500
            
#         conversion = Conversion.query.get(conversion_id)
#         if not conversion:
#             return jsonify({'error': 'Conversion not found'}), 404
            
#         if conversion.status != ConversionStatus.COMPLETED:
#             return jsonify({'error': 'Conversion not completed'}), 400
            
#         if not conversion.result_path or not os.path.exists(conversion.result_path):
#             return jsonify({'error': 'Result file not found'}), 404
            
#         return send_file(
#             conversion.result_path,
#             as_attachment=True,
#             download_name=f"converted_{conversion.document.original_name}"
#         )
        
#     except Exception as e:
#         app.logger.error(f"Download failed: {str(e)}")
#         return jsonify({'error': 'Download failed'}), 500


# Add these routes to your app.py file for manual API testing

@app.route('/api/test-azure-openai', methods=['GET', 'POST'])
def test_azure_openai():
    """Test Azure OpenAI API manually - ENHANCED WITH BETTER DEBUGGING"""
    try:
        if request.method == 'POST':
            data = request.get_json() or {}
            test_prompt = data.get('prompt', 'Explain cloud computing in 3 key benefits.')
            max_tokens = data.get('max_tokens', 2000)  # Allow custom token limits
        else:
            test_prompt = request.args.get('prompt', 'Explain cloud computing in 3 key benefits.')
            max_tokens = int(request.args.get('max_tokens', 2000))
        
        if not app.connection_status.get('azure_openai'):
            return jsonify({
                'success': False,
                'error': 'Azure OpenAI not available',
                'connection_status': app.connection_status
            }), 503
        
        # ENHANCED: Use connection manager with higher token limit
        app.logger.info(f"Testing Azure OpenAI with prompt: '{test_prompt[:50]}...' and max_tokens: {max_tokens}")
        
        try:
            # Direct call to generate_completion with higher token limit
            messages = [
                {"role": "system", "content": "You are a helpful technical assistant. Provide clear, complete responses."},
                {"role": "user", "content": test_prompt}
            ]
            
            result = app.connection_manager.azure_openai.generate_completion(
                messages=messages,
                max_tokens=max_tokens,
                temperature=0.3
            )
            
            response_content = result.get('content', '')
            
            # Enhanced logging
            app.logger.info(f"API Test Results:")
            app.logger.info(f"  Response length: {len(response_content)} characters")
            app.logger.info(f"  Tokens used: {result.get('tokens_used', 0)}")
            app.logger.info(f"  Finish reason: {result.get('finish_reason')}")
            app.logger.info(f"  Prompt tokens: {result.get('prompt_tokens', 0)}")
            app.logger.info(f"  Completion tokens: {result.get('completion_tokens', 0)}")
            
            return jsonify({
                'test_successful': True,
                'prompt': test_prompt,
                'response': response_content,
                'response_length': len(response_content),
                'tokens_used': result.get('tokens_used', 0),
                'prompt_tokens': result.get('prompt_tokens', 0),
                'completion_tokens': result.get('completion_tokens', 0),
                'processing_time': result.get('processing_time', 0),
                'model': result.get('model'),
                'finish_reason': result.get('finish_reason'),
                'max_tokens_requested': max_tokens,
                'debug_info': {
                    'has_content': bool(response_content),
                    'content_preview': response_content[:100] if response_content else "[NO CONTENT]",
                    'deployment': app.connection_manager.azure_openai.deployment
                }
            })
            
        except Exception as api_error:
            app.logger.error(f"Azure OpenAI API call failed: {str(api_error)}")
            return jsonify({
                'test_successful': False,
                'error': str(api_error),
                'error_type': type(api_error).__name__,
                'prompt': test_prompt
            }), 500
        
    except Exception as e:
        app.logger.error(f"Azure OpenAI test failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e),
            'error_type': type(e).__name__
        }), 500
    

    
@app.route('/api/test-conversion', methods=['POST'])
def test_conversion_api():
    """Test document conversion with sample content"""
    try:
        data = request.get_json()
        
        # Default test content if none provided
        test_content = data.get('content', """
# PEGA Case Management System

## Overview
This document describes a PEGA-based case management system for processing customer service requests.

## Key Components

### Case Types
- Service Request Cases
- Complaint Cases  
- Billing Inquiry Cases

### Business Rules
- Priority assignment based on customer tier
- SLA calculations for response times
- Escalation rules for overdue cases

### Data Model
- Customer information
- Case details and history
- Resolution tracking

## Implementation
The system uses PEGA's built-in case management framework with custom business rules and data transforms.
""")
        
        source_tech = data.get('source_technology', 'pega')
        target_tech = data.get('target_technology', 'power_bi')
        conversion_depth = data.get('conversion_depth', 'detailed')
        
        if not app.connection_status.get('azure_openai'):
            return jsonify({
                'success': False,
                'error': 'Azure OpenAI not available',
                'connection_status': app.connection_status
            }), 503
        
        # Perform the conversion
        result = app.connection_manager.generate_ai_conversion(
            source_content=test_content,
            source_technology=source_tech,
            target_technology=target_tech,
            conversion_depth=conversion_depth
        )
        
        return jsonify({
            'success': True,
            'conversion': {
                'source_technology': source_tech,
                'target_technology': target_tech,
                'conversion_depth': conversion_depth,
                'content_length': len(result['content']),
                'tokens_used': result.get('tokens_used', 0),
                'processing_time': result.get('processing_time', 0),
                'content': result['content']
            }
        })
        
    except Exception as e:
        app.logger.error(f"Conversion test failed: {str(e)}")
        return jsonify({
            'success': False,
            'error': str(e),
            'error_type': type(e).__name__
        }), 500

@app.route('/api/azure-openai/info')
def azure_openai_info():
    """Get Azure OpenAI configuration and status"""
    try:
        if not app.connection_manager.azure_openai:
            return jsonify({
                'available': False,
                'error': 'Azure OpenAI not configured'
            })
        
        info = app.connection_manager.azure_openai.get_model_info()
        info['connection_test'] = app.connection_manager.azure_openai.check_connection()
        
        return jsonify(info)
        
    except Exception as e:
        app.logger.error(f"Azure OpenAI info failed: {str(e)}")
        return jsonify({
            'available': False,
            'error': str(e)
        }), 500

@app.route('/test-azure-openai')
def test_azure_openai_page():
    """Simple HTML page for testing Azure OpenAI"""
    return '''
    <!DOCTYPE html>
    <html>
    <head>
        <title>Azure OpenAI Test - DocConverter Pro</title>
        <style>
            body { font-family: Arial, sans-serif; margin: 40px; max-width: 800px; }
            .container { margin: 20px 0; }
            textarea { width: 100%; height: 100px; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
            button { background: #007cba; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; margin: 10px 5px 10px 0; }
            button:hover { background: #005a8b; }
            .result { background: #f5f5f5; padding: 15px; border-radius: 5px; margin: 10px 0; white-space: pre-wrap; }
            .error { background: #ffebee; border-left: 4px solid #f44336; }
            .success { background: #e8f5e9; border-left: 4px solid #4caf50; }
            .info { background: #e3f2fd; border-left: 4px solid #2196f3; }
            select { padding: 8px; margin: 5px; border: 1px solid #ddd; border-radius: 4px; }
        </style>
    </head>
    <body>
        <h1>Azure OpenAI API Test</h1>
        
        <div class="container">
            <h3>Connection Status</h3>
            <button onclick="checkConnection()">Check Connection</button>
            <div id="connectionResult"></div>
        </div>
        
        <div class="container">
            <h3>Simple API Test</h3>
            <textarea id="testPrompt" placeholder="Enter your test prompt here...">Explain the benefits of cloud computing in 3 key points.</textarea><br>
            <button onclick="testApi()">Test API</button>
            <div id="apiResult"></div>
        </div>
        
        <div class="container">
            <h3>Document Conversion Test</h3>
            <div>
                Source Technology: 
                <select id="sourceTech">
                    <option value="pega">PEGA BPM</option>
                    <option value="power_bi">Power BI</option>
                    <option value="salesforce">Salesforce</option>
                    <option value="servicenow">ServiceNow</option>
                    <option value="spring_boot">Spring Boot</option>
                </select>
            </div>
            <div>
                Target Technology: 
                <select id="targetTech">
                    <option value="power_bi">Power BI</option>
                    <option value="pega">PEGA BPM</option>
                    <option value="salesforce">Salesforce</option>
                    <option value="servicenow">ServiceNow</option>
                    <option value="power_automate">Power Automate</option>
                </select>
            </div>
            <div>
                Conversion Depth: 
                <select id="conversionDepth">
                    <option value="overview">Overview</option>
                    <option value="detailed" selected>Detailed</option>
                    <option value="comprehensive">Comprehensive</option>
                </select>
            </div>
            <textarea id="conversionContent" placeholder="Enter source content to convert (or leave blank for default test content)..."></textarea><br>
            <button onclick="testConversion()">Test Conversion</button>
            <div id="conversionResult"></div>
        </div>

        <script>
            async function checkConnection() {
                const resultDiv = document.getElementById('connectionResult');
                resultDiv.innerHTML = 'Checking connection...';
                
                try {
                    const response = await fetch('/api/azure-openai/info');
                    const data = await response.json();
                    
                    if (data.available !== false) {
                        resultDiv.innerHTML = `<div class="result success">
                            <strong>Connection Status:</strong> ${data.connection_test ? 'Connected' : 'Failed'}<br>
                            <strong>Model:</strong> ${data.model_name}<br>
                            <strong>Endpoint:</strong> ${data.endpoint}<br>
                            <strong>API Version:</strong> ${data.api_version}
                        </div>`;
                    } else {
                        resultDiv.innerHTML = `<div class="result error">
                            <strong>Error:</strong> ${data.error}
                        </div>`;
                    }
                } catch (error) {
                    resultDiv.innerHTML = `<div class="result error">
                        <strong>Connection Error:</strong> ${error.message}
                    </div>`;
                }
            }

            async function testApi() {
                const prompt = document.getElementById('testPrompt').value;
                const resultDiv = document.getElementById('apiResult');
                
                if (!prompt.trim()) {
                    resultDiv.innerHTML = '<div class="result error">Please enter a test prompt</div>';
                    return;
                }
                
                resultDiv.innerHTML = 'Testing API...';
                
                try {
                    const response = await fetch('/api/test-azure-openai', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify({ prompt: prompt })
                    });
                    
                    const data = await response.json();
                    
                    if (data.test_successful) {
                        resultDiv.innerHTML = `<div class="result success">
                            <strong>Response:</strong><br>${data.response}<br><br>
                            <strong>Tokens Used:</strong> ${data.tokens_used}<br>
                            <strong>Processing Time:</strong> ${data.processing_time.toFixed(2)}s<br>
                            <strong>Model:</strong> ${data.model}
                        </div>`;
                    } else {
                        resultDiv.innerHTML = `<div class="result error">
                            <strong>Error:</strong> ${data.error}<br>
                            <strong>Type:</strong> ${data.error_type}
                        </div>`;
                    }
                } catch (error) {
                    resultDiv.innerHTML = `<div class="result error">
                        <strong>Request Error:</strong> ${error.message}
                    </div>`;
                }
            }

            async function testConversion() {
                const sourceTech = document.getElementById('sourceTech').value;
                const targetTech = document.getElementById('targetTech').value;
                const conversionDepth = document.getElementById('conversionDepth').value;
                const content = document.getElementById('conversionContent').value;
                const resultDiv = document.getElementById('conversionResult');
                
                resultDiv.innerHTML = 'Testing conversion...';
                
                try {
                    const requestBody = {
                        source_technology: sourceTech,
                        target_technology: targetTech,
                        conversion_depth: conversionDepth
                    };
                    
                    if (content.trim()) {
                        requestBody.content = content;
                    }
                    
                    const response = await fetch('/api/test-conversion', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(requestBody)
                    });
                    
                    const data = await response.json();
                    
                    if (data.success) {
                        const conversion = data.conversion;
                        resultDiv.innerHTML = `<div class="result success">
                            <strong>Conversion Successful!</strong><br>
                            <strong>Source:</strong> ${conversion.source_technology}<br>
                            <strong>Target:</strong> ${conversion.target_technology}<br>
                            <strong>Content Length:</strong> ${conversion.content_length} characters<br>
                            <strong>Tokens Used:</strong> ${conversion.tokens_used}<br>
                            <strong>Processing Time:</strong> ${conversion.processing_time.toFixed(2)}s<br><br>
                            <strong>Generated Content (first 500 chars):</strong><br>
                            <div style="background: white; padding: 10px; border: 1px solid #ddd; border-radius: 4px; margin-top: 10px;">
                                ${conversion.content.substring(0, 500)}${conversion.content.length > 500 ? '...' : ''}
                            </div>
                            <br>
                            <button onclick="showFullContent('${conversion.content.replace(/'/g, "\\'")}')">Show Full Content</button>
                        </div>`;
                    } else {
                        resultDiv.innerHTML = `<div class="result error">
                            <strong>Conversion Failed:</strong> ${data.error}<br>
                            <strong>Type:</strong> ${data.error_type}
                        </div>`;
                    }
                } catch (error) {
                    resultDiv.innerHTML = `<div class="result error">
                        <strong>Request Error:</strong> ${error.message}
                    </div>`;
                }
            }

            function showFullContent(content) {
                const newWindow = window.open('', '_blank');
                newWindow.document.write(`
                    <html>
                        <head><title>Full Conversion Result</title></head>
                        <body style="font-family: Arial, sans-serif; margin: 20px; white-space: pre-wrap;">
                            ${content.replace(/\n/g, '<br>')}
                        </body>
                    </html>
                `);
            }

            // Auto-check connection on page load
            window.onload = function() {
                checkConnection();
            };
        </script>
    </body>
    </html>
    '''

@app.route('/debug/db')
def debug_db():
    """Debug database connection and SQLAlchemy status"""
    try:
        status = {
            'models_available': MODELS_AVAILABLE,
            'app_db_exists': hasattr(app, 'db') and app.db is not None,
            'postgresql_connected': app.connection_status.get('postgresql', False),
            'app_db_available_flag': getattr(app, 'db_available', False),
            'app_models_available_flag': getattr(app, 'models_available', False)
        }
        
        if hasattr(app, 'db') and app.db:
            try:
                # Test a simple query
                result = app.db.session.execute(text('SELECT 1')).fetchone()
                status['db_query_test'] = 'success' if result else 'failed'
                
                # Test model query if available
                if MODELS_AVAILABLE:
                    count = Document.query.count()
                    status['model_query_test'] = f'success - {count} documents'
                    
            except Exception as e:
                status['db_query_test'] = f'error: {str(e)}'
        else:
            status['db_query_test'] = 'no db object'
        
        return jsonify(status)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Resource not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    app.logger.error(f"Internal error: {str(error)}")
    return jsonify({'error': 'Internal server error'}), 500

@app.errorhandler(413)
def file_too_large(error):
    return jsonify({'error': 'File too large'}), 413

# Cleanup on app shutdown
@app.teardown_appcontext
def cleanup_connections(error):
    """Clean up connections when app context tears down"""
    if error:
        app.logger.error(f"App context error: {error}")

if __name__ == '__main__':
    print("=" * 60)
    print("DocConverter Pro - Starting Application")
    print("=" * 60)
    print(f"Environment: {os.environ.get('FLASK_ENV', 'development')}")
    print(f"Debug mode: {app.debug}")
    print(f"Upload folder: {app.config.get('UPLOAD_FOLDER')}")
    
    # Display connection status
    print("\nConnection Status:")
    for connection, status in app.connection_status.items():
        status_text = "✓ Connected" if status else "✗ Failed"
        print(f"  {connection}: {status_text}")
    
    # Display component availability
    print("\nComponents:")
    print(f"  Database: {'✓ Available' if hasattr(app, 'db') and app.db else '✗ Not Available'}")
    print(f"  Models: {'✓ Available' if MODELS_AVAILABLE else '✗ Not Available'}")
    print(f"  Auth: {'✓ Available' if getattr(app, 'auth_available', False) else '✗ Not Available'}")
    print(f"  API: {'✓ Available' if getattr(app, 'api_available', False) else '✗ Not Available'}")
    
    print(f"\nAdmin: {os.environ.get('ADMIN_EMAIL', 'Not configured')}")
    print("=" * 60)
    print("Access the application at: http://localhost:5000")
    print("Health check: http://localhost:5000/health")
    print("Connection status: http://localhost:5000/connections/status")
    print("Debug routes: http://localhost:5000/debug/routes")
    print("Debug database: http://localhost:5000/debug/db")
    print("Press Ctrl+C to stop")
    print("-" * 60)
    
    try:
        app.run(
            debug=app.debug,
            host='0.0.0.0',
            port=5000
        )
    except KeyboardInterrupt:
        print("\nShutting down...")
        app.connection_manager.close_all_connections()
        print("Application stopped.")