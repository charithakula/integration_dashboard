#!/usr/bin/env python3
"""
Startup script for DocConverter Pro with PostgreSQL
This script includes PostgreSQL-specific checks and setup
"""

import sys
import os
import traceback
from dotenv import load_dotenv

def check_postgresql_dependencies():
    """Check PostgreSQL-specific dependencies"""
    missing_deps = []
    
    # Core Flask dependencies
    try:
        import flask
        print(f"✓ Flask {flask.__version__}")
    except ImportError:
        missing_deps.append("Flask")
    
    try:
        import flask_sqlalchemy
        print(f"✓ Flask-SQLAlchemy {flask_sqlalchemy.__version__}")
    except ImportError:
        missing_deps.append("Flask-SQLAlchemy")
    
    try:
        import flask_cors
        print("✓ Flask-CORS")
    except ImportError:
        missing_deps.append("Flask-CORS")
    
    # PostgreSQL specific
    try:
        import psycopg2
        print(f"✓ psycopg2 {psycopg2.__version__}")
    except ImportError:
        missing_deps.append("psycopg2-binary")
        print("❌ psycopg2 not found - PostgreSQL adapter required")
    
    # Optional dependencies
    optional_deps = [
        ('PyPDF2', 'PDF processing'),
        ('docx', 'DOCX processing'),
        ('markdown', 'Markdown processing')
    ]
    
    for dep, description in optional_deps:
        try:
            __import__(dep)
            print(f"✓ {dep} ({description})")
        except ImportError:
            print(f"⚠ {dep} not installed ({description} disabled)")
    
    if missing_deps:
        print(f"\n❌ Missing required dependencies: {', '.join(missing_deps)}")
        print("Install with: pip install " + " ".join(missing_deps))
        return False
    
    print("\n✓ All required dependencies found")
    return True

def check_database_config():
    """Check database configuration"""
    print("\nChecking database configuration...")
    
    db_url = os.environ.get('DATABASE_URL')
    if db_url:
        print(f"✓ DATABASE_URL found")
        if db_url.startswith('postgresql://'):
            print("✓ PostgreSQL URL format detected")
            return True
        else:
            print("❌ DATABASE_URL doesn't appear to be PostgreSQL")
            return False
    
    # Check individual parameters
    required_params = ['DB_HOST', 'DB_NAME', 'DB_USER']
    missing_params = []
    
    for param in required_params:
        value = os.environ.get(param)
        if value:
            print(f"✓ {param}: {value}")
        else:
            missing_params.append(param)
    
    if missing_params:
        print(f"❌ Missing database parameters: {', '.join(missing_params)}")
        print("\nPlease set these environment variables:")
        print("DB_HOST=localhost")
        print("DB_PORT=5432")
        print("DB_NAME=doc_converter") 
        print("DB_USER=postgres")
        print("DB_PASSWORD=your_password")
        print("\nOr use a complete DATABASE_URL:")
        print("DATABASE_URL=postgresql://user:pass@localhost:5432/doc_converter")
        return False
    
    return True

def test_database_connection():
    """Test PostgreSQL connection"""
    print("\nTesting PostgreSQL connection...")
    
    try:
        import psycopg2
        from urllib.parse import urlparse
        
        db_url = os.environ.get('DATABASE_URL')
        if db_url:
            parsed = urlparse(db_url)
            conn_params = {
                'host': parsed.hostname,
                'port': parsed.port or 5432,
                'user': parsed.username,
                'password': parsed.password,
                'database': parsed.path[1:]  # Remove leading slash
            }
        else:
            conn_params = {
                'host': os.environ.get('DB_HOST', 'localhost'),
                'port': int(os.environ.get('DB_PORT', 5432)),
                'user': os.environ.get('DB_USER', 'postgres'),
                'password': os.environ.get('DB_PASSWORD', ''),
                'database': os.environ.get('DB_NAME', 'doc_converter')
            }
        
        # Test connection
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()
        cursor.execute('SELECT version();')
        version = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        
        print(f"✓ Connected to PostgreSQL")
        print(f"  Version: {version.split()[1]}")
        print(f"  Database: {conn_params['database']}")
        return True
        
    except ImportError:
        print("❌ psycopg2 not available")
        return False
    except Exception as e:
        print(f"❌ Connection failed: {e}")
        print("\nTroubleshooting:")
        print("1. Ensure PostgreSQL server is running")
        print("2. Check host, port, username, password")
        print("3. Verify database exists")
        print("4. Check user permissions")
        return False

def create_directories():
    """Create necessary directories"""
    directories = [
        'uploads',
        'uploads/documents', 
        'uploads/results',
        'uploads/temp',
        'logs',
        'backups',
        'templates'
    ]
    
    for directory in directories:
        try:
            os.makedirs(directory, exist_ok=True)
            print(f"✓ Directory: {directory}")
        except Exception as e:
            print(f"⚠ Could not create directory {directory}: {e}")

def main():
    """Main startup function"""
    print("=" * 60)
    print("DocConverter Pro - PostgreSQL Startup")
    print("=" * 60)
    
    # Load environment variables
    if os.path.exists('.env'):
        load_dotenv()
        print("✓ Loaded .env file")
    else:
        print("⚠ No .env file found")
        print("  Consider running: python setup_postgresql.py")
    
    # Check Python version
    python_version = sys.version_info
    print(f"Python version: {python_version.major}.{python_version.minor}.{python_version.micro}")
    
    if python_version < (3, 8):
        print("❌ Python 3.8+ required")
        sys.exit(1)
    
    # Check dependencies
    if not check_postgresql_dependencies():
        sys.exit(1)
    
    # Check database configuration
    if not check_database_config():
        print("\nRun setup: python setup_postgresql.py")
        sys.exit(1)
    
    # Test database connection
    if not test_database_connection():
        sys.exit(1)
    
    # Create directories
    print("\nCreating directories...")
    create_directories()
    
    # Set environment variables
    os.environ.setdefault('FLASK_ENV', 'development')
    os.environ.setdefault('FLASK_DEBUG', '1')
    
    print("\nStarting application...")
    print("=" * 60)
    
    try:
        # Import and create the app
        from app import create_app
        app = create_app()
        
        # Test basic functionality
        with app.app_context():
            print("✓ Application context created")
            
            # Test database initialization
            from database import check_db_connection, init_db
            if check_db_connection():
                print("✓ Database connection verified")
                if init_db():
                    print("✓ Database tables created/verified")
                else:
                    print("⚠ Database initialization had issues")
            else:
                print("❌ Database connection failed in Flask context")
        
        print("✓ Application loaded successfully")
        print(f"✓ Upload folder: {app.config.get('UPLOAD_FOLDER', 'uploads')}")
        print(f"✓ Debug mode: {app.debug}")
        
        print("\nStarting Flask development server...")
        print("Access the application at: http://localhost:5000")
        print("Admin login: admin@docconverter.com / admin123")
        print("Press Ctrl+C to stop the server")
        print("-" * 60)
        
        app.run(
            debug=True,
            host='0.0.0.0',
            port=5000,
            use_reloader=False  # Disable reloader to prevent issues
        )
        
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("\nMake sure all required files are present:")
        print("- app.py")
        print("- config.py") 
        print("- database.py")
        print("- models.py")
        traceback.print_exc()
        sys.exit(1)
        
    except Exception as e:
        print(f"❌ Startup error: {e}")
        traceback.print_exc()
        sys.exit(1)

if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\n\nShutting down gracefully...")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Fatal error: {e}")
        traceback.print_exc()
        sys.exit(1)