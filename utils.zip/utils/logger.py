import logging
import logging.handlers
import os
from datetime import datetime
from flask import request, session, current_app
from models import AuditLog, db
import json

def setup_logger(name, log_file=None, level=logging.INFO):
    """Set up application logger"""
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    # Remove existing handlers
    for handler in logger.handlers[:]:
        logger.removeHandler(handler)
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    
    # File handler
    if log_file:
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        file_handler = logging.handlers.RotatingFileHandler(
            log_file, 
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5
        )
        file_handler.setLevel(level)
    
    # Formatter
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    console_handler.setFormatter(formatter)
    if log_file:
        file_handler.setFormatter(formatter)
    
    # Add handlers
    logger.addHandler(console_handler)
    if log_file:
        logger.addHandler(file_handler)
    
    return logger

def log_activity(user_id=None, action=None, resource_type=None, resource_id=None, 
                details=None, ip_address=None, user_agent=None):
    """Log user activity to audit trail"""
    try:
        # Get request context if available
        if not ip_address and request:
            ip_address = request.remote_addr
        
        if not user_agent and request:
            user_agent = request.headers.get('User-Agent', '')[:500]  # Truncate
        
        # Create audit log entry
        audit_log = AuditLog(
            user_id=user_id,
            action=action,
            resource_type=resource_type,
            resource_id=resource_id,
            ip_address=ip_address,
            user_agent=user_agent
        )
        
        if details:
            audit_log.set_details(details)
        
        db.session.add(audit_log)
        db.session.commit()
        
    except Exception as e:
        current_app.logger.error(f"Failed to log activity: {str(e)}")
        # Don't raise exception to avoid breaking main functionality

class SecurityLogger:
    """Enhanced logging for security events"""
    
    def __init__(self):
        self.logger = logging.getLogger('security')
        
    def log_login_attempt(self, email, success, reason=None, ip_address=None):
        """Log login attempts"""
        event = {
            'event_type': 'login_attempt',
            'email': email,
            'success': success,
            'reason': reason,
            'ip_address': ip_address,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        if success:
            self.logger.info(f"Successful login: {email} from {ip_address}")
        else:
            self.logger.warning(f"Failed login: {email} from {ip_address} - {reason}")
        
        log_activity(
            action='login_attempt',
            details=event,
            ip_address=ip_address
        )
    
    def log_permission_denied(self, user_id, resource, action, ip_address=None):
        """Log permission denied events"""
        event = {
            'event_type': 'permission_denied',
            'user_id': user_id,
            'resource': resource,
            'action': action,
            'ip_address': ip_address,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        self.logger.warning(f"Permission denied: User {user_id} attempted {action} on {resource}")
        
        log_activity(
            user_id=user_id,
            action='permission_denied',
            resource_type=resource,
            details=event,
            ip_address=ip_address
        )
    
    def log_file_access(self, user_id, file_path, action, success=True):
        """Log file access events"""
        event = {
            'event_type': 'file_access',
            'user_id': user_id,
            'file_path': file_path,
            'action': action,
            'success': success,
            'timestamp': datetime.utcnow().isoformat()
        }
        
        level = logging.INFO if success else logging.WARNING
        self.logger.log(level, f"File {action}: {file_path} by user {user_id} - {'Success' if success else 'Failed'}")
        
        log_activity(
            user_id=user_id,
            action=f'file_{action}',
            resource_type='file',
            details=event
        )

class PerformanceLogger:
    """Logger for performance monitoring"""
    
    def __init__(self):
        self.logger = logging.getLogger('performance')
    
    def log_request_timing(self, endpoint, method, duration, status_code):
        """Log request timing information"""
        self.logger.info(f"{method} {endpoint} - {duration:.3f}s - {status_code}")
        
        if duration > 5.0:  # Log slow requests
            self.logger.warning(f"Slow request: {method} {endpoint} took {duration:.3f}s")
    
    def log_conversion_timing(self, conversion_id, duration, tokens_used=None):
        """Log conversion performance"""
        message = f"Conversion {conversion_id} completed in {duration:.2f}s"
        if tokens_used:
            message += f" using {tokens_used} tokens"
        
        self.logger.info(message)
        
        # Log as activity
        log_activity(
            action='conversion_performance',
            resource_type='conversion',
            resource_id=conversion_id,
            details={
                'duration_seconds': duration,
                'tokens_used': tokens_used
            }
        )

def configure_app_logging(app):
    """Configure logging for Flask application"""
    # Main application logger
    app.logger = setup_logger(
        'doc_converter',
        app.config.get('LOG_FILE', 'logs/app.log'),
        getattr(logging, app.config.get('LOG_LEVEL', 'INFO'))
    )
    
    # Security logger
    security_logger = setup_logger(
        'security',
        'logs/security.log',
        logging.WARNING
    )
    
    # Performance logger
    performance_logger = setup_logger(
        'performance', 
        'logs/performance.log',
        logging.INFO
    )
    
    # Store loggers in app context
    app.security_logger = SecurityLogger()
    app.performance_logger = PerformanceLogger()
    
    return app.logger