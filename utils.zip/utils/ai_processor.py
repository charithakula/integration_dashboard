import asyncio
import threading
import time
from datetime import datetime
import openai
from flask import current_app
from models import Conversion, ConversionStatus, db
from utils.file_handler import FileHandler
from utils.logger import log_activity
import json
import re

class AIProcessor:
    """AI-powered document conversion processor"""
    
    def __init__(self, endpoint, api_key, model="gpt-4"):
        self.endpoint = endpoint
        self.api_key = api_key
        self.model = model
        self.processing_queue = []
        self.processing_threads = {}
        self.max_concurrent = 3
        
        # Configure OpenAI client
        openai.api_type = "azure"
        openai.api_base = endpoint
        openai.api_key = api_key
        openai.api_version = "2023-12-01-preview"
    
    def queue_conversion(self, conversion_id):
        """Add conversion to processing queue"""
        if conversion_id not in self.processing_queue:
            self.processing_queue.append(conversion_id)
            self._start_processing()
    
    def _start_processing(self):
        """Start processing queued conversions"""
        active_threads = len([t for t in self.processing_threads.values() if t.is_alive()])
        
        if active_threads < self.max_concurrent and self.processing_queue:
            conversion_id = self.processing_queue.pop(0)
            
            thread = threading.Thread(
                target=self._process_conversion,
                args=(conversion_id,),
                daemon=True
            )
            thread.start()
            self.processing_threads[conversion_id] = thread
    
    def _process_conversion(self, conversion_id):
        """Process a single conversion"""
        try:
            with current_app.app_context():
                conversion = Conversion.query.get(conversion_id)
                if not conversion:
                    return
                
                # Update status to processing
                conversion.status = ConversionStatus.PROCESSING
                conversion.started_at = datetime.utcnow()
                conversion.progress = 10
                db.session.commit()
                
                # Extract document content
                file_handler = FileHandler(current_app.config['UPLOAD_FOLDER'])
                document_path = conversion.document.file_path
                
                if not document_path or not os.path.exists(document_path):
                    self._handle_conversion_error(conversion, "Document file not found")
                    return
                
                # Extract text content
                conversion.progress = 30
                db.session.commit()
                
                text_content = file_handler.extract_text_content(document_path)
                
                # Generate AI prompt
                conversion.progress = 50
                db.session.commit()
                
                prompt = self._generate_conversion_prompt(
                    text_content,
                    conversion.source_technology,
                    conversion.target_technology,
                    conversion.conversion_depth,
                    conversion.get_configuration()
                )
                
                # Process with AI
                conversion.progress = 70
                db.session.commit()
                
                ai_response = self._call_ai_service(prompt)
                
                # Save result
                conversion.progress = 90
                db.session.commit()
                
                result_path = file_handler.save_conversion_result(
                    ai_response['content'],
                    conversion.document.original_name,
                    conversion.output_format
                )
                
                # Update conversion record
                conversion.status = ConversionStatus.COMPLETED
                conversion.completed_at = datetime.utcnow()
                conversion.progress = 100
                conversion.result_path = result_path
                conversion.processing_time = (conversion.completed_at - conversion.started_at).total_seconds()
                conversion.ai_tokens_used = ai_response.get('tokens_used', 0)
                
                db.session.commit()
                
                # Log completion
                log_activity(
                    user_id=conversion.user_id,
                    action='conversion_completed',
                    resource_type='conversion',
                    resource_id=conversion_id,
                    details={
                        'processing_time': conversion.processing_time,
                        'tokens_used': conversion.ai_tokens_used
                    }
                )
                
                current_app.logger.info(f"Conversion completed: {conversion_id}")
                
        except Exception as e:
            self._handle_conversion_error(conversion, str(e))
        
        finally:
            # Clean up and start next job
            if conversion_id in self.processing_threads:
                del self.processing_threads[conversion_id]
            self._start_processing()
    
    def _generate_conversion_prompt(self, content, source_tech, target_tech, depth, config):
        """Generate AI prompt for document conversion"""
        
        system_prompt = f"""You are an expert technical writer and software architect specializing in technology migrations. 
Your task is to convert technical documentation from {source_tech} to {target_tech}.

Guidelines:
- Maintain the original document structure and organization
- Update all technical references, code examples, and terminology
- Provide accurate and up-to-date information for {target_tech}
- Include migration notes where significant changes are required
- Preserve the original intent and level of technical detail
- Use clear, professional technical writing style

Conversion depth: {depth}
- comprehensive: Include detailed explanations, code examples, and migration steps
- detailed: Include technical details with some code examples
- overview: High-level conversion with minimal code examples
- architecture: Focus on architectural patterns and design decisions
- migration: Focus on migration strategy and implementation steps

Output format: Clean, well-structured markdown with proper headings, code blocks, and formatting."""

        user_prompt = f"""Convert the following {source_tech} documentation to {target_tech}:

--- Original Document ---
{content}
--- End Document ---

Configuration options:
{json.dumps(config, indent=2)}

Please convert this document following the guidelines above."""

        return {
            'system': system_prompt,
            'user': user_prompt
        }
    
    def _call_ai_service(self, prompt):
        """Call Azure OpenAI service"""
        try:
            response = openai.ChatCompletion.create(
                engine=current_app.config.get('AZURE_OPENAI_DEPLOYMENT', 'doc-converter-gpt4'),
                messages=[
                    {"role": "system", "content": prompt['system']},
                    {"role": "user", "content": prompt['user']}
                ],
                temperature=0.3,
                max_tokens=4000,
                top_p=0.95,
                frequency_penalty=0,
                presence_penalty=0
            )
            
            content = response.choices[0].message.content
            tokens_used = response.usage.total_tokens
            
            # Post-process the content
            processed_content = self._post_process_content(content)
            
            return {
                'content': processed_content,
                'tokens_used': tokens_used,
                'model': response.model
            }
            
        except Exception as e:
            current_app.logger.error(f"AI service call failed: {str(e)}")
            raise
    
    def _post_process_content(self, content):
        """Post-process AI-generated content"""
        # Clean up common AI response artifacts
        content = re.sub(r'^```\w*\n', '', content, flags=re.MULTILINE)
        content = re.sub(r'\n```$', '', content)
        
        # Ensure proper markdown formatting
        content = self._fix_markdown_formatting(content)
        
        # Add conversion metadata
        metadata = f"""---
Generated by: DocConverter Pro
Conversion Date: {datetime.utcnow().isoformat()}
AI Model: {self.model}
---

"""
        
        return metadata + content
    
    def _fix_markdown_formatting(self, content):
        """Fix common markdown formatting issues"""
        # Ensure code blocks have proper language tags
        content = re.sub(r'```(\n)', r'```\1', content)
        
        # Ensure proper heading spacing
        content = re.sub(r'\n(#{1,6})', r'\n\n\1', content)
        content = re.sub(r'(#{1,6}.*)\n([^#\n])', r'\1\n\n\2', content)
        
        # Fix list formatting
        content = re.sub(r'\n(\d+\.|\*|\-) ', r'\n\n\1 ', content)
        
        return content.strip()
    
    def _handle_conversion_error(self, conversion, error_message):
        """Handle conversion errors"""
        try:
            conversion.status = ConversionStatus.FAILED
            conversion.error_message = error_message
            conversion.completed_at = datetime.utcnow()
            
            if conversion.started_at:
                conversion.processing_time = (conversion.completed_at - conversion.started_at).total_seconds()
            
            db.session.commit()
            
            # Log error
            log_activity(
                user_id=conversion.user_id,
                action='conversion_failed',
                resource_type='conversion',
                resource_id=conversion.id,
                details={'error': error_message}
            )
            
            current_app.logger.error(f"Conversion failed: {conversion.id} - {error_message}")
            
        except Exception as e:
            current_app.logger.error(f"Error handling conversion failure: {str(e)}")
    
    def get_processing_status(self):
        """Get current processing status"""
        active_threads = len([t for t in self.processing_threads.values() if t.is_alive()])
        
        return {
            'queue_length': len(self.processing_queue),
            'active_jobs': active_threads,
            'max_concurrent': self.max_concurrent,
            'processing_threads': list(self.processing_threads.keys())
        }
    
    def cancel_conversion(self, conversion_id):
        """Cancel a queued or processing conversion"""
        try:
            # Remove from queue if queued
            if conversion_id in self.processing_queue:
                self.processing_queue.remove(conversion_id)
                
                with current_app.app_context():
                    conversion = Conversion.query.get(conversion_id)
                    if conversion:
                        conversion.status = ConversionStatus.FAILED
                        conversion.error_message = "Cancelled by user"
                        conversion.completed_at = datetime.utcnow()
                        db.session.commit()
                
                return True
            
            # Note: Cannot safely cancel threads that are already processing
            # This would require more complex thread management
            return False
            
        except Exception as e:
            current_app.logger.error(f"Conversion cancellation failed: {str(e)}")
            return False
    
    def cleanup_failed_jobs(self):
        """Clean up failed conversion jobs"""
        try:
            with current_app.app_context():
                # Find conversions stuck in processing state for more than 1 hour
                stuck_time = datetime.utcnow() - timedelta(hours=1)
                stuck_conversions = Conversion.query.filter(
                    Conversion.status == ConversionStatus.PROCESSING,
                    Conversion.started_at < stuck_time
                ).all()
                
                cleaned_count = 0
                for conversion in stuck_conversions:
                    conversion.status = ConversionStatus.FAILED
                    conversion.error_message = "Processing timeout - job cleanup"
                    conversion.completed_at = datetime.utcnow()
                    cleaned_count += 1
                
                if cleaned_count > 0:
                    db.session.commit()
                    current_app.logger.info(f"Cleaned up {cleaned_count} stuck conversion jobs")
                
                return cleaned_count
                
        except Exception as e:
            current_app.logger.error(f"Job cleanup failed: {str(e)}")
            return 0