import re
from email_validator import validate_email as email_validate, EmailNotValidError

def validate_email(email):
    """Validate email format"""
    try:
        email_validate(email)
        return True
    except EmailNotValidError:
        return False

def validate_password(password):
    """Validate password strength"""
    errors = []
    
    if len(password) < 8:
        errors.append("Password must be at least 8 characters long")
    
    if len(password) > 128:
        errors.append("Password must be less than 128 characters")
    
    if not re.search(r'[A-Z]', password):
        errors.append("Password must contain at least one uppercase letter")
    
    if not re.search(r'[a-z]', password):
        errors.append("Password must contain at least one lowercase letter")
    
    if not re.search(r'\d', password):
        errors.append("Password must contain at least one digit")
    
    if not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
        errors.append("Password must contain at least one special character")
    
    return errors

def validate_file_upload(file):
    """Validate file upload parameters"""
    errors = []
    
    if not file or file.filename == '':
        errors.append("No file provided")
        return errors
    
    # Check file extension
    allowed_extensions = {'pdf', 'docx', 'txt', 'md', 'pptx'}
    file_ext = file.filename.rsplit('.', 1)[1].lower() if '.' in file.filename else ''
    
    if file_ext not in allowed_extensions:
        errors.append(f"File type '{file_ext}' not supported. Allowed types: {', '.join(allowed_extensions)}")
    
    # Check file size (50MB max)
    max_size = 50 * 1024 * 1024
    file.seek(0, 2)  # Seek to end
    file_size = file.tell()
    file.seek(0)     # Reset to beginning
    
    if file_size > max_size:
        errors.append(f"File size ({file_size / (1024*1024):.1f}MB) exceeds maximum allowed size (50MB)")
    
    if file_size == 0:
        errors.append("File is empty")
    
    return errors