import os
import hashlib
import uuid
from werkzeug.utils import secure_filename
from flask import current_app
import magic
import PyPDF2
from docx import Document as DocxDocument
import markdown

class FileHandler:
    """Handle file operations for document conversion"""
    
    def __init__(self, upload_folder):
        self.upload_folder = upload_folder
        self.allowed_extensions = {'pdf', 'docx', 'txt', 'md', 'pptx'}
        self.max_file_size = 50 * 1024 * 1024  # 50MB
        
        # Create directories if they don't exist
        self._ensure_directories()
    
    def _ensure_directories(self):
        """Ensure upload directories exist"""
        subdirs = ['documents', 'results', 'temp']
        for subdir in subdirs:
            path = os.path.join(self.upload_folder, subdir)
            os.makedirs(path, exist_ok=True)
    
    def validate_file(self, file):
        """Validate uploaded file"""
        if not file or file.filename == '':
            return False
        
        # Check file extension
        if not self._allowed_file(file.filename):
            return False
        
        # Check file size
        file.seek(0, os.SEEK_END)
        file_size = file.tell()
        file.seek(0)  # Reset pointer
        
        if file_size > self.max_file_size:
            return False
        
        # Validate MIME type
        if not self._validate_mime_type(file):
            return False
        
        return True
    
    def _allowed_file(self, filename):
        """Check if file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in self.allowed_extensions
    
    def _validate_mime_type(self, file):
        """Validate MIME type matches file extension"""
        file.seek(0)
        file_content = file.read(1024)  # Read first 1KB
        file.seek(0)  # Reset pointer
        
        try:
            mime_type = magic.from_buffer(file_content, mime=True)
            
            allowed_mime_types = {
                'pdf': ['application/pdf'],
                'docx': [
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'application/zip'  # DOCX files are ZIP archives
                ],
                'txt': ['text/plain'],
                'md': ['text/plain', 'text/markdown'],
                'pptx': [
                    'application/vnd.openxmlformats-officedocument.presentationml.presentation',
                    'application/zip'
                ]
            }
            
            file_ext = file.filename.rsplit('.', 1)[1].lower()
            return mime_type in allowed_mime_types.get(file_ext, [])
            
        except Exception as e:
            current_app.logger.warning(f"MIME type validation failed: {str(e)}")
            return True  # Allow if validation fails
    
    def save_file(self, file):
        """Save uploaded file and return filename"""
        if not self.validate_file(file):
            raise ValueError("Invalid file")
        
        # Generate unique filename
        original_filename = secure_filename(file.filename)
        name, ext = os.path.splitext(original_filename)
        unique_filename = f"{name}_{uuid.uuid4().hex[:8]}{ext}"
        
        # Save file
        file_path = os.path.join(self.upload_folder, 'documents', unique_filename)
        file.save(file_path)
        
        current_app.logger.info(f"File saved: {unique_filename}")
        return unique_filename
    
    def get_file_size(self, file):
        """Get file size in bytes"""
        file.seek(0, os.SEEK_END)
        size = file.tell()
        file.seek(0)
        return size
    
    def calculate_checksum(self, file):
        """Calculate SHA-256 checksum of file"""
        file.seek(0)
        hash_sha256 = hashlib.sha256()
        
        for chunk in iter(lambda: file.read(4096), b""):
            hash_sha256.update(chunk)
        
        file.seek(0)
        return hash_sha256.hexdigest()
    
    def extract_text_content(self, file_path):
        """Extract text content from various file types"""
        file_ext = os.path.splitext(file_path)[1].lower()
        
        try:
            if file_ext == '.pdf':
                return self._extract_pdf_text(file_path)
            elif file_ext == '.docx':
                return self._extract_docx_text(file_path)
            elif file_ext in ['.txt', '.md']:
                return self._extract_text_file(file_path)
            else:
                raise ValueError(f"Unsupported file type: {file_ext}")
                
        except Exception as e:
            current_app.logger.error(f"Text extraction failed for {file_path}: {str(e)}")
            raise
    
    def _extract_pdf_text(self, file_path):
        """Extract text from PDF file"""
        text_content = []
        
        with open(file_path, 'rb') as file:
            pdf_reader = PyPDF2.PdfReader(file)
            
            for page_num, page in enumerate(pdf_reader.pages):
                try:
                    page_text = page.extract_text()
                    if page_text.strip():
                        text_content.append(f"--- Page {page_num + 1} ---\n{page_text}\n")
                except Exception as e:
                    current_app.logger.warning(f"Failed to extract text from PDF page {page_num + 1}: {str(e)}")
        
        return '\n'.join(text_content)
    
    def _extract_docx_text(self, file_path):
        """Extract text from DOCX file"""
        try:
            doc = DocxDocument(file_path)
            text_content = []
            
            for paragraph in doc.paragraphs:
                if paragraph.text.strip():
                    text_content.append(paragraph.text)
            
            # Extract text from tables
            for table in doc.tables:
                for row in table.rows:
                    row_text = []
                    for cell in row.cells:
                        if cell.text.strip():
                            row_text.append(cell.text.strip())
                    if row_text:
                        text_content.append(' | '.join(row_text))
            
            return '\n\n'.join(text_content)
            
        except Exception as e:
            current_app.logger.error(f"DOCX text extraction failed: {str(e)}")
            raise
    
    def _extract_text_file(self, file_path):
        """Extract text from plain text or markdown file"""
        encodings = ['utf-8', 'utf-16', 'latin-1', 'cp1252']
        
        for encoding in encodings:
            try:
                with open(file_path, 'r', encoding=encoding) as file:
                    return file.read()
            except UnicodeDecodeError:
                continue
        
        raise ValueError("Could not decode text file with any supported encoding")
    
    def save_conversion_result(self, content, original_filename, output_format):
        """Save conversion result and return file path"""
        # Generate result filename
        name = os.path.splitext(original_filename)[0]
        result_filename = f"{name}_converted_{uuid.uuid4().hex[:8]}.{output_format}"
        result_path = os.path.join(self.upload_folder, 'results', result_filename)
        
        try:
            if output_format == 'markdown' or output_format == 'md':
                with open(result_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            elif output_format == 'html':
                html_content = markdown.markdown(content, extensions=['tables', 'codehilite'])
                with open(result_path, 'w', encoding='utf-8') as f:
                    f.write(self._wrap_html(html_content, original_filename))
            elif output_format == 'txt':
                with open(result_path, 'w', encoding='utf-8') as f:
                    f.write(content)
            else:
                raise ValueError(f"Unsupported output format: {output_format}")
            
            current_app.logger.info(f"Conversion result saved: {result_filename}")
            return result_path
            
        except Exception as e:
            current_app.logger.error(f"Failed to save conversion result: {str(e)}")
            raise
    
    def _wrap_html(self, content, title):
        """Wrap content in HTML template"""
        return f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Converted: {title}</title>
    <style>
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            line-height: 1.6;
            max-width: 800px;
            margin: 0 auto;
            padding: 2rem;
            color: #333;
        }}
        pre {{
            background: #f4f4f4;
            padding: 1rem;
            border-radius: 4px;
            overflow-x: auto;
        }}
        code {{
            background: #f4f4f4;
            padding: 0.2rem 0.4rem;
            border-radius: 3px;
            font-family: 'Monaco', 'Menlo', 'Ubuntu Mono', monospace;
        }}
        table {{
            border-collapse: collapse;
            width: 100%;
            margin: 1rem 0;
        }}
        th, td {{
            border: 1px solid #ddd;
            padding: 0.75rem;
            text-align: left;
        }}
        th {{
            background-color: #f8f9fa;
        }}
        h1, h2, h3, h4, h5, h6 {{
            color: #2c3e50;
            margin-top: 2rem;
        }}
        .conversion-info {{
            background: #e3f2fd;
            padding: 1rem;
            border-radius: 4px;
            margin-bottom: 2rem;
            border-left: 4px solid #2196f3;
        }}
    </style>
</head>
<body>
    <div class="conversion-info">
        <strong>Document Conversion Result</strong><br>
        Original file: {title}<br>
        Converted on: {os.path.basename(os.path.dirname(__file__)).replace('_', ' ').title()}
    </div>
    {content}
</body>
</html>
        """
    
    def delete_file(self, file_path):
        """Delete file safely"""
        try:
            if os.path.exists(file_path):
                os.remove(file_path)
                current_app.logger.info(f"File deleted: {file_path}")
                return True
            return False
        except Exception as e:
            current_app.logger.error(f"Failed to delete file {file_path}: {str(e)}")
            return False
    
    def cleanup_temp_files(self, older_than_hours=24):
        """Clean up temporary files older than specified hours"""
        temp_dir = os.path.join(self.upload_folder, 'temp')
        current_time = time.time()
        cutoff_time = current_time - (older_than_hours * 3600)
        
        cleaned_files = 0
        
        try:
            for filename in os.listdir(temp_dir):
                file_path = os.path.join(temp_dir, filename)
                
                if os.path.isfile(file_path):
                    file_mtime = os.path.getmtime(file_path)
                    
                    if file_mtime < cutoff_time:
                        os.remove(file_path)
                        cleaned_files += 1
            
            current_app.logger.info(f"Cleaned up {cleaned_files} temporary files")
            return cleaned_files
            
        except Exception as e:
            current_app.logger.error(f"Temp file cleanup failed: {str(e)}")
            return 0
    
    def get_file_info(self, file_path):
        """Get detailed file information"""
        if not os.path.exists(file_path):
            return None
        
        stat = os.stat(file_path)
        
        return {
            'size_bytes': stat.st_size,
            'size_mb': round(stat.st_size / (1024 * 1024), 2),
            'created_at': datetime.fromtimestamp(stat.st_ctime),
            'modified_at': datetime.fromtimestamp(stat.st_mtime),
            'extension': os.path.splitext(file_path)[1].lower(),
            'filename': os.path.basename(file_path)
        }