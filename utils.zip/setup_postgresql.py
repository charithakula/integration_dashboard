#!/usr/bin/env python3
"""
PostgreSQL setup script for DocConverter Pro
This script helps set up the PostgreSQL database and test connections
"""

import os
import sys
import subprocess
import psycopg2
from urllib.parse import urlparse
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

def check_postgresql_installed():
    """Check if PostgreSQL is installed and accessible"""
    try:
        result = subprocess.run(['psql', '--version'], capture_output=True, text=True)
        if result.returncode == 0:
            print(f"✓ PostgreSQL client found: {result.stdout.strip()}")
            return True
        else:
            print("❌ PostgreSQL client not found")
            return False
    except FileNotFoundError:
        print("❌ PostgreSQL client not found in PATH")
        return False

def test_connection(host, port, user, password, database=None):
    """Test PostgreSQL connection"""
    try:
        # Test connection to PostgreSQL server (without specific database)
        conn_params = {
            'host': host,
            'port': port,
            'user': user,
            'password': password
        }
        
        if database:
            conn_params['database'] = database
        else:
            conn_params['database'] = 'postgres'  # Default system database
        
        conn = psycopg2.connect(**conn_params)
        cursor = conn.cursor()
        cursor.execute('SELECT version();')
        version = cursor.fetchone()[0]
        cursor.close()
        conn.close()
        
        db_info = f" to database '{database}'" if database else ""
        print(f"✓ Successfully connected to PostgreSQL{db_info}")
        print(f"  Server version: {version.split()[1]}")
        return True
        
    except psycopg2.Error as e:
        print(f"❌ PostgreSQL connection failed: {e}")
        return False

def create_database(host, port, user, password, database):
    """Create database if it doesn't exist"""
    try:
        # Connect to PostgreSQL server (default postgres database)
        conn = psycopg2.connect(
            host=host,
            port=port,
            user=user,
            password=password,
            database='postgres'
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        # Check if database exists
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (database,))
        exists = cursor.fetchone()
        
        if not exists:
            cursor.execute(f'CREATE DATABASE "{database}"')
            print(f"✓ Created database: {database}")
        else:
            print(f"✓ Database already exists: {database}")
        
        cursor.close()
        conn.close()
        return True
        
    except psycopg2.Error as e:
        print(f"❌ Failed to create database: {e}")
        return False

def get_db_config():
    """Get database configuration from environment or prompt user"""
    # Try to get from environment first
    if os.environ.get('DATABASE_URL'):
        parsed = urlparse(os.environ['DATABASE_URL'])
        return {
            'host': parsed.hostname or 'localhost',
            'port': parsed.port or 5432,
            'user': parsed.username or 'postgres',
            'password': parsed.password or '',
            'database': parsed.path[1:] if parsed.path else 'doc_converter'
        }
    
    # Get individual parameters
    config = {
        'host': os.environ.get('DB_HOST', 'localhost'),
        'port': int(os.environ.get('DB_PORT', 5432)),
        'user': os.environ.get('DB_USER', 'postgres'),
        'password': os.environ.get('DB_PASSWORD', ''),
        'database': os.environ.get('DB_NAME', 'doc_converter')
    }
    
    # Prompt for missing values
    if not config['password']:
        import getpass
        config['password'] = getpass.getpass(f"Enter password for PostgreSQL user '{config['user']}': ")
    
    return config

def setup_database():
    """Main database setup function"""
    print("=" * 60)
    print("DocConverter Pro - PostgreSQL Setup")
    print("=" * 60)
    
    # Step 1: Check PostgreSQL installation
    if not check_postgresql_installed():
        print("\n❌ PostgreSQL not found. Please install PostgreSQL:")
        print("  Windows: Download from https://www.postgresql.org/download/windows/")
        print("  macOS: brew install postgresql")
        print("  Ubuntu: sudo apt-get install postgresql postgresql-contrib")
        return False
    
    # Step 2: Get database configuration
    print("\nGetting database configuration...")
    config = get_db_config()
    
    print(f"Database config:")
    print(f"  Host: {config['host']}")
    print(f"  Port: {config['port']}")
    print(f"  User: {config['user']}")
    print(f"  Database: {config['database']}")
    
    # Step 3: Test connection to PostgreSQL server
    print(f"\nTesting connection to PostgreSQL server...")
    if not test_connection(config['host'], config['port'], config['user'], config['password']):
        print("\n❌ Cannot connect to PostgreSQL server. Please check:")
        print("  1. PostgreSQL server is running")
        print("  2. Host and port are correct")
        print("  3. Username and password are correct")
        print("  4. User has necessary permissions")
        return False
    
    # Step 4: Create database
    print(f"\nCreating database '{config['database']}'...")
    if not create_database(config['host'], config['port'], config['user'], config['password'], config['database']):
        return False
    
    # Step 5: Test connection to the application database
    print(f"\nTesting connection to application database...")
    if not test_connection(config['host'], config['port'], config['user'], config['password'], config['database']):
        return False
    
    # Step 6: Generate connection string
    db_url = f"postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}"
    
    print(f"\n✓ Database setup completed successfully!")
    print(f"\nDatabase URL: postgresql://{config['user']}:***@{config['host']}:{config['port']}/{config['database']}")
    print(f"\nAdd this to your .env file:")
    print(f"DATABASE_URL={db_url}")
    
    return True

def create_env_file():
    """Create .env file with database configuration"""
    config = get_db_config()
    
    env_content = f"""# Flask Configuration
SECRET_KEY=your-secret-key-here-change-in-production
FLASK_ENV=development
FLASK_DEBUG=1

# PostgreSQL Database Configuration
DB_HOST={config['host']}
DB_PORT={config['port']}
DB_NAME={config['database']}
DB_USER={config['user']}
DB_PASSWORD={config['password']}

# Or use complete database URL:
DATABASE_URL=postgresql://{config['user']}:{config['password']}@{config['host']}:{config['port']}/{config['database']}

# Azure OpenAI Configuration (Optional)
AZURE_OPENAI_ENDPOINT=
AZURE_OPENAI_KEY=
AZURE_OPENAI_MODEL=gpt-4

# Application Settings
ADMIN_EMAIL=admin@docconverter.com
ADMIN_PASSWORD=admin123

# File Storage
UPLOAD_FOLDER=uploads
"""
    
    with open('.env', 'w') as f:
        f.write(env_content)
    
    print("✓ Created .env file with database configuration")

def test_flask_app():
    """Test Flask application with PostgreSQL"""
    try:
        print("\nTesting Flask application with PostgreSQL...")
        
        # Try to import and create the app
        from app import create_app
        app = create_app()
        
        with app.app_context():
            from database import check_db_connection, init_db
            
            if check_db_connection():
                print("✓ Flask can connect to PostgreSQL")
                
                if init_db():
                    print("✓ Database tables created successfully")
                    return True
                else:
                    print("❌ Failed to create database tables")
                    return False
            else:
                print("❌ Flask cannot connect to PostgreSQL")
                return False
                
    except Exception as e:
        print(f"❌ Flask application test failed: {e}")
        return False

def main():
    """Main setup function"""
    print("Welcome to DocConverter Pro PostgreSQL Setup!\n")
    
    # Check if .env file exists
    if not os.path.exists('.env'):
        print("No .env file found. Let's create one...")
        try:
            create_env_file()
        except Exception as e:
            print(f"Failed to create .env file: {e}")
    
    # Setup database
    if setup_database():
        print("\nDatabase setup completed! Next steps:")
        print("1. Update your .env file with the database URL shown above")
        print("2. Install Python dependencies: pip install -r requirements.txt")
        print("3. Run the application: python app.py")
        
        # Test Flask app if possible
        try:
            test_flask_app()
        except ImportError:
            print("\nTo test the Flask application:")
            print("1. Install requirements: pip install -r requirements.txt")
            print("2. Run: python -c 'from app import create_app; app = create_app()'")
            
    else:
        print("\n❌ Database setup failed. Please check the errors above.")

if __name__ == '__main__':
    main()