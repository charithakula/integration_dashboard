"""
PostgreSQL Database Connection Module
Handles PostgreSQL database connections for DocConverter Pro
"""

import os
import logging
from contextlib import contextmanager
from dotenv import load_dotenv

try:
    import psycopg2
    import psycopg2.pool
    PSYCOPG2_AVAILABLE = True
except ImportError:
    print("psycopg2 not found. Install with: pip install psycopg2-binary")
    psycopg2 = None
    PSYCOPG2_AVAILABLE = False

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class PostgreSQLConnection:
    """PostgreSQL database connection manager."""
    
    def __init__(self):
        self.config = {
            'host': os.getenv('DB_HOST', 'localhost'),
            'port': int(os.getenv('DB_PORT', '5434')),
            'database': os.getenv('DB_NAME', 'doc_converter'),
            'user': os.getenv('DB_USER', 'docconverter_app'),
            'password': os.getenv('DB_PASSWORD', 'DocConverter2024!')
        }
        self.connection_pool = None
        self.is_available = PSYCOPG2_AVAILABLE
        
        if self.is_available:
            self._initialize_pool()
        else:
            logger.warning("PostgreSQL connection not available - psycopg2 not installed")
    
    def _initialize_pool(self):
        """Initialize connection pool."""
        if not self.is_available:
            return False
            
        try:
            self.connection_pool = psycopg2.pool.ThreadedConnectionPool(
                minconn=1,
                maxconn=20,
                **self.config
            )
            logger.info("PostgreSQL connection pool initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Failed to initialize PostgreSQL connection pool: {e}")
            self.connection_pool = None
            return False
    
    @contextmanager
    def get_connection(self):
        """Get a database connection from the pool."""
        if not self.is_available or not self.connection_pool:
            raise ConnectionError("PostgreSQL connection not available")
            
        connection = None
        try:
            connection = self.connection_pool.getconn()
            yield connection
        except Exception as e:
            if connection:
                connection.rollback()
            logger.error(f"Database connection error: {e}")
            raise
        finally:
            if connection:
                self.connection_pool.putconn(connection)
    
    def execute_query(self, query, params=None, fetch=False):
        """Execute a database query."""
        if not self.is_available:
            raise ConnectionError("PostgreSQL not available")
            
        with self.get_connection() as conn:
            with conn.cursor() as cursor:
                cursor.execute(query, params)
                if fetch:
                    return cursor.fetchall()
                conn.commit()
                return cursor.rowcount
    
    def check_connection(self):
        """Check if database connection is working."""
        if not self.is_available:
            return False
            
        try:
            with self.get_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("SELECT 1")
                    return True
        except Exception as e:
            logger.error(f"Database connection check failed: {e}")
            return False
    
    def close_all_connections(self):
        """Close all connections in the pool."""
        if self.connection_pool:
            self.connection_pool.closeall()
            logger.info("All PostgreSQL connections closed")

# Create global connection instance
postgresql_connection = PostgreSQLConnection()