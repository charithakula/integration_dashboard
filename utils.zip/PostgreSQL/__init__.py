"""
PostgreSQL Package
Database connection and utilities for DocConverter Pro
"""

from .connection import postgresql_connection, PostgreSQLConnection

__all__ = ['postgresql_connection', 'PostgreSQLConnection']

# Package metadata
__version__ = '1.0.0'
__author__ = 'DocConverter Pro Team'
__description__ = 'PostgreSQL database connection module for DocConverter Pro'