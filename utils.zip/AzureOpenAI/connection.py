"""
Azure OpenAI Connection Module
Handles Azure OpenAI API connections for DocConverter Pro
"""

import os
import json
import time
import logging
from datetime import datetime
from typing import Dict, List, Optional, Union
from dotenv import load_dotenv

try:
    from openai import AzureOpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    print("OpenAI library not found. Install with: pip install openai")
    AzureOpenAI = None
    OPENAI_AVAILABLE = False

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)

class AzureOpenAIConnection:
    """Azure OpenAI API connection manager with comprehensive error handling."""
    
    def __init__(self):
        """Initialize Azure OpenAI connection with configuration validation."""
        
        # Load configuration from environment
        self.endpoint = os.getenv('AZURE_OPENAI_ENDPOINT')
        self.api_key = os.getenv('AZURE_OPENAI_API_KEY') or os.getenv('AZURE_OPENAI_KEY')
        self.deployment = os.getenv('AZURE_OPENAI_DEPLOYMENT', 'gpt-4')
        self.api_version = os.getenv('AZURE_OPENAI_VERSION', '2024-02-15-preview')
        
        # Initialize connection state
        self.client = None
        self.is_connected = False
        
        # Validate and initialize if configuration is available
        if self._has_configuration():
            try:
                self._validate_configuration()
                self._initialize_client()
            except Exception as e:
                logger.error(f"Failed to initialize Azure OpenAI: {e}")
        else:
            logger.warning("Azure OpenAI configuration incomplete - connection disabled")
        
        # Configuration for different conversion types
        self.conversion_configs = {
            'comprehensive': {
                'max_tokens': 6000,
                'temperature': 0.3,
                'include_examples': True,
                'include_migration_steps': True
            },
            'detailed': {
                'max_tokens': 5000,
                'temperature': 0.2,
                'include_examples': True,
                'include_migration_steps': False
            },
            'overview': {
                'max_tokens': 3000,
                'temperature': 0.1,
                'include_examples': False,
                'include_migration_steps': False
            },
            'architecture': {
                'max_tokens': 4500,
                'temperature': 0.2,
                'include_examples': True,
                'include_migration_steps': False
            },
            'migration': {
                'max_tokens': 6000,
                'temperature': 0.1,
                'include_examples': True,
                'include_migration_steps': True
            }
        }
    
    def _has_configuration(self) -> bool:
        """Check if minimum configuration is available."""
        return bool(self.endpoint and self.api_key)
    
    def _validate_configuration(self):
        """Validate Azure OpenAI configuration."""
        if not OPENAI_AVAILABLE:
            raise ImportError("OpenAI library not available. Install with: pip install openai")
            
        missing_configs = []
        
        if not self.endpoint:
            missing_configs.append('AZURE_OPENAI_ENDPOINT')
        if not self.api_key:
            missing_configs.append('AZURE_OPENAI_API_KEY or AZURE_OPENAI_KEY')
        
        if missing_configs:
            error_msg = f"Missing required Azure OpenAI configuration: {', '.join(missing_configs)}"
            raise ValueError(error_msg)
        
        # Validate endpoint format
        if not self.endpoint.startswith('https://'):
            raise ValueError("Azure OpenAI endpoint must start with 'https://'")
        
        logger.info("Azure OpenAI configuration validated successfully")
    
    def _initialize_client(self):
        """Initialize the Azure OpenAI client."""
        try:
            self.client = AzureOpenAI(
                azure_endpoint=self.endpoint,
                api_key=self.api_key,
                api_version=self.api_version
            )
            
            # Test connection
            if self.check_connection():
                self.is_connected = True
                logger.info("Azure OpenAI connection initialized successfully")
            else:
                logger.warning("Azure OpenAI client created but connection test failed")
                
        except Exception as e:
            logger.error(f"Failed to initialize Azure OpenAI client: {e}")
            self.client = None
            self.is_connected = False
    
    def check_connection(self) -> bool:
        """Check if Azure OpenAI connection is working."""
        if not self.client:
            logger.warning("Azure OpenAI client not initialized")
            return False
        
        try:
            # Basic parameters for connection test
            api_params = {
                "model": self.deployment,
                "messages": [{"role": "user", "content": "Hello"}],
                "max_tokens": 5
            }
            
            # Try different parameter combinations for compatibility
            try:
                response = self.client.chat.completions.create(**api_params)
            except Exception as e:
                if "max_tokens" in str(e) or "unsupported_parameter" in str(e):
                    # Try with max_completion_tokens
                    api_params["max_completion_tokens"] = api_params.pop("max_tokens")
                    response = self.client.chat.completions.create(**api_params)
                else:
                    raise e
            
            if response and response.choices:
                logger.info("Azure OpenAI connection check successful")
                return True
            else:
                logger.warning("Azure OpenAI connection check failed - no response")
                return False
                
        except Exception as e:
            logger.error(f"Azure OpenAI connection check failed: {e}")
            return False

    def generate_completion(
        self, 
        messages: List[Dict[str, str]], 
        max_tokens: int = 4000,
        temperature: float = 0.3,
        timeout: int = 120,
        **kwargs
    ) -> Dict:
        """Generate chat completion using Azure OpenAI with parameter compatibility."""
        
        if not self.client:
            raise ConnectionError("Azure OpenAI client not initialized")
        
        if not self.is_connected and not self.check_connection():
            raise ConnectionError("Azure OpenAI connection not available")
        
        try:
            logger.info(f"Generating completion with {len(messages)} messages, max_tokens: {max_tokens}")
            
            start_time = time.time()
            
            # Prepare API parameters
            api_params = {
                "model": self.deployment,
                "messages": messages,
                "timeout": timeout,
                **kwargs
            }
            
            # Handle temperature parameter (some models don't support it)
            if temperature is not None:
                api_params["temperature"] = temperature
            
            # Try different token parameter names for compatibility
            success = False
            for token_param in ["max_tokens", "max_completion_tokens"]:
                try:
                    api_params[token_param] = max_tokens
                    # Remove other token parameters to avoid conflicts
                    for other_param in ["max_tokens", "max_completion_tokens"]:
                        if other_param != token_param and other_param in api_params:
                            del api_params[other_param]
                    
                    response = self.client.chat.completions.create(**api_params)
                    success = True
                    break
                    
                except Exception as e:
                    if token_param in str(e) or "unsupported_parameter" in str(e):
                        continue  # Try next parameter name
                    else:
                        # Different error, try without temperature
                        if "temperature" in api_params:
                            del api_params["temperature"]
                            try:
                                response = self.client.chat.completions.create(**api_params)
                                success = True
                                break
                            except:
                                continue
                        else:
                            raise e
            
            if not success:
                raise ValueError("Unable to create completion with available parameters")
            
            processing_time = time.time() - start_time
            
            if not response or not response.choices:
                raise ValueError("No response generated from Azure OpenAI")
            
            # Get the actual response content
            response_content = response.choices[0].message.content or ""
            
            result = {
                'content': response_content,
                'tokens_used': response.usage.total_tokens if response.usage else 0,
                'prompt_tokens': response.usage.prompt_tokens if response.usage else 0,
                'completion_tokens': response.usage.completion_tokens if response.usage else 0,
                'model': response.model,
                'finish_reason': response.choices[0].finish_reason,
                'processing_time': processing_time,
                'timestamp': datetime.utcnow().isoformat()
            }
            
            logger.info(f"Completion generated successfully in {processing_time:.2f}s")
            logger.info(f"Response length: {len(response_content)} characters")
            logger.info(f"Tokens: {result['tokens_used']} (prompt: {result['prompt_tokens']}, completion: {result['completion_tokens']})")
            logger.info(f"Finish reason: {result['finish_reason']}")
            
            return result
            
        except Exception as e:
            logger.error(f"Azure OpenAI completion error: {e}")
            raise
    
    def generate_document_conversion(
        self,
        source_content: str,
        source_technology: str,
        target_technology: str,
        conversion_depth: str = "comprehensive",
        output_format: str = "markdown",
        additional_instructions: Optional[str] = None,
        custom_config: Optional[Dict] = None
    ) -> Dict:
        """Generate document conversion using Azure OpenAI with optimized prompts."""
        
        # Get configuration for conversion depth
        config = self.conversion_configs.get(conversion_depth, self.conversion_configs['comprehensive'])
        
        # Override with custom config if provided
        if custom_config:
            config.update(custom_config)
        
        # Generate optimized prompts
        system_prompt = self._create_conversion_system_prompt(
            source_technology, 
            target_technology, 
            conversion_depth,
            output_format,
            config
        )
        
        user_prompt = self._create_conversion_user_prompt(
            source_content,
            source_technology,
            target_technology,
            additional_instructions
        )
        
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ]
        
        try:
            result = self.generate_completion(
                messages=messages,
                max_tokens=config.get('max_tokens', 4000),
                temperature=config.get('temperature', 0.3)
            )
            
            # Check if the response is too short and retry if needed
            if len(result['content']) < 800:
                logger.warning(f"AI response too short ({len(result['content'])} chars), retrying with simplified prompt")
                
                # Retry with a much shorter, more direct prompt
                retry_messages = [
                    {"role": "system", "content": f"You are a {source_technology} to {target_technology} migration expert. Provide detailed, comprehensive responses with at least 1500 words."},
                    {"role": "user", "content": f"Create a complete {target_technology} implementation guide based on this {source_technology} content:\n\n{source_content[:1000]}\n\nProvide full technical details, code examples, and implementation steps:"}
                ]
                
                result = self.generate_completion(
                    messages=retry_messages,
                    max_tokens=config.get('max_tokens', 4000),
                    temperature=0.2  # Lower temperature for more focused response
                )
            
            # Post-process the conversion result
            result['content'] = self._post_process_conversion(
                result['content'],
                source_technology,
                target_technology,
                output_format
            )
            
            # Add conversion metadata
            result['conversion_metadata'] = {
                'source_technology': source_technology,
                'target_technology': target_technology,
                'conversion_depth': conversion_depth,
                'output_format': output_format,
                'config_used': config,
                'content_length': len(result['content'])
            }
            
            logger.info(f"Document conversion completed: {len(result['content'])} characters generated")
            return result
            
        except Exception as e:
            logger.error(f"Document conversion failed: {e}")
            raise
    
    def _create_conversion_system_prompt(
        self,
        source_tech: str,
        target_tech: str,
        depth: str,
        output_format: str,
        config: Dict
    ) -> str:
        """Create optimized system prompt for document conversion."""

        base_prompt = f"""You are a senior technical architect specializing in {source_tech} to {target_tech} migrations.

Your task: Convert the provided {source_tech} documentation to a complete {target_tech} implementation guide.

Required sections:
- Executive Summary
- Architecture Overview  
- Technology Mapping ({source_tech} → {target_tech})
- Implementation Guide
- Code Examples and Configurations
- Migration Steps and Timeline
- Testing and Validation Strategy
- Potential Challenges and Solutions

Output format: {output_format}
Minimum length: 1500 words of technical content
Focus: Practical, actionable guidance with working examples"""

        # Depth-specific instructions
        if depth == "comprehensive":
            base_prompt += "\n\nDETAIL LEVEL: Include full code examples, detailed setup procedures, testing strategies, and migration best practices."
        elif depth == "detailed":
            base_prompt += "\n\nDETAIL LEVEL: Include key code examples and detailed implementation steps for core functionality."
        elif depth == "overview":
            base_prompt += "\n\nDETAIL LEVEL: Focus on high-level architecture, key mappings, and strategic migration approach."
        else:
            base_prompt += "\n\nDETAIL LEVEL: Comprehensive coverage with practical implementation details."

        return base_prompt

    def _create_conversion_user_prompt(
        self,
        content: str,
        source_tech: str,
        target_tech: str,
        additional_instructions: Optional[str] = None
    ) -> str:
        """Create optimized user prompt for document conversion."""
        
        # Truncate content to preserve tokens for response - more aggressive truncation
        max_content_length = 1200
        if len(content) > max_content_length:
            content = content[:max_content_length] + "\n\n[Content truncated for processing...]"
        
        # Short, direct prompt to maximize response tokens
        prompt = f"""Convert this {source_tech} documentation to {target_tech}:

{content}

Generate a comprehensive migration report including:
1. Executive summary
2. Complete technology mapping
3. Detailed implementation guide with code examples
4. Step-by-step migration process
5. Testing and validation approach
6. Timeline and resource planning

Provide at least 1500 words of detailed technical content. Begin the complete conversion now:"""
        
        if additional_instructions:
            prompt += f"\n\nAdditional requirements: {additional_instructions[:150]}"
        
        return prompt
    
    def _post_process_conversion(
        self,
        content: str,
        source_tech: str,
        target_tech: str,
        output_format: str
    ) -> str:
        """Post-process the AI-generated conversion content."""
        
        # Add conversion header if not already present
        if not content.startswith('---') and not content.startswith('#'):
            header = f"""---
# Document Conversion Report
**Original Technology:** {source_tech}  
**Target Technology:** {target_tech}  
**Conversion Date:** {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} UTC  
**Generated by:** DocConverter Pro - Azure OpenAI  
---

"""
            content = header + content
        
        # Clean up common AI artifacts
        import re
        
        # Remove stray markdown code block markers
        content = re.sub(r'^```\w*\s*$', '', content, flags=re.MULTILINE)
        
        # Ensure proper code block formatting
        content = re.sub(r'```(\w+)?\n', lambda m: f'```{m.group(1) or "text"}\n', content)
        
        # Fix heading spacing
        content = re.sub(r'\n(#{1,6})', r'\n\n\1', content)
        content = re.sub(r'(#{1,6}[^\n]+)\n([^#\n])', r'\1\n\n\2', content)
        
        # Remove excessive blank lines
        content = re.sub(r'\n{3,}', '\n\n', content)
        
        return content.strip()
    
    def test_api_manually(self, test_prompt: str = None, max_tokens: int = 2000) -> Dict:
        """Test Azure OpenAI API with a custom prompt for manual testing."""
        
        if not test_prompt:
            test_prompt = "Explain the benefits of cloud computing in 3 key points with technical details."
        
        try:
            messages = [
                {"role": "system", "content": "You are a helpful technical assistant. Provide clear, complete, detailed responses."},
                {"role": "user", "content": test_prompt}
            ]
            
            result = self.generate_completion(
                messages=messages,
                max_tokens=max_tokens,
                temperature=0.3
            )
            
            # Log the actual response for debugging
            response_content = result.get('content', '')
            logger.info(f"Test API response length: {len(response_content)} characters")
            logger.info(f"Finish reason: {result.get('finish_reason', 'unknown')}")
            
            return {
                'test_successful': True,
                'prompt': test_prompt,
                'response': response_content,
                'response_length': len(response_content),
                'tokens_used': result.get('tokens_used', 0),
                'prompt_tokens': result.get('prompt_tokens', 0),
                'completion_tokens': result.get('completion_tokens', 0),
                'processing_time': result.get('processing_time', 0),
                'model': result.get('model', self.deployment),
                'finish_reason': result.get('finish_reason', 'unknown'),
                'max_tokens_requested': max_tokens
            }
            
        except Exception as e:
            logger.error(f"Manual API test failed: {e}")
            return {
                'test_successful': False,
                'error': str(e),
                'error_type': type(e).__name__,
                'prompt': test_prompt
            }
    
    def retry_with_backoff(self, func, max_retries: int = 3, base_delay: float = 1.0):
        """Execute function with exponential backoff retry logic."""
        
        for attempt in range(max_retries):
            try:
                return func()
            except Exception as e:
                if attempt == max_retries - 1:
                    logger.error(f"Final retry attempt failed: {e}")
                    raise e
                
                delay = base_delay * (2 ** attempt)
                logger.warning(f"Attempt {attempt + 1} failed, retrying in {delay}s: {e}")
                time.sleep(delay)
    
    def get_model_info(self) -> Dict:
        """Get information about the configured model and connection."""
        return {
            'endpoint': self.endpoint,
            'deployment': self.deployment,
            'api_version': self.api_version,
            'model_name': self.deployment,
            'is_connected': self.is_connected,
            'client_available': self.client is not None,
            'openai_library_available': OPENAI_AVAILABLE,
            'supported_conversions': list(self.conversion_configs.keys()),
            'has_configuration': self._has_configuration()
        }
    
    def get_usage_stats(self) -> Dict:
        """Get basic usage statistics (placeholder for future implementation)."""
        return {
            'total_requests': 0,  # Would be tracked in production
            'total_tokens_used': 0,  # Would be tracked in production
            'average_response_time': 0.0,  # Would be tracked in production
            'last_request_time': None  # Would be tracked in production
        }
    
    def test_conversion(self, test_content: str = None) -> Dict:
        """Test the conversion functionality with sample content."""
        
        if not test_content:
            test_content = """
# PEGA Case Management System

## Overview
This document describes a PEGA-based case management system for processing customer service requests.

## Key Components

### Case Types
- Service Request Cases
- Complaint Cases  
- Billing Inquiry Cases

### Business Rules
- Priority assignment based on customer tier
- SLA calculations for response times
- Escalation rules for overdue cases

### Data Model
- Customer information
- Case details and history
- Resolution tracking

## Implementation
The system uses PEGA's built-in case management framework with custom business rules and data transforms.
"""
        
        try:
            result = self.generate_document_conversion(
                source_content=test_content,
                source_technology="PEGA",
                target_technology="Power Automate",
                conversion_depth="detailed"
            )
            
            return {
                'test_successful': True,
                'tokens_used': result.get('tokens_used', 0),
                'processing_time': result.get('processing_time', 0),
                'content_length': len(result['content']),
                'content_preview': result['content'][:300] + "..." if len(result['content']) > 300 else result['content']
            }
            
        except Exception as e:
            return {
                'test_successful': False,
                'error': str(e),
                'error_type': type(e).__name__
            }

# Create global connection instance - handle initialization errors gracefully
try:
    azure_openai_connection = AzureOpenAIConnection()
    logger.info("Azure OpenAI connection instance created")
except Exception as e:
    logger.error(f"Failed to initialize Azure OpenAI connection: {e}")
    azure_openai_connection = None

# Module-level functions for backward compatibility
def check_connection() -> bool:
    """Check Azure OpenAI connection status."""
    return azure_openai_connection.check_connection() if azure_openai_connection else False

def generate_conversion(**kwargs) -> Dict:
    """Generate document conversion."""
    if not azure_openai_connection:
        raise ImportError("Azure OpenAI connection not available")
    return azure_openai_connection.generate_document_conversion(**kwargs)

def get_model_info() -> Dict:
    """Get model information."""
    if not azure_openai_connection:
        return {
            'error': 'Azure OpenAI connection not available',
            'openai_library_available': OPENAI_AVAILABLE,
            'has_configuration': False
        }
    return azure_openai_connection.get_model_info()

# Export the connection instance
__all__ = ['AzureOpenAIConnection', 'azure_openai_connection', 'check_connection', 'generate_conversion', 'get_model_info']