"""
AzureOpenAI Package
Azure OpenAI connection and utilities for DocConverter Pro
"""

from .connection import azure_openai_connection, AzureOpenAIConnection

__all__ = ['azure_openai_connection', 'AzureOpenAIConnection']

# Package metadata
__version__ = '1.0.0'
__author__ = 'DocConverter Pro Team'
__description__ = 'Azure OpenAI connection module for DocConverter Pro'