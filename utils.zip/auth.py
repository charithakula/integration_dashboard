from flask import Blueprint, request, jsonify, session, current_app
from werkzeug.security import check_password_hash
from functools import wraps
from datetime import datetime, timedelta
import jwt
from models import User, UserRole, AuditLog, db
from utils.validators import validate_email, validate_password
from utils.logger import log_activity

auth_bp = Blueprint('auth', __name__)

def login_required(f):
    """Decorator to require login"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'user_id' not in session:
            return jsonify({'error': 'Authentication required'}), 401
        
        # Check if user is still active
        user = User.query.get(session['user_id'])
        if not user or not user.is_active:
            session.clear()
            return jsonify({'error': 'User account inactive'}), 401
        
        # Update last activity
        session['last_activity'] = datetime.utcnow().isoformat()
        
        return f(*args, **kwargs)
    return decorated_function

def role_required(required_role):
    """Decorator to require specific role"""
    def decorator(f):
        @wraps(f)
        def decorated_function(*args, **kwargs):
            if 'user_id' not in session:
                return jsonify({'error': 'Authentication required'}), 401
            
            user = User.query.get(session['user_id'])
            if not user:
                return jsonify({'error': 'User not found'}), 401
            
            # Check role hierarchy (admin > editor > viewer)
            role_hierarchy = {
                UserRole.ADMIN: 3,
                UserRole.EDITOR: 2,
                UserRole.VIEWER: 1
            }
            
            user_level = role_hierarchy.get(user.role, 0)
            required_level = role_hierarchy.get(required_role, 0)
            
            if user_level < required_level:
                return jsonify({'error': 'Insufficient permissions'}), 403
            
            return f(*args, **kwargs)
        return decorated_function
    return decorator

@auth_bp.route('/login', methods=['POST'])
def login():
    """User login endpoint"""
    data = request.get_json()
    
    if not data or not data.get('email') or not data.get('password'):
        return jsonify({'error': 'Email and password required'}), 400
    
    email = data['email'].lower().strip()
    password = data['password']
    
    # Validate email format
    if not validate_email(email):
        return jsonify({'error': 'Invalid email format'}), 400
    
    # Find user
    user = User.query.filter_by(email=email).first()
    
    if not user or not user.check_password(password):
        # Log failed login attempt
        log_activity(
            action='login_failed',
            details={'email': email, 'reason': 'invalid_credentials'},
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        return jsonify({'error': 'Invalid email or password'}), 401
    
    if not user.is_active:
        log_activity(
            user_id=user.id,
            action='login_failed',
            details={'reason': 'account_inactive'},
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        return jsonify({'error': 'Account is inactive'}), 401
    
    # Create session
    session['user_id'] = user.id
    session['user_email'] = user.email
    session['user_role'] = user.role.value
    session['login_time'] = datetime.utcnow().isoformat()
    session.permanent = True
    
    # Update user's last login
    user.last_login = datetime.utcnow()
    db.session.commit()
    
    # Log successful login
    log_activity(
        user_id=user.id,
        action='login_success',
        details={'login_method': 'email_password'},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    return jsonify({
        'message': 'Login successful',
        'user': user.to_dict()
    })

@auth_bp.route('/logout', methods=['POST'])
@login_required
def logout():
    """User logout endpoint"""
    user_id = session.get('user_id')
    
    # Log logout
    log_activity(
        user_id=user_id,
        action='logout',
        details={'session_duration': get_session_duration()},
        ip_address=request.remote_addr,
        user_agent=request.headers.get('User-Agent')
    )
    
    session.clear()
    
    return jsonify({'message': 'Logout successful'})

@auth_bp.route('/register', methods=['POST'])
def register():
    """User registration endpoint"""
    data = request.get_json()
    
    required_fields = ['email', 'password', 'first_name', 'last_name']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    email = data['email'].lower().strip()
    password = data['password']
    first_name = data['first_name'].strip()
    last_name = data['last_name'].strip()
    
    # Validate email
    if not validate_email(email):
        return jsonify({'error': 'Invalid email format'}), 400
    
    # Validate password
    password_errors = validate_password(password)
    if password_errors:
        return jsonify({'error': 'Password validation failed', 'details': password_errors}), 400
    
    # Check if user already exists
    if User.query.filter_by(email=email).first():
        return jsonify({'error': 'Email already registered'}), 409
    
    try:
        # Create new user
        user = User(
            email=email,
            first_name=first_name,
            last_name=last_name,
            role=UserRole.VIEWER  # Default role
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        # Log registration
        log_activity(
            user_id=user.id,
            action='user_registered',
            details={'registration_method': 'email'},
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        return jsonify({
            'message': 'Registration successful',
            'user': user.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Registration error: {str(e)}")
        return jsonify({'error': 'Registration failed'}), 500

@auth_bp.route('/profile', methods=['GET'])
@login_required
def get_profile():
    """Get current user profile"""
    user = User.query.get(session['user_id'])
    return jsonify(user.to_dict())

@auth_bp.route('/profile', methods=['PUT'])
@login_required
def update_profile():
    """Update current user profile"""
    user = User.query.get(session['user_id'])
    data = request.get_json()
    
    # Fields that can be updated
    updatable_fields = ['first_name', 'last_name']
    updated_fields = []
    
    for field in updatable_fields:
        if field in data and data[field].strip():
            setattr(user, field, data[field].strip())
            updated_fields.append(field)
    
    if updated_fields:
        try:
            db.session.commit()
            
            # Log profile update
            log_activity(
                user_id=user.id,
                action='profile_updated',
                details={'updated_fields': updated_fields},
                ip_address=request.remote_addr,
                user_agent=request.headers.get('User-Agent')
            )
            
            return jsonify({
                'message': 'Profile updated successfully',
                'user': user.to_dict()
            })
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"Profile update error: {str(e)}")
            return jsonify({'error': 'Profile update failed'}), 500
    
    return jsonify({'message': 'No changes made'})

@auth_bp.route('/change-password', methods=['POST'])
@login_required
def change_password():
    """Change user password"""
    data = request.get_json()
    
    if not data.get('current_password') or not data.get('new_password'):
        return jsonify({'error': 'Current password and new password required'}), 400
    
    user = User.query.get(session['user_id'])
    
    # Verify current password
    if not user.check_password(data['current_password']):
        log_activity(
            user_id=user.id,
            action='password_change_failed',
            details={'reason': 'invalid_current_password'},
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        return jsonify({'error': 'Current password is incorrect'}), 401
    
    # Validate new password
    password_errors = validate_password(data['new_password'])
    if password_errors:
        return jsonify({'error': 'New password validation failed', 'details': password_errors}), 400
    
    try:
        # Update password
        user.set_password(data['new_password'])
        db.session.commit()
        
        # Log password change
        log_activity(
            user_id=user.id,
            action='password_changed',
            details={},
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        return jsonify({'message': 'Password changed successfully'})
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Password change error: {str(e)}")
        return jsonify({'error': 'Password change failed'}), 500

@auth_bp.route('/session', methods=['GET'])
def check_session():
    """Check if user session is valid"""
    if 'user_id' not in session:
        return jsonify({'authenticated': False}), 401
    
    user = User.query.get(session['user_id'])
    if not user or not user.is_active:
        session.clear()
        return jsonify({'authenticated': False}), 401
    
    # Check session timeout
    login_time = session.get('login_time')
    if login_time:
        login_datetime = datetime.fromisoformat(login_time)
        session_timeout = timedelta(hours=24)  # 24 hour session
        
        if datetime.utcnow() - login_datetime > session_timeout:
            session.clear()
            return jsonify({'authenticated': False, 'reason': 'session_expired'}), 401
    
    return jsonify({
        'authenticated': True,
        'user': user.to_dict(),
        'session_info': {
            'login_time': session.get('login_time'),
            'last_activity': session.get('last_activity')
        }
    })

@auth_bp.route('/users', methods=['GET'])
@role_required(UserRole.ADMIN)
def list_users():
    """List all users (admin only)"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    
    users = User.query.paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    
    return jsonify({
        'users': [user.to_dict() for user in users.items],
        'total': users.total,
        'pages': users.pages,
        'current_page': page
    })

@auth_bp.route('/users/<int:user_id>/toggle-status', methods=['POST'])
@role_required(UserRole.ADMIN)
def toggle_user_status(user_id):
    """Toggle user active status (admin only)"""
    user = User.query.get(user_id)
    if not user:
        return jsonify({'error': 'User not found'}), 404
    
    # Prevent admin from deactivating themselves
    if user.id == session['user_id']:
        return jsonify({'error': 'Cannot deactivate your own account'}), 400
    
    try:
        user.is_active = not user.is_active
        db.session.commit()
        
        # Log status change
        log_activity(
            user_id=session['user_id'],
            action='user_status_changed',
            details={
                'target_user_id': user.id,
                'new_status': 'active' if user.is_active else 'inactive'
            },
            ip_address=request.remote_addr,
            user_agent=request.headers.get('User-Agent')
        )
        
        return jsonify({
            'message': f"User {'activated' if user.is_active else 'deactivated'} successfully",
            'user': user.to_dict()
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"User status toggle error: {str(e)}")
        return jsonify({'error': 'Status update failed'}), 500

def get_session_duration():
    """Calculate current session duration in seconds"""
    login_time = session.get('login_time')
    if login_time:
        login_datetime = datetime.fromisoformat(login_time)
        return int((datetime.utcnow() - login_datetime).total_seconds())
    return 0

def generate_jwt_token(user_id, expires_in=3600):
    """Generate JWT token for API access"""
    payload = {
        'user_id': user_id,
        'exp': datetime.utcnow() + timedelta(seconds=expires_in),
        'iat': datetime.utcnow()
    }
    
    return jwt.encode(
        payload,
        current_app.config['SECRET_KEY'],
        algorithm='HS256'
    )

def verify_jwt_token(token):
    """Verify JWT token and return user_id"""
    try:
        payload = jwt.decode(
            token,
            current_app.config['SECRET_KEY'],
            algorithms=['HS256']
        )
        return payload['user_id']
    except jwt.ExpiredSignatureError:
        return None
    except jwt.InvalidTokenError:
        return None