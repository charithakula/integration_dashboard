from flask import Blueprint, request, jsonify, current_app, send_file, session
from auth import login_required, role_required
from utils.file_handler import FileHandler
from utils.ai_processor import AIProcessor
from utils.logger import log_activity
from datetime import datetime, timedelta, timezone
from sqlalchemy import func, desc, text
import os
import uuid
import time

# CRITICAL FIX: Import ALL models and db from the SAME models.py file
from models import (
    db, User, Document, Conversion, AuditLog, SystemSetting, 
    UserRole, ConversionStatus
)

api_bp = Blueprint('api', __name__)

# Dashboard & Analytics APIs
@api_bp.route('/dashboard/stats', methods=['GET'])
@login_required
def dashboard_stats():
    """Get dashboard statistics for current user"""
    user_id = request.args.get('user_id') if request.args.get('admin') else None
    
    # If admin view requested, check permissions
    if user_id and user_id != str(session.get('user_id')):
        current_user = User.query.get(session['user_id'])
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Insufficient permissions'}), 403
    else:
        user_id = session.get('user_id')
    
    # Base query filters
    base_filter = {'user_id': user_id} if user_id else {}
    
    # Get conversion statistics
    total_conversions = Conversion.query.filter_by(**base_filter).count()
    completed_conversions = Conversion.query.filter_by(status=ConversionStatus.COMPLETED, **base_filter).count()
    processing_conversions = Conversion.query.filter_by(status=ConversionStatus.PROCESSING, **base_filter).count()
    failed_conversions = Conversion.query.filter_by(status=ConversionStatus.FAILED, **base_filter).count()
    
    # Calculate success rate
    success_rate = (completed_conversions / total_conversions * 100) if total_conversions > 0 else 0
    
    # Get time saved (average 4.2 minutes per conversion)
    time_saved_minutes = completed_conversions * 4.2
    time_saved_hours = time_saved_minutes / 60
    
    # Get recent activity
    recent_conversions = Conversion.query.filter_by(**base_filter)\
        .order_by(desc(Conversion.created_at))\
        .limit(5)\
        .all()
    
    # Active users (last 24 hours)
    yesterday = datetime.utcnow() - timedelta(hours=24)
    active_users = User.query.filter(User.last_login >= yesterday, User.is_active == True).count()
    
    return jsonify({
        'stats': {
            'documents_processed': total_conversions,
            'success_rate': round(success_rate, 1),
            'active_users': active_users,
            'time_saved_hours': round(time_saved_hours, 1),
            'processing_jobs': processing_conversions,
            'failed_jobs': failed_conversions
        },
        'recent_conversions': [conv.to_dict() for conv in recent_conversions]
    })

@api_bp.route('/analytics/overview', methods=['GET'])
@login_required
def analytics_overview():
    """Get analytics overview data"""
    user_id = session.get('user_id')
    days = request.args.get('days', 30, type=int)
    
    # Date range
    end_date = datetime.utcnow()
    start_date = end_date - timedelta(days=days)
    
    # Conversion trends by day
    daily_stats = db.session.query(
        func.date(Conversion.created_at).label('date'),
        func.count(Conversion.id).label('count'),
        func.avg(Conversion.processing_time).label('avg_time')
    ).filter(
        Conversion.user_id == user_id,
        Conversion.created_at >= start_date
    ).group_by(func.date(Conversion.created_at)).all()
    
    # Technology conversion popularity
    tech_stats = db.session.query(
        Conversion.source_technology,
        Conversion.target_technology,
        func.count(Conversion.id).label('count')
    ).filter(
        Conversion.user_id == user_id,
        Conversion.created_at >= start_date
    ).group_by(
        Conversion.source_technology,
        Conversion.target_technology
    ).order_by(desc('count')).limit(10).all()
    
    # Performance metrics
    avg_processing_time = db.session.query(
        func.avg(Conversion.processing_time)
    ).filter(
        Conversion.user_id == user_id,
        Conversion.status == ConversionStatus.COMPLETED,
        Conversion.created_at >= start_date
    ).scalar() or 0
    
    # Success rate trend
    total_in_period = Conversion.query.filter(
        Conversion.user_id == user_id,
        Conversion.created_at >= start_date
    ).count()
    
    completed_in_period = Conversion.query.filter(
        Conversion.user_id == user_id,
        Conversion.status == ConversionStatus.COMPLETED,
        Conversion.created_at >= start_date
    ).count()
    
    return jsonify({
        'daily_trends': [
            {
                'date': stat.date.isoformat(),
                'conversions': stat.count,
                'avg_processing_time': round(stat.avg_time, 2) if stat.avg_time else 0
            }
            for stat in daily_stats
        ],
        'technology_popularity': [
            {
                'source': stat.source_technology,
                'target': stat.target_technology,
                'count': stat.count
            }
            for stat in tech_stats
        ],
        'performance_metrics': {
            'avg_processing_time_seconds': round(avg_processing_time, 2),
            'success_rate': round((completed_in_period / total_in_period * 100) if total_in_period > 0 else 0, 1),
            'total_conversions': total_in_period
        }
    })

# File Management APIs
@api_bp.route('/files/upload', methods=['POST'])
@login_required
def upload_file():
    """Upload a file for conversion"""
    if 'file' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    try:
        # Validate file
        file_handler = current_app.file_handler
        if not file_handler.validate_file(file):
            return jsonify({'error': 'Invalid file type or size'}), 400
        
        # Save file
        saved_filename = file_handler.save_file(file)
        
        # Create document record
        document = Document(
            filename=saved_filename,
            original_name=file.filename,
            user_id=session.get('user_id'),
            file_size=file_handler.get_file_size(file),
            file_type=file.content_type,
            file_path=os.path.join(current_app.config['UPLOAD_FOLDER'], 'documents', saved_filename),
            checksum=file_handler.calculate_checksum(file)
        )
        
        db.session.add(document)
        db.session.commit()
        
        # Log activity
        log_activity(
            user_id=session.get('user_id'),
            action='file_uploaded',
            resource_type='document',
            resource_id=str(document.id),
            details={
                'filename': file.filename,
                'file_size': document.file_size,
                'file_type': document.file_type
            }
        )
        
        return jsonify({
            'message': 'File uploaded successfully',
            'document': document.to_dict()
        })
        
    except Exception as e:
        current_app.logger.error(f"File upload error: {str(e)}")
        return jsonify({'error': 'Upload failed'}), 500

@api_bp.route('/files/<int:document_id>', methods=['GET'])
@login_required
def get_file_info(document_id):
    """Get file information"""
    document = Document.query.get(document_id)
    
    if not document:
        return jsonify({'error': 'Document not found'}), 404
    
    # Check ownership
    if document.user_id != session.get('user_id'):
        current_user = User.query.get(session['user_id'])
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Access denied'}), 403
    
    return jsonify(document.to_dict())

@api_bp.route('/files/<int:document_id>/download', methods=['GET'])
@login_required
def download_file(document_id):
    """Download original file"""
    document = Document.query.get(document_id)
    
    if not document:
        return jsonify({'error': 'Document not found'}), 404
    
    # Check ownership
    if document.user_id != session.get('user_id'):
        current_user = User.query.get(session['user_id'])
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Access denied'}), 403
    
    try:
        return send_file(
            document.file_path,
            as_attachment=True,
            download_name=document.original_name
        )
    except FileNotFoundError:
        return jsonify({'error': 'File not found on disk'}), 404

# Conversion APIs
@api_bp.route('/conversions', methods=['POST'])
@login_required
def create_conversion():
    """Create a new conversion job"""
    data = request.get_json()
    
    required_fields = ['document_id', 'source_technology', 'target_technology']
    if not all(field in data for field in required_fields):
        return jsonify({'error': 'Missing required fields'}), 400
    
    # Validate document exists and belongs to user
    document = Document.query.get(data['document_id'])
    if not document:
        return jsonify({'error': 'Document not found'}), 404
    
    if document.user_id != session.get('user_id'):
        return jsonify({'error': 'Access denied'}), 403
    
    try:
        # Create conversion record
        conversion = Conversion(
            id=str(uuid.uuid4()),
            document_id=document.id,
            user_id=session.get('user_id'),
            source_technology=data['source_technology'],
            target_technology=data['target_technology'],
            conversion_depth=data.get('conversion_depth', 'comprehensive'),
            output_format=data.get('output_format', 'markdown'),
            status=ConversionStatus.QUEUED
        )
        
        # Set configuration
        conversion.set_configuration({
            'include_code_examples': data.get('include_code_examples', True),
            'include_migration_steps': data.get('include_migration_steps', True),
            'include_performance_notes': data.get('include_performance_notes', False),
            'include_security_notes': data.get('include_security_notes', False),
            'include_testing_strategy': data.get('include_testing_strategy', False)
        })
        
        db.session.add(conversion)
        db.session.commit()
        
        # Start async processing
        ai_processor = current_app.ai_processor
        if ai_processor:
            ai_processor.queue_conversion(conversion.id)
        
        # Log activity
        log_activity(
            user_id=session.get('user_id'),
            action='conversion_started',
            resource_type='conversion',
            resource_id=conversion.id,
            details={
                'document_id': document.id,
                'source_tech': data['source_technology'],
                'target_tech': data['target_technology']
            }
        )
        
        return jsonify({
            'message': 'Conversion started successfully',
            'conversion': conversion.to_dict()
        }), 201
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Conversion creation error: {str(e)}")
        return jsonify({'error': 'Failed to start conversion'}), 500

@api_bp.route('/conversions/<conversion_id>', methods=['GET'])
@login_required
def get_conversion(conversion_id):
    """Get conversion details"""
    conversion = Conversion.query.get(conversion_id)
    
    if not conversion:
        return jsonify({'error': 'Conversion not found'}), 404
    
    # Check ownership
    if conversion.user_id != session.get('user_id'):
        current_user = User.query.get(session['user_id'])
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Access denied'}), 403
    
    return jsonify(conversion.to_dict())

@api_bp.route('/conversions/<conversion_id>/result', methods=['GET'])
@login_required
def get_conversion_result(conversion_id):
    """Get conversion result file"""
    conversion = Conversion.query.get(conversion_id)
    
    if not conversion:
        return jsonify({'error': 'Conversion not found'}), 404
    
    if conversion.user_id != session.get('user_id'):
        current_user = User.query.get(session['user_id'])
        if current_user.role != UserRole.ADMIN:
            return jsonify({'error': 'Access denied'}), 403
    
    if conversion.status != ConversionStatus.COMPLETED:
        return jsonify({'error': 'Conversion not completed'}), 400
    
    if not conversion.result_path or not os.path.exists(conversion.result_path):
        return jsonify({'error': 'Result file not found'}), 404
    
    try:
        return send_file(
            conversion.result_path,
            as_attachment=True,
            download_name=f"converted_{conversion.document.original_name}.{conversion.output_format}"
        )
    except Exception as e:
        current_app.logger.error(f"Result download error: {str(e)}")
        return jsonify({'error': 'Failed to download result'}), 500

@api_bp.route('/conversions', methods=['GET'])
@login_required
def list_conversions():
    """List user conversions with filtering and pagination"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 20, type=int)
    status = request.args.get('status')
    source_tech = request.args.get('source_tech')
    target_tech = request.args.get('target_tech')
    days = request.args.get('days', type=int)
    
    # Base query
    query = Conversion.query.filter_by(user_id=session.get('user_id'))
    
    # Apply filters
    if status:
        query = query.filter_by(status=ConversionStatus(status))
    
    if source_tech:
        query = query.filter_by(source_technology=source_tech)
    
    if target_tech:
        query = query.filter_by(target_technology=target_tech)
    
    if days:
        start_date = datetime.utcnow() - timedelta(days=days)
        query = query.filter(Conversion.created_at >= start_date)
    
    # Paginate
    conversions = query.order_by(desc(Conversion.created_at)).paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    
    return jsonify({
        'conversions': [conv.to_dict() for conv in conversions.items],
        'pagination': {
            'total': conversions.total,
            'pages': conversions.pages,
            'current_page': page,
            'per_page': per_page,
            'has_next': conversions.has_next,
            'has_prev': conversions.has_prev
        }
    })

# System Administration APIs
@api_bp.route('/admin/users', methods=['GET'])
@role_required(UserRole.ADMIN)
def admin_list_users():
    """Admin: List all users"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    search = request.args.get('search')
    role = request.args.get('role')
    is_active = request.args.get('is_active')
    
    query = User.query
    
    # Apply filters
    if search:
        query = query.filter(
            db.or_(
                User.email.contains(search),
                User.first_name.contains(search),
                User.last_name.contains(search)
            )
        )
    
    if role:
        query = query.filter_by(role=UserRole(role))
    
    if is_active is not None:
        query = query.filter_by(is_active=is_active.lower() == 'true')
    
    users = query.order_by(User.created_at.desc()).paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    
    return jsonify({
        'users': [user.to_dict() for user in users.items],
        'pagination': {
            'total': users.total,
            'pages': users.pages,
            'current_page': page,
            'per_page': per_page
        }
    })

@api_bp.route('/admin/system/stats', methods=['GET'])
@role_required(UserRole.ADMIN)
def admin_system_stats():
    """Admin: Get system statistics"""
    # User statistics
    total_users = User.query.count()
    active_users = User.query.filter_by(is_active=True).count()
    admin_users = User.query.filter_by(role=UserRole.ADMIN).count()
    
    # Document statistics
    total_documents = Document.query.count()
    total_file_size = db.session.query(func.sum(Document.file_size)).scalar() or 0
    
    # Conversion statistics
    total_conversions = Conversion.query.count()
    completed_conversions = Conversion.query.filter_by(status=ConversionStatus.COMPLETED).count()
    failed_conversions = Conversion.query.filter_by(status=ConversionStatus.FAILED).count()
    processing_conversions = Conversion.query.filter_by(status=ConversionStatus.PROCESSING).count()
    
    # Recent activity
    recent_logins = User.query.filter(
        User.last_login >= datetime.utcnow() - timedelta(hours=24)
    ).count()
    
    # Top users by conversions
    top_users = db.session.query(
        User.first_name,
        User.last_name,
        User.email,
        func.count(Conversion.id).label('conversion_count')
    ).join(Conversion).group_by(User.id).order_by(desc('conversion_count')).limit(5).all()
    
    return jsonify({
        'users': {
            'total': total_users,
            'active': active_users,
            'admins': admin_users,
            'recent_logins_24h': recent_logins
        },
        'documents': {
            'total': total_documents,
            'total_size_bytes': total_file_size,
            'total_size_mb': round(total_file_size / (1024 * 1024), 2)
        },
        'conversions': {
            'total': total_conversions,
            'completed': completed_conversions,
            'failed': failed_conversions,
            'processing': processing_conversions,
            'success_rate': round((completed_conversions / total_conversions * 100) if total_conversions > 0 else 0, 1)
        },
        'top_users': [
            {
                'name': f"{user.first_name} {user.last_name}",
                'email': user.email,
                'conversions': user.conversion_count
            }
            for user in top_users
        ]
    })

@api_bp.route('/admin/settings', methods=['GET'])
@role_required(UserRole.ADMIN)
def get_system_settings():
    """Admin: Get system settings"""
    settings = SystemSetting.query.all()
    return jsonify({
        'settings': [setting.to_dict() for setting in settings]
    })

@api_bp.route('/admin/settings', methods=['PUT'])
@role_required(UserRole.ADMIN)
def update_system_settings():
    """Admin: Update system settings"""
    data = request.get_json()
    
    if not data or 'settings' not in data:
        return jsonify({'error': 'Settings data required'}), 400
    
    try:
        updated_settings = []
        
        for setting_data in data['settings']:
            setting = SystemSetting.query.filter_by(key=setting_data['key']).first()
            
            if setting:
                setting.value = setting_data['value']
                setting.updated_by = session.get('user_id')
                setting.updated_at = datetime.utcnow()
                updated_settings.append(setting.key)
            else:
                # Create new setting
                new_setting = SystemSetting(
                    key=setting_data['key'],
                    value=setting_data['value'],
                    description=setting_data.get('description', ''),
                    updated_by=session.get('user_id')
                )
                db.session.add(new_setting)
                updated_settings.append(new_setting.key)
        
        db.session.commit()
        
        # Log activity
        log_activity(
            user_id=session.get('user_id'),
            action='system_settings_updated',
            details={'updated_settings': updated_settings}
        )
        
        return jsonify({
            'message': 'Settings updated successfully',
            'updated_settings': updated_settings
        })
        
    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Settings update error: {str(e)}")
        return jsonify({'error': 'Failed to update settings'}), 500

@api_bp.route('/admin/audit-logs', methods=['GET'])
@role_required(UserRole.ADMIN)
def get_audit_logs():
    """Admin: Get audit logs"""
    page = request.args.get('page', 1, type=int)
    per_page = request.args.get('per_page', 50, type=int)
    action = request.args.get('action')
    user_id = request.args.get('user_id', type=int)
    days = request.args.get('days', 30, type=int)
    
    query = AuditLog.query
    
    # Apply filters
    if action:
        query = query.filter(AuditLog.action.contains(action))
    
    if user_id:
        query = query.filter_by(user_id=user_id)
    
    if days:
        start_date = datetime.utcnow() - timedelta(days=days)
        query = query.filter(AuditLog.timestamp >= start_date)
    
    logs = query.order_by(desc(AuditLog.timestamp)).paginate(
        page=page,
        per_page=per_page,
        error_out=False
    )
    
    return jsonify({
        'audit_logs': [log.to_dict() for log in logs.items],
        'pagination': {
            'total': logs.total,
            'pages': logs.pages,
            'current_page': page,
            'per_page': per_page
        }
    })

# Health Check & Status APIs
@api_bp.route('/health', methods=['GET'])
def health_check():
    """System health check endpoint"""
    try:
        # Test database connection
        db.session.execute(text('SELECT 1'))
        
        return jsonify({
            'status': 'healthy',
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'version': '1.0.0',
            'components': {
                'database': 'healthy',
                'filesystem': 'healthy'
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Health check failed: {str(e)}")
        return jsonify({
            'status': 'unhealthy',
            'error': str(e),
            'timestamp': datetime.now(timezone.utc).isoformat()
        }), 500

@api_bp.route('/storage/stats', methods=['GET'])
def storage_stats():
    """Get storage statistics"""
    try:
        upload_dir = current_app.config.get('UPLOAD_FOLDER')
        total_size = get_directory_size(upload_dir)
        
        return jsonify({
            'total_size_mb': round(total_size / (1024 * 1024), 2),
            'upload_path': upload_dir
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@api_bp.route('/status', methods=['GET'])
@login_required
def system_status():
    """Get detailed system status"""
    try:
        # Get database stats - simplified without external dependency
        total_tables = db.session.execute(
            text("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = 'public'")
        ).scalar()
        
        # Get processing queue status
        queued_jobs = Conversion.query.filter_by(status=ConversionStatus.QUEUED).count()
        processing_jobs = Conversion.query.filter_by(status=ConversionStatus.PROCESSING).count()
        
        # Get disk usage
        upload_dir = current_app.config.get('UPLOAD_FOLDER')
        disk_usage = get_directory_size(upload_dir)
        
        return jsonify({
            'database': {
                'tables': total_tables,
                'connection': 'healthy'
            },
            'processing_queue': {
                'queued': queued_jobs,
                'processing': processing_jobs
            },
            'storage': {
                'upload_directory_size_mb': round(disk_usage / (1024 * 1024), 2),
                'upload_directory_path': upload_dir
            },
            'system': {
                'uptime': get_system_uptime(),
                'memory_usage': get_memory_usage()
            }
        })
        
    except Exception as e:
        current_app.logger.error(f"Status check failed: {str(e)}")
        return jsonify({'error': 'Status check failed'}), 500

def get_directory_size(directory):
    """Get total size of directory in bytes"""
    total = 0
    try:
        for dirpath, dirnames, filenames in os.walk(directory):
            for filename in filenames:
                filepath = os.path.join(dirpath, filename)
                if os.path.exists(filepath):
                    total += os.path.getsize(filepath)
    except Exception:
        pass
    return total

def get_system_uptime():
    """Get system uptime (simplified)"""
    try:
        with open('/proc/uptime', 'r') as f:
            uptime_seconds = float(f.readline().split()[0])
            return uptime_seconds
    except Exception:
        return None

def get_memory_usage():
    """Get memory usage (simplified)"""
    try:
        import psutil
        memory = psutil.virtual_memory()
        return {
            'total_mb': round(memory.total / (1024 * 1024), 2),
            'available_mb': round(memory.available / (1024 * 1024), 2),
            'percent_used': memory.percent
        }
    except ImportError:
        return None