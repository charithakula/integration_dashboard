"""
Database initialization and utility functions.
NOTE: The actual SQLAlchemy instance (db) is defined in models.py to avoid circular imports.
"""

from sqlalchemy import text
import logging

logger = logging.getLogger(__name__)

def init_db():
    """Initialize database tables using the Flask-SQLAlchemy instance from models.py"""
    try:
        # Import the db instance from models.py (where it's defined)
        from models import db
        
        # Create all tables
        db.create_all()
        logger.info("Database tables created successfully")
        return True
        
    except Exception as e:
        logger.error(f"Database initialization failed: {e}")
        return False

def get_db_stats():
    """Get database statistics"""
    try:
        from models import db, User, Document, Conversion
        
        stats = {
            'total_users': User.query.count(),
            'total_documents': Document.query.count(),
            'total_conversions': Conversion.query.count(),
            'connection_status': 'healthy'
        }
        
        return stats
        
    except Exception as e:
        logger.error(f"Failed to get database stats: {e}")
        return {
            'connection_status': 'error',
            'error': str(e)
        }

def test_db_connection():
    """Test database connection"""
    try:
        from models import db
        
        # Simple connection test
        result = db.session.execute(text('SELECT 1')).fetchone()
        return result is not None
        
    except Exception as e:
        logger.error(f"Database connection test failed: {e}")
        return False

def get_table_info():
    """Get information about database tables"""
    try:
        from models import db
        
        # Query to get table information
        result = db.session.execute(
            text("""
                SELECT table_name, 
                       (SELECT COUNT(*) FROM information_schema.columns 
                        WHERE table_name = t.table_name) as column_count
                FROM information_schema.tables t
                WHERE table_schema = 'public' 
                AND table_type = 'BASE TABLE'
                ORDER BY table_name
            """)
        ).fetchall()
        
        tables = [
            {
                'name': row.table_name,
                'columns': row.column_count
            }
            for row in result
        ]
        
        return tables
        
    except Exception as e:
        logger.error(f"Failed to get table info: {e}")
        return []

def cleanup_old_data(days=90):
    """Clean up old data based on retention policy"""
    try:
        from models import db, AuditLog, Conversion
        from datetime import datetime, timedelta
        
        cutoff_date = datetime.utcnow() - timedelta(days=days)
        
        # Clean up old audit logs
        old_logs = AuditLog.query.filter(AuditLog.timestamp < cutoff_date).count()
        if old_logs > 0:
            AuditLog.query.filter(AuditLog.timestamp < cutoff_date).delete()
            logger.info(f"Cleaned up {old_logs} old audit log entries")
        
        # Clean up old failed conversions
        old_conversions = Conversion.query.filter(
            Conversion.created_at < cutoff_date,
            Conversion.status.in_(['failed', 'cancelled'])
        ).count()
        
        if old_conversions > 0:
            Conversion.query.filter(
                Conversion.created_at < cutoff_date,
                Conversion.status.in_(['failed', 'cancelled'])
            ).delete()
            logger.info(f"Cleaned up {old_conversions} old failed conversions")
        
        db.session.commit()
        return {'cleaned_logs': old_logs, 'cleaned_conversions': old_conversions}
        
    except Exception as e:
        logger.error(f"Data cleanup failed: {e}")
        db.session.rollback()
        return {'error': str(e)}

def backup_database(backup_path=None):
    """Create database backup (simplified version)"""
    try:
        import os
        from datetime import datetime
        
        if not backup_path:
            backup_path = f"backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sql"
        
        # This would typically use pg_dump for PostgreSQL
        # For now, just return the command that should be run
        db_url = os.environ.get('DATABASE_URL', '')
        
        if 'postgresql' in db_url:
            # Extract connection details for pg_dump
            return {
                'status': 'info',
                'message': f'To backup database, run: pg_dump {db_url} > {backup_path}'
            }
        
        return {
            'status': 'error',
            'message': 'Backup not implemented for this database type'
        }
        
    except Exception as e:
        logger.error(f"Backup preparation failed: {e}")
        return {
            'status': 'error',
            'message': str(e)
        }