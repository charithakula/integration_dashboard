from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from flask_sqlalchemy import SQLAlchemy
from enum import Enum
import json

# Create the SINGLE SQLAlchemy instance that will be used throughout the application
db = SQLAlchemy()

class UserRole(Enum):
    ADMIN = 'admin'
    EDITOR = 'editor'
    VIEWER = 'viewer'

class ConversionStatus(Enum):
    QUEUED = 'queued'
    PROCESSING = 'processing' 
    COMPLETED = 'completed'
    FAILED = 'failed'
    CANCELLED = 'cancelled'

class User(db.Model):
    """User model for authentication and authorization"""
    __tablename__ = 'users'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    role = db.Column(db.Enum(UserRole), default=UserRole.VIEWER)
    is_active = db.Column(db.Boolean, default=True)
    last_login = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    documents = db.relationship('Document', backref='user', lazy=True, cascade='all, delete-orphan')
    conversions = db.relationship('Conversion', backref='user', lazy=True, cascade='all, delete-orphan')
    audit_logs = db.relationship('AuditLog', backref='user', lazy=True)
    
    def set_password(self, password):
        """Set password hash"""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check password against hash"""
        return check_password_hash(self.password_hash, password)
    
    @property
    def full_name(self):
        """Get full name"""
        return f"{self.first_name} {self.last_name}"
    
    @property
    def initials(self):
        """Get user initials"""
        return f"{self.first_name[0]}{self.last_name[0]}".upper()
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'email': self.email,
            'full_name': self.full_name,
            'initials': self.initials,
            'role': self.role.value,
            'is_active': self.is_active,
            'last_login': self.last_login.isoformat() if self.last_login else None,
            'created_at': self.created_at.isoformat()
        }

class Document(db.Model):
    """Document model for uploaded files"""
    __tablename__ = 'documents'
    
    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    original_name = db.Column(db.String(255), nullable=False)
    file_path = db.Column(db.String(500))
    file_size = db.Column(db.Integer)
    file_type = db.Column(db.String(50))
    checksum = db.Column(db.String(64))
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relationships
    conversions = db.relationship('Conversion', backref='document', lazy=True, cascade='all, delete-orphan')
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'filename': self.filename,
            'original_name': self.original_name,
            'file_size': self.file_size,
            'file_type': self.file_type,
            'created_at': self.created_at.isoformat(),
            'conversion_count': len(self.conversions)
        }

class Conversion(db.Model):
    """Conversion model for document processing jobs"""
    __tablename__ = 'conversions'
    
    id = db.Column(db.String(36), primary_key=True)  # UUID
    document_id = db.Column(db.Integer, db.ForeignKey('documents.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)
    source_technology = db.Column(db.String(50), nullable=False)
    target_technology = db.Column(db.String(50), nullable=False)
    conversion_depth = db.Column(db.String(20), default='comprehensive')
    output_format = db.Column(db.String(20), default='markdown')
    status = db.Column(db.Enum(ConversionStatus), default=ConversionStatus.QUEUED)
    progress = db.Column(db.Integer, default=0)
    result_path = db.Column(db.String(500))
    error_message = db.Column(db.Text)
    processing_time = db.Column(db.Float)  # seconds
    ai_tokens_used = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # Configuration JSON field
    configuration = db.Column(db.Text)  # JSON string
    
    def set_configuration(self, config_dict):
        """Set configuration as JSON"""
        self.configuration = json.dumps(config_dict)
    
    def get_configuration(self):
        """Get configuration as dictionary"""
        return json.loads(self.configuration) if self.configuration else {}
    
    @property
    def duration(self):
        """Get processing duration"""
        if self.started_at and self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'document_id': self.document_id,
            'document_name': self.document.original_name if self.document else None,
            'source_technology': self.source_technology,
            'target_technology': self.target_technology,
            'conversion_depth': self.conversion_depth,
            'output_format': self.output_format,
            'status': self.status.value,
            'progress': self.progress,
            'error_message': self.error_message,
            'processing_time': self.processing_time,
            'ai_tokens_used': self.ai_tokens_used,
            'created_at': self.created_at.isoformat(),
            'started_at': self.started_at.isoformat() if self.started_at else None,
            'completed_at': self.completed_at.isoformat() if self.completed_at else None,
            'configuration': self.get_configuration()
        }

class AuditLog(db.Model):
    """Audit log model for tracking system activities"""
    __tablename__ = 'audit_logs'
    
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=True)
    action = db.Column(db.String(50), nullable=False)
    resource_type = db.Column(db.String(50))
    resource_id = db.Column(db.String(50))
    details = db.Column(db.Text)  # JSON string
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(500))
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    def set_details(self, details_dict):
        """Set details as JSON"""
        self.details = json.dumps(details_dict)
    
    def get_details(self):
        """Get details as dictionary"""
        return json.loads(self.details) if self.details else {}
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'user_id': self.user_id,
            'user_name': self.user.full_name if self.user else 'System',
            'action': self.action,
            'resource_type': self.resource_type,
            'resource_id': self.resource_id,
            'details': self.get_details(),
            'ip_address': self.ip_address,
            'timestamp': self.timestamp.isoformat()
        }

class SystemSetting(db.Model):
    """System settings model"""
    __tablename__ = 'system_settings'
    
    id = db.Column(db.Integer, primary_key=True)
    key = db.Column(db.String(100), unique=True, nullable=False)
    value = db.Column(db.Text)
    description = db.Column(db.String(255))
    is_encrypted = db.Column(db.Boolean, default=False)
    updated_by = db.Column(db.Integer, db.ForeignKey('users.id'))
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'key': self.key,
            'value': self.value if not self.is_encrypted else '*****',
            'description': self.description,
            'updated_at': self.updated_at.isoformat()
        }

class ProcessingQueue(db.Model):
    """Queue model for background processing"""
    __tablename__ = 'processing_queue'
    
    id = db.Column(db.Integer, primary_key=True)
    conversion_id = db.Column(db.String(36), db.ForeignKey('conversions.id'), nullable=False)
    priority = db.Column(db.Integer, default=5)
    retry_count = db.Column(db.Integer, default=0)
    max_retries = db.Column(db.Integer, default=3)
    scheduled_at = db.Column(db.DateTime, default=datetime.utcnow)
    started_at = db.Column(db.DateTime)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert to dictionary"""
        return {
            'id': self.id,
            'conversion_id': self.conversion_id,
            'priority': self.priority,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'scheduled_at': self.scheduled_at.isoformat(),
            'created_at': self.created_at.isoformat()
        }