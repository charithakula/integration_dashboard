-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pgcrypto;
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Create ENUM types
DO $$
BEGIN
    -- Drop existing types to recreate with correct values
    DROP TYPE IF EXISTS conversion_status CASCADE;
    DROP TYPE IF EXISTS user_role CASCADE;
    
    -- User roles (matching Python exactly)
    CREATE TYPE user_role AS ENUM ('admin', 'editor', 'viewer');
    
    -- Conversion status (matching Python exactly) 
    CREATE TYPE conversion_status AS ENUM ('queued', 'processing', 'completed', 'failed', 'cancelled');
END$$;

-- Drop existing tables to recreate with correct structure
DROP TABLE IF EXISTS conversions CASCADE;
DROP TABLE IF EXISTS documents CASCADE;
DROP TABLE IF EXISTS audit_logs CASCADE;
DROP TABLE IF EXISTS system_settings CASCADE;

-- Users table (keep existing data)
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(120) UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    first_name VARCHAR(50),
    last_name VARCHAR(50),
    role user_role NOT NULL DEFAULT 'viewer',
    is_active BOOLEAN DEFAULT true,
    is_verified BOOLEAN DEFAULT false,
    last_login TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Documents table (expanded to match Python models exactly)
CREATE TABLE documents (
    id SERIAL PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    filename VARCHAR(255) NOT NULL,  -- Match Python model
    original_name VARCHAR(255) NOT NULL,  -- Match Python model
    file_path VARCHAR(500),  -- Match Python model
    file_size INTEGER,  -- Match Python model (Integer, not BIGINT)
    file_type VARCHAR(100),  -- Increased to handle long MIME types
    checksum VARCHAR(64),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Conversions table (match Python model exactly)
CREATE TABLE conversions (
    id VARCHAR(36) PRIMARY KEY,  -- UUID as string to match Python
    document_id INTEGER NOT NULL REFERENCES documents(id) ON DELETE CASCADE,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    source_technology VARCHAR(50) NOT NULL,  -- Match Python model
    target_technology VARCHAR(50) NOT NULL,  -- Match Python model
    conversion_depth VARCHAR(20) DEFAULT 'comprehensive',  -- Match Python model
    output_format VARCHAR(20) DEFAULT 'markdown',  -- Match Python model
    status conversion_status DEFAULT 'queued',
    progress INTEGER DEFAULT 0,  -- Add missing field
    result_path VARCHAR(500),  -- Match Python model
    error_message TEXT,
    processing_time REAL,  -- Match Python model (Float)
    ai_tokens_used INTEGER,  -- Add missing field
    configuration TEXT,  -- JSON as TEXT to match Python model
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE
);

-- Audit logs table (match Python model exactly)
CREATE TABLE audit_logs (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(50) NOT NULL,  -- Match Python model
    resource_type VARCHAR(50),
    resource_id VARCHAR(50),
    details TEXT,  -- JSON as TEXT to match Python model
    ip_address VARCHAR(45),  -- Match Python model
    user_agent VARCHAR(500),  -- Match Python model
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- System settings table (match Python model exactly)
CREATE TABLE system_settings (
    id SERIAL PRIMARY KEY,
    key VARCHAR(100) UNIQUE NOT NULL,
    value TEXT,
    description VARCHAR(255),  -- Match Python model
    is_encrypted BOOLEAN DEFAULT false,  -- Add missing field
    updated_by INTEGER REFERENCES users(id),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_role ON users(role);
CREATE INDEX idx_users_active ON users(is_active);

CREATE INDEX idx_documents_user_id ON documents(user_id);
CREATE INDEX idx_documents_created_at ON documents(created_at);
CREATE INDEX idx_documents_filename ON documents(filename);

CREATE INDEX idx_conversions_user_id ON conversions(user_id);
CREATE INDEX idx_conversions_document_id ON conversions(document_id);
CREATE INDEX idx_conversions_status ON conversions(status);
CREATE INDEX idx_conversions_created_at ON conversions(created_at);
CREATE INDEX idx_conversions_source_tech ON conversions(source_technology);
CREATE INDEX idx_conversions_target_tech ON conversions(target_technology);

CREATE INDEX idx_audit_logs_user_id ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_action ON audit_logs(action);
CREATE INDEX idx_audit_logs_timestamp ON audit_logs(timestamp);

CREATE INDEX idx_system_settings_key ON system_settings(key);

-- Create application database users with correct passwords
DO $$
BEGIN
    -- Main application user
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='docconverter_app') THEN
        CREATE USER docconverter_app WITH PASSWORD 'DocConverter2024';
    END IF;
    
    -- Read-only user for reporting
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='docconverter_readonly') THEN
        CREATE USER docconverter_readonly WITH PASSWORD 'ReadOnly2024';
    END IF;
    
    -- Backup user
    IF NOT EXISTS (SELECT 1 FROM pg_roles WHERE rolname='docconverter_backup') THEN
        CREATE USER docconverter_backup WITH PASSWORD 'Backup2024';
    END IF;
END$$;

-- Grant database connection privileges
GRANT CONNECT ON DATABASE doc_converter TO docconverter_app, docconverter_readonly, docconverter_backup;
GRANT USAGE ON SCHEMA public TO docconverter_app, docconverter_readonly, docconverter_backup;

-- Grant table privileges to main app user
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO docconverter_app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO docconverter_app;

-- Grant default privileges for future tables
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO docconverter_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO docconverter_app;

-- Grant read-only privileges
GRANT SELECT ON ALL TABLES IN SCHEMA public TO docconverter_readonly;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO docconverter_readonly;

-- Grant backup privileges
GRANT SELECT ON ALL TABLES IN SCHEMA public TO docconverter_backup;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT ON TABLES TO docconverter_backup;

-- Create updated user management function
CREATE OR REPLACE FUNCTION create_app_user(
    user_email VARCHAR(120),
    user_password VARCHAR(100),
    user_first_name VARCHAR(50),
    user_last_name VARCHAR(50),
    user_role user_role DEFAULT 'viewer'
)
RETURNS INTEGER AS $$
DECLARE
    new_user_id INTEGER;
BEGIN
    INSERT INTO users (email, password_hash, first_name, last_name, role, is_active)
    VALUES (user_email, crypt(user_password, gen_salt('bf')), user_first_name, user_last_name, user_role, true)
    RETURNING id INTO new_user_id;

    INSERT INTO audit_logs (action, resource_type, resource_id, details, timestamp)
    VALUES ('user_created', 'user', new_user_id::TEXT,
            jsonb_build_object('email', user_email, 'role', user_role)::TEXT,
            CURRENT_TIMESTAMP);

    RETURN new_user_id;
END;
$$ LANGUAGE plpgsql;

-- Create admin user if not exists
DO $$
DECLARE
    admin_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO admin_count FROM users WHERE role = 'admin';
    
    IF admin_count = 0 THEN
        PERFORM create_app_user('admin@docconverter.com', 'AdminPassword123!', 'System', 'Administrator', 'admin');
    END IF;
END$$;

-- Seed additional users (only if they don't exist)
DO $$
BEGIN
    IF NOT EXISTS (SELECT 1 FROM users WHERE email = 'john.doe@company.com') THEN
        PERFORM create_app_user('john.doe@company.com', 'TempPassword123!', 'John', 'Doe', 'editor');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM users WHERE email = 'jane.smith@company.com') THEN
        PERFORM create_app_user('jane.smith@company.com', 'TempPassword123!', 'Jane', 'Smith', 'editor');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM users WHERE email = 'mike.wilson@company.com') THEN
        PERFORM create_app_user('mike.wilson@company.com', 'TempPassword123!', 'Mike', 'Wilson', 'viewer');
    END IF;
    IF NOT EXISTS (SELECT 1 FROM users WHERE email = 'sarah.johnson@company.com') THEN
        PERFORM create_app_user('sarah.johnson@company.com', 'TempPassword123!', 'Sarah', 'Johnson', 'admin');
    END IF;
END$$;

-- System settings
INSERT INTO system_settings (key, value, description) VALUES
('max_file_size_mb', '50', 'Maximum file size for uploads in MB'),
('supported_formats', 'pdf,docx,txt,md,pptx', 'Supported file formats for conversion'),
('default_conversion_depth', 'comprehensive', 'Default depth for conversions'),
('ai_processing_timeout', '300', 'Timeout for AI processing in seconds'),
('max_concurrent_conversions', '5', 'Maximum number of concurrent conversions per user'),
('retention_days', '90', 'Number of days to retain conversion results'),
('enable_email_notifications', 'true', 'Enable email notifications for completed conversions')
ON CONFLICT (key) DO UPDATE SET 
    value = EXCLUDED.value,
    description = EXCLUDED.description,
    updated_at = CURRENT_TIMESTAMP;

-- Create function to update timestamps
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Create triggers for automatic timestamp updates
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON system_settings
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Display completion message
SELECT 'Database schema updated successfully!' as status;
SELECT 'Python models and PostgreSQL schema are now synchronized!' as important;