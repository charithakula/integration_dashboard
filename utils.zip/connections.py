"""
Connections Configuration
Central configuration file for all external connections in DocConverter Pro
"""

import logging
from typing import Dict, Any, Optional

logger = logging.getLogger(__name__)

# Import connections with error handling
try:
    from PostgreSQL import postgresql_connection
    POSTGRESQL_AVAILABLE = True
except ImportError as e:
    logger.warning(f"PostgreSQL connection not available: {e}")
    postgresql_connection = None
    POSTGRESQL_AVAILABLE = False

try:
    from AzureOpenAI import azure_openai_connection
    AZURE_OPENAI_AVAILABLE = True
except ImportError as e:
    logger.warning(f"Azure OpenAI connection not available: {e}")
    azure_openai_connection = None
    AZURE_OPENAI_AVAILABLE = False

class ConnectionManager:
    """Manages all external connections for the application."""
    
    def __init__(self):
        self.postgresql = postgresql_connection
        self.azure_openai = azure_openai_connection
        self._connection_status = {}
        self.postgresql_available = POSTGRESQL_AVAILABLE
        self.azure_openai_available = AZURE_OPENAI_AVAILABLE
    
    def initialize_all_connections(self) -> Dict[str, bool]:
        """Initialize and test all connections."""
        results = {}
        
        # Test PostgreSQL
        if self.postgresql_available and self.postgresql:
            try:
                logger.info("Testing PostgreSQL connection...")
                results['postgresql'] = self._test_postgresql()
                status = "SUCCESS" if results['postgresql'] else "FAILED"
                logger.info(f"PostgreSQL connection: {status}")
            except Exception as e:
                logger.error(f"PostgreSQL connection failed: {e}")
                results['postgresql'] = False
        else:
            logger.info("PostgreSQL connection: UNAVAILABLE")
            results['postgresql'] = False
        
        # Test Azure OpenAI
        if self.azure_openai_available and self.azure_openai:
            try:
                logger.info("Testing Azure OpenAI connection...")
                results['azure_openai'] = self._test_azure_openai()
                status = "SUCCESS" if results['azure_openai'] else "FAILED"
                logger.info(f"Azure OpenAI connection: {status}")
            except Exception as e:
                logger.error(f"Azure OpenAI connection failed: {e}")
                results['azure_openai'] = False
        else:
            logger.info("Azure OpenAI connection: UNAVAILABLE")
            results['azure_openai'] = False
        
        self._connection_status = results
        return results
    
    def _test_postgresql(self) -> bool:
        """Test PostgreSQL connection."""
        if not self.postgresql:
            return False
        return self.postgresql.check_connection()
    
    def _test_azure_openai(self) -> bool:
        """Test Azure OpenAI connection."""
        if not self.azure_openai:
            return False
        return self.azure_openai.check_connection()
    
    def get_connection_status(self) -> Dict[str, Any]:
        """Get detailed connection status."""
        postgresql_config = {}
        if self.postgresql:
            postgresql_config = {
                'host': self.postgresql.config['host'],
                'port': self.postgresql.config['port'],
                'database': self.postgresql.config['database'],
                'user': self.postgresql.config['user']
            }
        
        azure_config = {}
        if self.azure_openai:
            azure_config = self.azure_openai.get_model_info()
        
        return {
            'postgresql': {
                'available': self.postgresql_available,
                'connected': self._connection_status.get('postgresql', False),
                'config': postgresql_config
            },
            'azure_openai': {
                'available': self.azure_openai_available,
                'connected': self._connection_status.get('azure_openai', False),
                'config': azure_config
            }
        }
    
    def get_database_connection(self):
        """Get PostgreSQL connection context manager."""
        if not self.postgresql:
            raise ConnectionError("PostgreSQL connection not available")
        return self.postgresql.get_connection()
    
    def execute_database_query(self, query: str, params: Optional[tuple] = None, fetch: bool = False):
        """Execute database query."""
        if not self.postgresql:
            raise ConnectionError("PostgreSQL connection not available")
        return self.postgresql.execute_query(query, params, fetch)
    
    def generate_ai_conversion(self, **kwargs):
        """Generate document conversion using Azure OpenAI."""
        if not self.azure_openai:
            raise ConnectionError("Azure OpenAI connection not available")
        return self.azure_openai.generate_document_conversion(**kwargs)
    
    def close_all_connections(self):
        """Close all connections."""
        try:
            if self.postgresql:
                self.postgresql.close_all_connections()
            logger.info("All connections closed successfully")
        except Exception as e:
            logger.error(f"Error closing connections: {e}")

# Global connection manager instance
connection_manager = ConnectionManager()