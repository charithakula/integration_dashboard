// Enhanced tab loader with dynamic content fetching
class TabLoader {
    constructor() {
        this.cache = new Map();
        this.loadingStates = new Set();
    }

    async loadTabContent(tabName, containerId) {
        // Show loading state
        this.showLoading(containerId);
        
        try {
            // Check cache first
            if (this.cache.has(tabName)) {
                this.renderContent(containerId, this.cache.get(tabName));
                return;
            }

            // Simulate API call or dynamic content loading
            const content = await this.fetchTabData(tabName);
            
            // Cache the content
            this.cache.set(tabName, content);
            
            // Render content
            this.renderContent(containerId, content);
            
        } catch (error) {
            this.showError(containerId, `Failed to load ${tabName} content`);
        } finally {
            this.loadingStates.delete(containerId);
        }
    }

    async fetchTabData(tabName) {
        // Simulate network delay
        await new Promise(resolve => setTimeout(resolve, 500));
        
        // Return mock data based on tab
        switch (tabName) {
            case 'dashboard':
                return this.getDashboardData();
            case 'analytics':
                return this.getAnalyticsData();
            case 'history':
                return this.getHistoryData();
            default:
                return { message: 'Content not available' };
        }
    }

    getDashboardData() {
        return {
            stats: [
                { label: 'Documents Processed', value: '2,847', change: '+12%', icon: 'fa-file-alt' },
                { label: 'Active Users', value: '156', change: '+8%', icon: 'fa-users' },
                { label: 'Time Saved', value: '340h', change: '+25%', icon: 'fa-clock' },
                { label: 'Success Rate', value: '94.2%', change: '+2.1%', icon: 'fa-check-circle' }
            ],
            recentConversions: [
                {
                    name: 'API Architecture Guide.pdf',
                    from: 'Spring Boot',
                    to: 'Node.js Express',
                    status: 'completed',
                    user: 'Sarah Chen',
                    time: '2 hours ago'
                },
                {
                    name: 'Database Design.docx',
                    from: 'Oracle',
                    to: 'PostgreSQL',
                    status: 'processing',
                    user: 'Mike Rodriguez',
                    time: '30 minutes ago'
                }
            ]
        };
    }

    getAnalyticsData() {
        return {
            metrics: [
                { label: 'Avg Processing Time', value: '4.2min', trend: 'down' },
                { label: 'User Satisfaction', value: '4.8/5', trend: 'up' },
                { label: 'AI Accuracy', value: '96.7%', trend: 'up' },
                { label: 'Cost Savings', value: '$47K', trend: 'neutral' }
            ],
            topConversions: [
                { from: 'Spring Boot', to: 'Node.js', count: 47 },
                { from: 'MySQL', to: 'PostgreSQL', count: 34 },
                { from: 'Docker', to: 'Kubernetes', count: 28 }
            ]
        };
    }

    getHistoryData() {
        return {
            conversions: [
                {
                    id: 1,
                    name: 'API Architecture Guide.pdf',
                    from: 'Spring Boot',
                    to: 'Node.js Express',
                    status: 'completed',
                    date: '2024-03-15',
                    user: 'Sarah Chen',
                    size: '2.4 MB'
                }
            ],
            totalCount: 127,
            filters: ['All Time', 'Last 7 days', 'Last 30 days', 'Last 90 days']
        };
    }

    showLoading(containerId) {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div style="display: flex; justify-content: center; align-items: center; height: 200px;">
                    <div class="loading"></div>
                    <span style="margin-left: 1rem; color: var(--gray-500);">Loading...</span>
                </div>
            `;
        }
        this.loadingStates.add(containerId);
    }

    showError(containerId, message) {
        const container = document.getElementById(containerId);
        if (container) {
            container.innerHTML = `
                <div style="text-align: center; padding: 2rem; color: var(--error-500);">
                    <i class="fas fa-exclamation-triangle" style="font-size: 2rem; margin-bottom: 1rem;"></i>
                    <h3>Error</h3>
                    <p>${message}</p>
                    <button class="btn-secondary" onclick="location.reload()">
                        <i class="fas fa-refresh"></i> Retry
                    </button>
                </div>
            `;
        }
    }

    renderContent(containerId, data) {
        const container = document.getElementById(containerId);
        if (!container) return;

        // Render based on container type
        if (containerId.includes('Stats')) {
            this.renderStats(container, data.stats || []);
        } else if (containerId.includes('Content')) {
            this.renderMainContent(container, data);
        }
    }

    renderStats(container, stats) {
        const statsHTML = stats.map(stat => `
            <div class="panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, var(--primary-500), var(--primary-600)); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas ${stat.icon}"></i>
                    </div>
                    <span style="color: var(--success-500); font-size: 0.875rem; font-weight: 600;">${stat.change}</span>
                </div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--gray-900); margin-bottom: 0.5rem;">${stat.value}</div>
                <div style="color: var(--gray-500);">${stat.label}</div>
            </div>
        `).join('');

        container.innerHTML = `
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                ${statsHTML}
            </div>
        `;
    }

    renderMainContent(container, data) {
        // Render different content based on data type
        if (data.recentConversions) {
            this.renderRecentConversions(container, data.recentConversions);
        } else if (data.metrics) {
            this.renderAnalytics(container, data);
        } else if (data.conversions) {
            this.renderHistory(container, data);
        } else {
            container.innerHTML = '<p>No content available</p>';
        }
    }

    renderRecentConversions(container, conversions) {
        const conversionsHTML = conversions.map(conv => `
            <div style="padding: 1rem; border-bottom: 1px solid var(--gray-200); display: flex; align-items: center; gap: 1rem;">
                <div style="width: 40px; height: 40px; background: var(--gray-100); border-radius: 8px; display: flex; align-items: center; justify-content: center;">
                    <i class="fas fa-file"></i>
                </div>
                <div style="flex: 1;">
                    <div style="font-weight: 600; margin-bottom: 0.25rem;">${conv.name}</div>
                    <div style="font-size: 0.85rem; color: var(--gray-500);">${conv.from} → ${conv.to}</div>
                </div>
                <div style="text-align: right; font-size: 0.85rem; color: var(--gray-500);">
                    <div style="background: var(--${conv.status === 'completed' ? 'success' : 'warning'}-100); color: var(--${conv.status === 'completed' ? 'success' : 'warning'}-700); padding: 0.2rem 0.5rem; border-radius: 12px; font-size: 0.7rem; margin-bottom: 0.25rem;">${conv.status}</div>
                    <div>${conv.time}</div>
                </div>
            </div>
        `).join('');

        container.innerHTML = `
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title">Recent Conversions</h3>
                </div>
                ${conversionsHTML}
            </div>
        `;
    }

    clearCache() {
        this.cache.clear();
    }

    isLoading(containerId) {
        return this.loadingStates.has(containerId);
    }
}

// Export for use in main script
window.TabLoader = TabLoader;