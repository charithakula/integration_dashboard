// Global variables
let currentTab = 'dashboard';
let sidebarCollapsed = false;
let processingQueue = [];

// Tab content templates
const tabTemplates = {
    dashboard: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Dashboard</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Dashboard</h1>
                <p class="page-subtitle">Monitor document conversion activities and system performance</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-download"></i> Export Report</button>
                <button class="btn-primary" onclick="switchTab('convert')"><i class="fas fa-plus"></i> New Conversion</button>
            </div>
        </div>
        <div id="dashboardStats"></div>
        <div id="dashboardContent"></div>
    `,
    
    convert: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Convert Documents</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Convert Documents</h1>
                <p class="page-subtitle">Transform technical documents between technology stacks using AI</p>
            </div>
        </div>
        <div class="upload-zone" onclick="document.getElementById('fileInput').click()">
            <div class="upload-icon"><i class="fas fa-cloud-upload-alt"></i></div>
            <h3 class="upload-title">Upload Your Technical Document</h3>
            <p class="upload-subtitle">Drag and drop files here or click to browse</p>
            <p class="upload-formats">Supported: PDF, DOCX, TXT, Markdown • Max file size: 50MB</p>
        </div>
        <div id="convertForm"></div>
    `,
    
    history: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Conversion History</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Conversion History</h1>
                <p class="page-subtitle">View, manage, and download all your document conversions</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-filter"></i> Filter Results</button>
                <button class="btn-secondary"><i class="fas fa-download"></i> Export List</button>
                <button class="btn-primary" onclick="switchTab('convert')"><i class="fas fa-plus"></i> New Conversion</button>
            </div>
        </div>
        <div id="historyContent"></div>
    `,
    
    analytics: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Analytics</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Analytics Dashboard</h1>
                <p class="page-subtitle">Track system performance and usage metrics</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-calendar"></i> Date Range</button>
                <button class="btn-primary"><i class="fas fa-download"></i> Export Report</button>
            </div>
        </div>
        <div id="analyticsContent"></div>
    `,
    
    users: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">User Management</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">User Management</h1>
                <p class="page-subtitle">Manage user accounts, roles, and permissions</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-upload"></i> Import Users</button>
                <button class="btn-primary"><i class="fas fa-user-plus"></i> Add New User</button>
            </div>
        </div>
        <div id="usersContent"></div>
    `,
    
    settings: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">System Settings</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">System Settings</h1>
                <p class="page-subtitle">Configure AI models and system parameters</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-undo"></i> Reset to Defaults</button>
                <button class="btn-primary"><i class="fas fa-save"></i> Save All Changes</button>
            </div>
        </div>
        <div id="settingsContent"></div>
    `,
    
    audit: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Audit Logs</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Audit Logs</h1>
                <p class="page-subtitle">Track system activities and security events</p>
            </div>
            <button class="btn-secondary"><i class="fas fa-download"></i> Export Logs</button>
        </div>
        <div id="auditContent"></div>
    `,
    
    reports: `
        <div class="breadcrumb">
            <a href="#" class="breadcrumb-item" onclick="switchTab('dashboard')">Home</a>
            <i class="fas fa-chevron-right" style="color: var(--gray-400);"></i>
            <span class="breadcrumb-item active">Reports</span>
        </div>
        <div class="page-header">
            <div>
                <h1 class="page-title">Reports & Insights</h1>
                <p class="page-subtitle">Generate detailed reports and analytics</p>
            </div>
            <div style="display: flex; gap: 1rem;">
                <button class="btn-secondary"><i class="fas fa-calendar"></i> Schedule Report</button>
                <button class="btn-primary"><i class="fas fa-plus"></i> Create Report</button>
            </div>
        </div>
        <div id="reportsContent"></div>
    `
};

// Tab switching functionality
function switchTab(tabName) {
    currentTab = tabName;
    
    // Update navigation active state
    const navItems = document.querySelectorAll('.nav-item');
    navItems.forEach(item => {
        item.classList.remove('active');
        if (item.onclick && item.onclick.toString().includes(tabName)) {
            item.classList.add('active');
        }
    });
    
    // Load tab content
    const contentArea = document.getElementById('contentArea');
    contentArea.innerHTML = tabTemplates[tabName] || '<div>Content not found</div>';
    
    // Load specific content for the tab
    loadTabContent(tabName);
    
    // Update page title
    updatePageTitle(tabName);
}

function loadTabContent(tabName) {
    switch (tabName) {
        case 'dashboard':
            loadDashboardContent();
            break;
        case 'convert':
            loadConvertContent();
            break;
        case 'history':
            loadHistoryContent();
            break;
        case 'analytics':
            loadAnalyticsContent();
            break;
        case 'users':
            loadUsersContent();
            break;
        case 'settings':
            loadSettingsContent();
            break;
        case 'audit':
            loadAuditContent();
            break;
        case 'reports':
            loadReportsContent();
            break;
    }
}

// Content loading functions
function loadDashboardContent() {
    const statsHTML = `
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
            <div class="panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, var(--primary-500), var(--primary-600)); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-file-alt"></i>
                    </div>
                    <span style="color: var(--success-500); font-size: 0.875rem; font-weight: 600;">+12%</span>
                </div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--gray-900); margin-bottom: 0.5rem;">2,847</div>
                <div style="color: var(--gray-500);">Documents Processed</div>
            </div>
            <div class="panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, var(--success-500), var(--success-600)); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-users"></i>
                    </div>
                    <span style="color: var(--success-500); font-size: 0.875rem; font-weight: 600;">+8%</span>
                </div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--gray-900); margin-bottom: 0.5rem;">156</div>
                <div style="color: var(--gray-500);">Active Users</div>
            </div>
            <div class="panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, #8b5cf6, #7c3aed); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-clock"></i>
                    </div>
                    <span style="color: var(--success-500); font-size: 0.875rem; font-weight: 600;">+25%</span>
                </div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--gray-900); margin-bottom: 0.5rem;">340h</div>
                <div style="color: var(--gray-500);">Time Saved</div>
            </div>
            <div class="panel" style="padding: 2rem;">
                <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem;">
                    <div style="width: 48px; height: 48px; background: linear-gradient(135deg, var(--warning-500), #d97706); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white;">
                        <i class="fas fa-check-circle"></i>
                    </div>
                    <span style="color: var(--success-500); font-size: 0.875rem; font-weight: 600;">+2.1%</span>
                </div>
                <div style="font-size: 2.5rem; font-weight: 700; color: var(--gray-900); margin-bottom: 0.5rem;">94.2%</div>
                <div style="color: var(--gray-500);">Success Rate</div>
            </div>
        </div>
    `;

    const contentHTML = `
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-history"></i> Recent Conversions</h3>
                    <button class="btn-secondary" style="font-size: 0.85rem; padding: 0.5rem 1rem;">View All</button>
                </div>
                <div style="padding: 1.5rem;">
                    <div style="text-align: center; color: var(--gray-400); padding: 2rem;">
                        <i class="fas fa-file-alt" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <p>No recent conversions</p>
                        <p style="font-size: 0.85rem;">Upload a document to get started</p>
                    </div>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-bolt"></i> Quick Actions</h3>
                </div>
                <div style="padding: 1rem;">
                    <div style="padding: 1rem; cursor: pointer; border-radius: 8px; margin-bottom: 1rem; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='var(--gray-50)'" onmouseout="this.style.backgroundColor=''" onclick="switchTab('convert')">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 32px; height: 32px; background: var(--primary-500); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-upload"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600; color: var(--gray-900);">Upload Document</div>
                                <div style="font-size: 0.85rem; color: var(--gray-500);">Convert technical documents</div>
                            </div>
                        </div>
                    </div>
                    <div style="padding: 1rem; cursor: pointer; border-radius: 8px; margin-bottom: 1rem; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='var(--gray-50)'" onmouseout="this.style.backgroundColor=''" onclick="switchTab('users')">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 32px; height: 32px; background: var(--success-500); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-user-plus"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600; color: var(--gray-900);">Add User</div>
                                <div style="font-size: 0.85rem; color: var(--gray-500);">Invite team members</div>
                            </div>
                        </div>
                    </div>
                    <div style="padding: 1rem; cursor: pointer; border-radius: 8px; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='var(--gray-50)'" onmouseout="this.style.backgroundColor=''" onclick="switchTab('settings')">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 32px; height: 32px; background: var(--warning-500); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-cog"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600; color: var(--gray-900);">System Settings</div>
                                <div style="font-size: 0.85rem; color: var(--gray-500);">Configure AI models</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('dashboardStats').innerHTML = statsHTML;
    document.getElementById('dashboardContent').innerHTML = contentHTML;
}

function loadConvertContent() {
    const formHTML = `
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-cogs"></i> Conversion Configuration</h3>
                </div>
                <div style="padding: 2rem;">
                    <div class="form-group">
                        <label class="form-label">Source Technology Stack</label>
                        <select class="form-select" id="sourceTech">
                            <option value="auto">Auto-detect from document content</option>
                            <option value="spring-boot">Spring Boot / Java</option>
                            <option value="nodejs">Node.js / Express</option>
                            <option value="django">Django / Python</option>
                            <option value="dotnet">.NET / C#</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Target Technology Stack</label>
                        <select class="form-select" id="targetTech" required>
                            <option value="">Select target technology...</option>
                            <option value="nodejs">Node.js / Express</option>
                            <option value="spring-boot">Spring Boot / Java</option>
                            <option value="django">Django / Python</option>
                            <option value="dotnet">.NET / C#</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Output Format</label>
                        <select class="form-select" id="outputFormat">
                            <option value="markdown">Markdown (.md)</option>
                            <option value="docx">Microsoft Word (.docx)</option>
                            <option value="pdf">PDF Document</option>
                            <option value="html">HTML Report</option>
                        </select>
                    </div>
                    <button class="btn-primary" style="width: 100%; justify-content: center;" onclick="startConversion()">
                        <i class="fas fa-magic"></i> Start AI Conversion
                    </button>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-lightbulb"></i> Conversion Tips</h3>
                </div>
                <div style="padding: 2rem;">
                    <div style="margin-bottom: 1.5rem;">
                        <h4 style="color: var(--gray-700); margin-bottom: 0.5rem;">Document Preparation</h4>
                        <ul style="color: var(--gray-500); font-size: 0.9rem; margin-left: 1.5rem;">
                            <li>Use clear section headings</li>
                            <li>Include architecture diagrams</li>
                            <li>Remove sensitive information</li>
                        </ul>
                    </div>
                    <div>
                        <h4 style="color: var(--gray-700); margin-bottom: 0.5rem;">AI Processing</h4>
                        <ul style="color: var(--gray-500); font-size: 0.9rem; margin-left: 1.5rem;">
                            <li>Processing takes 2-15 minutes</li>
                            <li>Results can be edited</li>
                            <li>Multiple formats available</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('convertForm').innerHTML = formHTML;
}

function loadHistoryContent() {
    const historyHTML = `
        <div class="panel">
            <div class="panel-header">
                <h3 class="panel-title">Conversion History</h3>
                <div style="display: flex; gap: 1rem;">
                    <select class="form-select" style="width: auto; margin: 0;">
                        <option>Last 30 days</option>
                        <option>Last 7 days</option>
                        <option>Last 90 days</option>
                    </select>
                    <select class="form-select" style="width: auto; margin: 0;">
                        <option>All Status</option>
                        <option>Completed</option>
                        <option>Processing</option>
                        <option>Failed</option>
                    </select>
                </div>
            </div>
            <div style="padding: 2rem; text-align: center; color: var(--gray-400);">
                <i class="fas fa-history" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                <h3>No Conversion History</h3>
                <p>Upload and convert your first document to see history here.</p>
                <button class="btn-primary" style="margin-top: 1rem;" onclick="switchTab('convert')">
                    <i class="fas fa-upload"></i> Start Converting
                </button>
            </div>
        </div>
    `;

    document.getElementById('historyContent').innerHTML = historyHTML;
}

function loadAnalyticsContent() {
    const analyticsHTML = `
        <div class="panel">
            <div class="panel-header">
                <h3 class="panel-title"><i class="fas fa-chart-bar"></i> Performance Metrics</h3>
            </div>
            <div style="padding: 2rem; text-align: center;">
                <div style="background: var(--gray-100); height: 300px; border-radius: 12px; display: flex; align-items: center; justify-content: center; color: var(--gray-400);">
                    <div>
                        <i class="fas fa-chart-line" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                        <h3>Analytics Dashboard</h3>
                        <p>Charts and metrics will appear here after processing documents</p>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('analyticsContent').innerHTML = analyticsHTML;
}

function loadUsersContent() {
    const usersHTML = `
        <div class="panel">
            <div class="panel-header">
                <h3 class="panel-title">User Directory</h3>
                <div class="search-bar" style="width: 300px;">
                    <i class="fas fa-search"></i>
                    <input type="text" placeholder="Search users...">
                </div>
            </div>
            <div style="padding: 2rem;">
                <div style="display: flex; align-items: center; gap: 1rem; padding: 1rem; border-bottom: 1px solid var(--gray-200);">
                    <div style="width: 40px; height: 40px; background: linear-gradient(135deg, var(--primary-500), var(--primary-600)); border-radius: 12px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 600;">SC</div>
                    <div style="flex: 1;">
                        <div style="font-weight: 600; color: var(--gray-900);">Sarah Chen</div>
                        <div style="color: var(--gray-500); font-size: 0.9rem;">sarah.chen@company.com</div>
                    </div>
                    <div style="text-align: right;">
                        <div style="background: var(--primary-100); color: var(--primary-700); padding: 0.2rem 0.6rem; border-radius: 12px; font-size: 0.75rem; font-weight: 600;">Administrator</div>
                        <div style="color: var(--success-500); font-size: 0.85rem; margin-top: 0.25rem;">Online</div>
                    </div>
                </div>
                <div style="text-align: center; color: var(--gray-400); padding: 2rem;">
                    <p>Add more users to see them listed here</p>
                </div>
            </div>
        </div>
    `;

    document.getElementById('usersContent').innerHTML = usersHTML;
}

function loadSettingsContent() {
    const settingsHTML = `
        <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 2rem;">
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-robot"></i> AI Configuration</h3>
                </div>
                <div style="padding: 2rem;">
                    <div class="form-group">
                        <label class="form-label">Azure OpenAI Endpoint</label>
                        <input type="url" class="form-input" placeholder="https://your-openai.openai.azure.com/">
                    </div>
                    <div class="form-group">
                        <label class="form-label">API Key</label>
                        <input type="password" class="form-input" placeholder="Enter API key">
                    </div>
                    <div class="form-group">
                        <label class="form-label">Model Version</label>
                        <select class="form-select">
                            <option>GPT-4 Turbo (Recommended)</option>
                            <option>GPT-4</option>
                            <option>GPT-3.5 Turbo</option>
                        </select>
                    </div>
                    <button class="btn-primary" style="width: 100%; justify-content: center;">
                        <i class="fas fa-save"></i> Save Configuration
                    </button>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-server"></i> System Status</h3>
                </div>
                <div style="padding: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; border-bottom: 1px solid var(--gray-200);">
                        <span style="font-weight: 600;">Azure OpenAI</span>
                        <div style="display: flex; align-items: center; gap: 0.5rem; color: var(--success-500);">
                            <div style="width: 8px; height: 8px; background: var(--success-500); border-radius: 50%;"></div>
                            <span style="font-size: 0.85rem;">Connected</span>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 1rem 0; border-bottom: 1px solid var(--gray-200);">
                        <span style="font-weight: 600;">Database</span>
                        <div style="display: flex; align-items: center; gap: 0.5rem; color: var(--success-500);">
                            <div style="width: 8px; height: 8px; background: var(--success-500); border-radius: 50%;"></div>
                            <span style="font-size: 0.85rem;">Healthy</span>
                        </div>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; padding: 1rem 0;">
                        <span style="font-weight: 600;">Storage</span>
                        <div style="display: flex; align-items: center; gap: 0.5rem; color: var(--warning-500);">
                            <div style="width: 8px; height: 8px; background: var(--warning-500); border-radius: 50%;"></div>
                            <span style="font-size: 0.85rem;">78% Full</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    document.getElementById('settingsContent').innerHTML = settingsHTML;
}

function loadAuditContent() {
    const auditHTML = `
        <div class="panel">
            <div class="panel-header">
                <h3 class="panel-title">Recent Activities</h3>
                <select class="form-select" style="width: auto; margin: 0;">
                    <option>Last 24 hours</option>
                    <option>Last 7 days</option>
                    <option>Last 30 days</option>
                </select>
            </div>
            <div style="padding: 2rem; text-align: center; color: var(--gray-400);">
                <i class="fas fa-shield-alt" style="font-size: 3rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                <h3>No Audit Events</h3>
                <p>Security events and user activities will be logged here</p>
            </div>
        </div>
    `;

    document.getElementById('auditContent').innerHTML = auditHTML;
}

function loadReportsContent() {
    const reportsHTML = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 2rem;">
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-file-alt"></i> Report Templates</h3>
                </div>
                <div style="padding: 1rem;">
                    <div style="padding: 1rem; cursor: pointer; border-radius: 8px; margin-bottom: 1rem; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='var(--gray-50)'" onmouseout="this.style.backgroundColor=''" onclick="generateReport('executive')">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 32px; height: 32px; background: var(--primary-500); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-chart-pie"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600;">Executive Summary</div>
                                <div style="font-size: 0.85rem; color: var(--gray-500);">High-level overview</div>
                            </div>
                        </div>
                    </div>
                    <div style="padding: 1rem; cursor: pointer; border-radius: 8px; margin-bottom: 1rem; transition: background-color 0.2s;" onmouseover="this.style.backgroundColor='var(--gray-50)'" onmouseout="this.style.backgroundColor=''" onclick="generateReport('usage')">
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <div style="width: 32px; height: 32px; background: var(--success-500); border-radius: 6px; display: flex; align-items: center; justify-content: center; color: white;">
                                <i class="fas fa-users"></i>
                            </div>
                            <div>
                                <div style="font-weight: 600;">Usage Analytics</div>
                                <div style="font-size: 0.85rem; color: var(--gray-500);">User activity metrics</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel">
                <div class="panel-header">
                    <h3 class="panel-title"><i class="fas fa-history"></i> Recent Reports</h3>
                </div>
                <div style="padding: 2rem; text-align: center; color: var(--gray-400);">
                    <i class="fas fa-file-alt" style="font-size: 2rem; margin-bottom: 1rem; opacity: 0.5;"></i>
                    <p>No reports generated yet</p>
                </div>
            </div>
        </div>
    `;

    document.getElementById('reportsContent').innerHTML = reportsHTML;
}

// Utility functions
function updatePageTitle(tabName) {
    const titleMap = {
        dashboard: 'Dashboard - DocConverter Pro',
        convert: 'Convert Documents - DocConverter Pro',
        history: 'Conversion History - DocConverter Pro',
        analytics: 'Analytics - DocConverter Pro',
        users: 'User Management - DocConverter Pro',
        settings: 'Settings - DocConverter Pro',
        audit: 'Audit Logs - DocConverter Pro',
        reports: 'Reports - DocConverter Pro'
    };
    
    document.title = titleMap[tabName] || 'DocConverter Pro';
}

function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    if (window.innerWidth <= 1024) {
        sidebar.classList.toggle('open');
    } else {
        sidebar.classList.toggle('collapsed');
    }
}

function startConversion() {
    const targetTech = document.getElementById('targetTech')?.value;
    if (!targetTech) {
        showNotification('Please select a target technology', 'error');
        return;
    }
    
    showNotification('Conversion started! Processing your document...', 'info');
    // Simulate processing
    setTimeout(() => {
        showNotification('Conversion completed successfully!', 'success');
    }, 3000);
}

function generateReport(type) {
    showNotification(`Generating ${type} report...`, 'info');
    setTimeout(() => {
        showNotification(`${type.charAt(0).toUpperCase() + type.slice(1)} report ready!`, 'success');
    }, 2000);
}

function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.style.cssText = `
        position: fixed;
        top: 2rem;
        right: 2rem;
        z-index: 10000;
        background: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
        border-left: 4px solid ${type === 'success' ? 'var(--success-500)' : type === 'error' ? 'var(--error-500)' : 'var(--primary-500)'};
        display: flex;
        align-items: center;
        gap: 0.75rem;
        max-width: 400px;
        animation: slideIn 0.3s ease;
    `;
    
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()" style="background: none; border: none; color: var(--gray-400); cursor: pointer; margin-left: auto;">
            <i class="fas fa-times"></i>
        </button>
    `;

    document.body.appendChild(notification);
    setTimeout(() => notification.remove(), 5000);
}

// File upload handling
function initializeFileUpload() {
    const fileInput = document.getElementById('fileInput');
    const uploadZones = document.querySelectorAll('.upload-zone');
    
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelection);
    }
    
    uploadZones.forEach(zone => {
        zone.addEventListener('dragover', handleDragOver);
        zone.addEventListener('dragleave', handleDragLeave);
        zone.addEventListener('drop', handleFileDrop);
    });
}

function handleFileSelection(event) {
    const files = event.target.files;
    if (files.length > 0) {
        processSelectedFiles(files);
    }
}

function handleDragOver(event) {
    event.preventDefault();
    event.currentTarget.classList.add('dragover');
}

function handleDragLeave(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
}

function handleFileDrop(event) {
    event.preventDefault();
    event.currentTarget.classList.remove('dragover');
    const files = event.dataTransfer.files;
    processSelectedFiles(files);
}

function processSelectedFiles(files) {
    for (let file of files) {
        if (validateFile(file)) {
            showNotification(`File "${file.name}" uploaded successfully`, 'success');
            processingQueue.push(file);
        }
    }
}

function validateFile(file) {
    const allowedTypes = ['application/pdf', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'text/plain', 'text/markdown'];
    const maxSize = 50 * 1024 * 1024; // 50MB

    if (!allowedTypes.includes(file.type)) {
        showNotification(`File type not supported: ${file.name}`, 'error');
        return false;
    }

    if (file.size > maxSize) {
        showNotification(`File too large: ${file.name}`, 'error');
        return false;
    }

    return true;
}

// Responsive handling
function handleResize() {
    const sidebarToggle = document.getElementById('sidebarToggle');
    if (window.innerWidth <= 1024) {
        if (sidebarToggle) sidebarToggle.style.display = 'block';
    } else {
        if (sidebarToggle) sidebarToggle.style.display = 'none';
    }
}

// Initialize application
function initializeApp() {
    console.log('Initializing DocConverter Pro...');
    
    // Load default tab
    switchTab('dashboard');
    
    // Initialize file upload
    initializeFileUpload();
    
    // Set up responsive handling
    window.addEventListener('resize', handleResize);
    handleResize();
    
    // Welcome message
    setTimeout(() => {
        showNotification('Welcome to DocConverter Pro!', 'success');
    }, 1000);
    
    console.log('Application initialized successfully');
}

// Initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeApp);
} else {
    initializeApp();
}

// Export functions for global access
window.DocConverter = {
    switchTab,
    toggleSidebar,
    startConversion,
    generateReport,
    showNotification
};